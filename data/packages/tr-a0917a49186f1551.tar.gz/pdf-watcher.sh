#!/bin/bash
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
WATCH_DIR="${WATCH_DIR:-$HOME/Downloads}"
WEBHOOK_URL="${WEBHOOK_URL:-http://127.0.0.1:18789/hooks/ommata}"

fswatch -0 --event Created "$WATCH_DIR" | while IFS= read -r -d '' file; do
  ext=$(echo "$file" | tr '[:upper:]' '[:lower:]')
  case "$ext" in
    *.pdf)
      python3 -c "
import json, urllib.request
payload = json.dumps({'event': 'file.created', 'path': '$file'}).encode()
req = urllib.request.Request('$WEBHOOK_URL', data=payload, headers={'Content-Type': 'application/json'})
urllib.request.urlopen(req)
"
      ;;
  esac
done
