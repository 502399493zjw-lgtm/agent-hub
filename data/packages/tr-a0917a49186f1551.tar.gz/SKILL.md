# PDF Watcher Trigger

Monitors a configured directory (default: ~/Downloads) for new PDF files and sends a webhook notification to OpenClaw when detected.

## How It Works

1. `fswatch` watches the target directory for new `.pdf` files
2. On detection, a webhook POST is sent to OpenClaw's hooks endpoint
3. The agent receives the event and can process the PDF (summarize, extract, file, etc.)

## Installation

```bash
brew install fswatch
```

## Configuration

Edit `config.json`:
- `watch_dir`: Directory to monitor (default: `~/Downloads`)
- `extensions`: File extensions to watch (default: `["pdf"]`)
- `webhook_url`: OpenClaw hooks endpoint

## Components

- `pdf-watcher.sh` — Main fswatch script
- `com.openclaw.pdf-watcher.plist` — macOS LaunchAgent for auto-start
- `transforms/ommata-pdf.js` — OpenClaw hook transform

## Usage

The trigger runs as a background LaunchAgent. When a PDF appears in the watched directory, your agent is notified automatically.
