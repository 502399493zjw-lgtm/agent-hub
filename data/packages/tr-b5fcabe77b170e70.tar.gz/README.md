# PDF Watcher Trigger

监控 ~/Downloads 目录中的新 PDF 文件，自动通知 OpenClaw Agent 处理。

## 架构

```
FSEvents (macOS) → fswatch → pdf-watcher.sh → POST /hooks/ommata → Agent
```

## 组件

- `scripts/pdf-watcher.sh` — 主监控脚本（fswatch + 过滤 + POST hooks）
- `transforms/ommata-pdf.js` — OpenClaw hooks transform（转换事件格式）
- `launchd/com.openclaw.pdf-watcher.plist` — macOS LaunchAgent（开机自启 + KeepAlive）

## 安装

1. 安装依赖：`brew install fswatch`
2. 复制脚本到 `~/.openclaw/hooks/`
3. 复制 transform 到 `~/.openclaw/hooks/transforms/`
4. 复制 plist 到 `~/Library/LaunchAgents/`
5. 加载：`launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist`

## 要求

- macOS（使用 FSEvents 内核级文件监控）
- fswatch（`brew install fswatch`）
- OpenClaw Gateway 运行中（hooks 端点可用）

## 无需 API Key
纯本地运行，不调用任何外部服务。
