# 基于 Subagent 派生的动态数据看板

静态数据看板显示过时数据，需要持续手动更新。您希望实时查看多个数据源，而无需构建自定义前端或担心达到 API 速率限制。

本工作流创建一个实时数据看板，它会派生 Subagent 以并行方式获取和处理数据：

• 同时监控多个数据源（API、数据库、GitHub、社交媒体）
• 为每个数据源派生 Subagent，以避免阻塞并分摊 API 负载
• 将结果聚合到统一的数据看板中（文本、HTML 或 Canvas）
• 每 N 分钟更新一次，显示最新数据
• 当指标超过阈值时发送告警
• 在数据库中维护历史趋势以供可视化

## 痛点

构建自定义数据看板需要数周时间。等到完成时，需求可能已经改变。顺序轮询多个 API 既慢又容易达到速率限制。您需要立即获得洞察，而不是在周末编码之后。

## 功能

您可以通过对话方式定义要监控的内容：“追踪 GitHub 星标、Twitter 提及、Polymarket 交易量和系统健康状况。” OpenClaw 会派生 Subagent 并行获取每个数据源的数据，聚合结果，并将格式化的数据看板发送到 Discord 或作为 HTML 文件。更新会根据 Cron 计划自动运行。

数据看板示例部分：
- **GitHub**：星标、分支、开放问题、近期提交
- **社交媒体**：Twitter 提及、Reddit 讨论、Discord 活动
- **市场**：Polymarket 交易量、预测趋势
- **系统健康**：CPU、内存、磁盘使用率、服务状态

## 所需技能

- 用于并行执行的 Subagent 派生
- `github` (gh CLI) 用于 GitHub 指标
- `bird` (Twitter) 用于社交数据
- `web_search` 或 `web_fetch` 用于外部 API
- `postgres` 用于存储历史指标
- Discord 或 Canvas 用于渲染数据看板
- Cron 作业用于计划更新

## 设置方法

1. 设置指标数据库：
```sql
CREATE TABLE metrics (
  id SERIAL PRIMARY KEY,
  source TEXT, -- 例如："github", "twitter", "polymarket"
  metric_name TEXT,
  metric_value NUMERIC,
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE alerts (
  id SERIAL PRIMARY KEY,
  source TEXT,
  condition TEXT,
  threshold NUMERIC,
  last_triggered TIMESTAMPTZ
);
```

2. 为数据看板更新创建一个 Discord 频道（例如，#dashboard）。

3. 提示 OpenClaw：
```text
You are my dynamic dashboard manager. Every 15 minutes, run a cron job to:

1. Spawn sub-agents in parallel to fetch data from:
   - GitHub: stars, forks, open issues, commits (past 24h)
   - Twitter: mentions of "@username", sentiment analysis
   - Polymarket: volume for tracked markets
   - System: CPU, memory, disk usage via shell commands

2. Each sub-agent writes results to the metrics database.

3. Aggregate all results and format a dashboard:

📊 **数据看板更新** — [timestamp]

**GitHub**
- ⭐ 星标：[count] (+[change])
- 🍴 分支：[count]
- 🐛 开放问题：[count]
- 💻 提交（24 小时）：[count]

**社交媒体**
- 🐦 Twitter 提及：[count]
- 📈 情感：[positive/negative/neutral]

**市场**
- 📊 Polymarket 交易量：$[amount]
- 🔥 趋势：[market names]

**系统健康**
- 💻 CPU：[usage]%
- 🧠 内存：[usage]%
- 💾 磁盘：[usage]%

4. Post to Discord #dashboard.

5. Check alert conditions:
   - If GitHub stars change > 50 in 1 hour → 提醒我
   - If system CPU > 90% → 告警
   - If negative sentiment spike on Twitter → 通知

将所有指标存储在数据库中以进行历史分析。
```

4. 可选：使用 Canvas 渲染带有图表的 HTML 数据看板。

5. 查询历史数据：“显示我过去 30 天的 GitHub 星标增长情况。”

## 相关链接

- [使用 Subagent 进行并行处理](https://docs.openclaw.ai/subagents)
- [数据看板设计原则](https://www.nngroup.com/articles/dashboard-design/)