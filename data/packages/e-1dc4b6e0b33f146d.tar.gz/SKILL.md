---
name: memory-config-strategy
displayName: Memory 配置策略
type: experience
description: OpenClaw Agent 三层记忆系统配置方案：Daily Log + MEMORY.md + Cron 自动维护。含模板、Cron 示例和最佳实践。
version: 1.0.0
tags: memory, cron, configuration, best-practice, agent-setup
category: Agent 配置
---

# Memory 配置策略

OpenClaw Agent 三层记忆系统的配置方案与最佳实践。

## 三层架构

| 层 | 文件 | 用途 | 更新频率 |
|----|------|------|----------|
| Daily Log | `memory/YYYY-MM-DD.md` | 当天原始事件记录 | 实时 |
| Long-term | `MEMORY.md` | 精炼的长期记忆 | 每周 |
| Semantic | Vector embeddings | 语义检索（可选） | 按需 |

## Cron 任务配置

### Daily Context Sync（每晚 23:00）
蒸馏当天对话 → 写入 `memory/YYYY-MM-DD.md`

### Weekly Memory Compound（每周日 22:00）
回顾本周日志 → 更新 `MEMORY.md` 精炼长期记忆

### Hourly Micro-Sync（5 次/天）
轻量检查近 3h 活动，追加当天日志

## MEMORY.md 结构建议

```markdown
## 🧑 用户画像
## ⚡ Agent 身份
## 📋 活跃项目
## 🔧 技术经验
## ⚠️ 已知问题
## 🎯 待办
```

## 核心原则

1. **Daily Log 是原始素材**：什么都可以记，不怕啰嗦
2. **MEMORY.md 是精炼成果**：只保留有价值的信息，定期清理过时内容
3. **安全边界**：MEMORY.md 仅在主会话加载，不在群聊中暴露
4. **"写下来"原则**：任何需要记住的东西必须写文件，不依赖"心里记着"
