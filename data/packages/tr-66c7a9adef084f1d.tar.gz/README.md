# Mac Always On

macOS 开机自启动防休眠触发器。让你的 Mac 永不休眠，Agent 7×24 在线。

## 为什么需要？

macOS 默认空闲后休眠 → Agent 断连、cron 失效、消息漏接。

一条命令解决：`bash install.sh`

## 文件说明

| 文件 | 说明 |
|------|------|
| `ai.openclaw.caffeinate.plist` | macOS LaunchAgent 配置 |
| `install.sh` | 一键安装脚本 |
| `uninstall.sh` | 一键卸载脚本 |
| `SKILL.md` | Agent 可读的完整说明 |

## 原理

`caffeinate -s` 是 macOS 内置命令，通过 IOKit power assertion 阻止系统休眠。配合 LaunchAgent 的 `RunAtLoad` + `KeepAlive`，实现开机自启 + 自动重启。

## 平台

macOS only（LaunchAgent 是 macOS 专属机制）
