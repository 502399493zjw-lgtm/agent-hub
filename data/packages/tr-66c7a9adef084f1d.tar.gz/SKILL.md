---
name: mac-always-on
displayName: Mac Always On
type: trigger
version: 1.0.0
description: macOS 开机自启动防休眠触发器。通过 LaunchAgent + caffeinate 让 Mac 永不休眠，确保 Agent 7×24 在线。一条命令安装，重启自动恢复。
tags: macos, caffeinate, always-on, launchagent, sleep-prevention
category: system
---

# Mac Always On — 让你的 Agent 永不掉线

macOS 默认会在空闲后休眠，导致 Agent 断连、cron 失效、消息漏接。

这个触发器通过系统级 LaunchAgent 调用 `caffeinate`，实现：
- **开机自动启动**（RunAtLoad）
- **进程挂了自动重启**（KeepAlive）
- **阻止系统休眠**（caffeinate -s）

## 安装

Agent 执行以下脚本即可完成安装：

```bash
bash install.sh
```

或手动操作：

```bash
# 1. 复制 plist 到 LaunchAgents 目录
cp ai.openclaw.caffeinate.plist ~/Library/LaunchAgents/

# 2. 加载并启动
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/ai.openclaw.caffeinate.plist
```

## 卸载

```bash
bash uninstall.sh
```

或手动：

```bash
launchctl bootout gui/$(id -u) ~/Library/LaunchAgents/ai.openclaw.caffeinate.plist
rm ~/Library/LaunchAgents/ai.openclaw.caffeinate.plist
```

## 验证

```bash
# 检查是否在运行
launchctl print gui/$(id -u)/ai.openclaw.caffeinate 2>/dev/null && echo "✅ 运行中" || echo "❌ 未运行"

# 检查 caffeinate 进程
pgrep -f "caffeinate -s" && echo "✅ 防休眠生效" || echo "❌ 未生效"
```

## 工作原理

| 组件 | 说明 |
|------|------|
| `caffeinate -s` | macOS 内置命令，`-s` 阻止系统休眠（保持 system sleep assertion） |
| LaunchAgent | macOS 用户级守护进程，开机自启 + 崩溃自重启 |
| `RunAtLoad` | 登录后立即执行 |
| `KeepAlive` | 进程退出后自动重启 |

## 注意事项

- 仅适用于 macOS（LaunchAgent 是 macOS 专属机制）
- 不阻止屏幕关闭（如需同时阻止屏幕关闭，改用 `caffeinate -disu`）
- 不影响手动休眠（合盖 / 点击「睡眠」仍然生效）
- 如果 Mac 是笔记本且不接电源，建议接电使用，否则会耗尽电池

## 适用场景

- Agent 服务器（OpenClaw / Claude Code / 任何长期运行的 Agent）
- cron 定时任务需要 Mac 不休眠
- 飞书 / Telegram / Discord 等消息渠道需要持续在线
- 开发机需要远程 SSH 访问
