#!/bin/bash
# Mac Always On — Install Script
# 安装 caffeinate LaunchAgent，让 Mac 永不休眠

set -e

PLIST_NAME="ai.openclaw.caffeinate.plist"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE="${SCRIPT_DIR}/${PLIST_NAME}"
TARGET="${HOME}/Library/LaunchAgents/${PLIST_NAME}"

# Check macOS
if [[ "$(uname)" != "Darwin" ]]; then
    echo "❌ 仅支持 macOS"
    exit 1
fi

# Check source exists
if [[ ! -f "$SOURCE" ]]; then
    echo "❌ 找不到 ${PLIST_NAME}"
    exit 1
fi

# Unload if already running
if launchctl print "gui/$(id -u)/ai.openclaw.caffeinate" &>/dev/null; then
    echo "⚠️  检测到已有实例，先卸载..."
    launchctl bootout "gui/$(id -u)" "$TARGET" 2>/dev/null || true
    sleep 1
fi

# Copy plist
cp "$SOURCE" "$TARGET"
echo "✅ 已复制 plist → ${TARGET}"

# Load
launchctl bootstrap "gui/$(id -u)" "$TARGET"
echo "✅ 已加载 LaunchAgent"

# Verify
sleep 1
if pgrep -f "caffeinate -s" >/dev/null; then
    echo "✅ caffeinate 正在运行，Mac 将不会休眠"
else
    echo "⚠️  caffeinate 未检测到，请检查 launchctl list | grep caffeinate"
fi

echo ""
echo "🎉 安装完成！Mac 重启后也会自动启动。"
