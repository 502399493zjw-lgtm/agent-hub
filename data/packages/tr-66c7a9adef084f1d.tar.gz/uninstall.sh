#!/bin/bash
# Mac Always On — Uninstall Script
# 卸载 caffeinate LaunchAgent，恢复默认休眠行为

set -e

PLIST_NAME="ai.openclaw.caffeinate.plist"
TARGET="${HOME}/Library/LaunchAgents/${PLIST_NAME}"

if [[ "$(uname)" != "Darwin" ]]; then
    echo "❌ 仅支持 macOS"
    exit 1
fi

if launchctl print "gui/$(id -u)/ai.openclaw.caffeinate" &>/dev/null; then
    launchctl bootout "gui/$(id -u)" "$TARGET" 2>/dev/null || true
    echo "✅ 已卸载 LaunchAgent"
else
    echo "ℹ️  LaunchAgent 未在运行"
fi

if [[ -f "$TARGET" ]]; then
    rm "$TARGET"
    echo "✅ 已删除 ${TARGET}"
else
    echo "ℹ️  plist 文件不存在"
fi

echo ""
echo "🎉 卸载完成。Mac 将恢复默认休眠行为。"
