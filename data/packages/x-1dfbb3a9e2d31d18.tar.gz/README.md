# 健康症状追踪

识别食物过敏或不耐受需要持续、一致地记录。但手动记食物日记太麻烦，大多数人坚持不下来。

本方案让 Agent 帮你轻松追踪：

- 用自然语言记录饮食（"午饭吃了意面和沙拉"）
- 记录身体症状（"下午胃胀、头疼"）
- 自动分析食物与症状的关联模式
- 生成周期性报告，识别可疑食物
- 就医时可导出完整记录

## 核心价值

- 降低记录门槛：聊天即记录
- 智能关联分析：人工很难发现的模式
- 长期趋势追踪：数据积累越多越准确

---

# Original (English)

# Health & Symptom Tracker

Identifying food sensitivities requires consistent logging over time, which is tedious to maintain. You need reminders to log and analysis to spot patterns.

This workflow tracks food and symptoms automatically:

• Message your food and symptoms in a dedicated Telegram topic and OpenClaw logs everything with timestamps
• 3x daily reminders (morning, midday, evening) prompt you to log meals
• Over time, analyzes patterns to identify potential triggers

## Skills you Need

- Cron jobs for reminders
- Telegram topic for logging
- File storage (markdown log file)

## How to Set it Up

1. Create a Telegram topic called "health-tracker" (or similar).
2. Create a log file: `~/clawd/memory/health-log.md`
3. Prompt OpenClaw:
```text
When I message in the "health-tracker" topic:
1. Parse the message for food items and symptoms
2. Log to ~/clawd/memory/health-log.md with timestamp
3. Confirm what was logged

Set up 3 daily reminders:
- 8 AM: "🍳 Log your breakfast"
- 1 PM: "🥗 Log your lunch"
- 7 PM: "🍽️ Log your dinner and any symptoms"

Every Sunday, analyze the past week's log and identify patterns:
- Which foods correlate with symptoms?
- Are there time-of-day patterns?
- Any clear triggers?

Post the analysis to the health-tracker topic.
```

4. Optional: Add a memory file for OpenClaw to track known triggers and update it as patterns emerge.
