# 健康与症状追踪器

识别食物敏感性需要长期持续地记录，但这过程维护起来很繁琐。你需要提醒来记录，也需要分析来发现模式。

此工作流自动追踪食物和症状：

• 在专用的 Telegram topic 中发送你的食物和症状消息，OpenClaw 会带时间戳记录一切
• 每日 3 次提醒（早、中、晚）提示你记录餐食
• 随着时间推移，分析模式以识别潜在触发因素

## 所需技能

- Cron jobs 用于提醒
- Telegram topic 用于记录
- 文件存储 (Markdown 日志文件)

## 如何设置

1.  创建一个名为 "health-tracker"（或类似名称）的 Telegram topic。
2.  创建一个日志文件：`~/clawd/memory/health-log.md`
3.  提示 OpenClaw：
    ```text
    When I message in the "health-tracker" topic:
    1. Parse the message for food items and symptoms
    2. Log to ~/clawd/memory/health-log.md with timestamp
    3. Confirm what was logged

    Set up 3 daily reminders:
    - 8 AM: "🍳 Log your breakfast"
    - 1 PM: "🥗 Log your lunch"
    - 7 PM: "🍽️ Log your dinner and any symptoms"

    Every Sunday, analyze the past week's log and identify patterns:
    - Which foods correlate with symptoms?
    - Are there time-of-day patterns?
    - Any clear triggers?

    Post the analysis to the health-tracker topic.
    ```
4.  可选：为 OpenClaw 添加一个记忆文件，用于追踪已知触发因素，并随着模式的出现进行更新。