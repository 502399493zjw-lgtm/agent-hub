# Skill Gaps — 能力缺口记录

> 由自进化系统信号采集模块自动维护。格式：`[日期] [类型] 描述 | session: key | 关键词: xxx`

<!-- 示例（安装后会被实际数据替换）：
- [2026-02-23] [Missing] 用户要求生成图片但无图片生成能力 | session: agent:main | 关键词: image generation, 图片生成
- [2026-02-23] [Failure] 代码审查遗漏类型错误 | session: agent:main | 关键词: code review, 类型检查
-->
