# Subagent自主项目管理

管理包含多条并行工作流的复杂项目令人筋疲力尽。你不断在上下文之间切换，跨工具跟踪状态，并手动协调交接。

本方案实现了一种去中心化的项目管理模式，其中 Subagent 自主完成任务，通过共享状态文件进行协调，而非依赖中央调度器。

## 痛点

传统的调度器模式会造成瓶颈——主 Agent 变成了交通警察。对于复杂项目（多仓库重构、研究冲刺、内容流水线），你需要能够并行工作且无需持续监督的 Agent。

## 功能特性

-   **去中心化协调**：Agent 读写共享的 `STATE.yaml` 文件
-   **并行执行**：多个 Subagent 同时处理独立任务
-   **无调度器开销**：主会话保持精简（CEO 模式——仅负责策略）
-   **自文档化**：所有任务状态都保留在版本控制文件中

## 核心模式：STATE.yaml

每个项目都维护一个 `STATE.yaml` 文件，作为单一事实来源：

```yaml
# STATE.yaml - 项目协调文件
project: website-redesign
updated: 2026-02-10T14:30:00Z

tasks:
  - id: homepage-hero
    status: in_progress # 进行中
    owner: pm-frontend
    started: 2026-02-10T12:00:00Z
    notes: "Working on responsive layout" # 正在处理响应式布局
    
  - id: api-auth
    status: done # 已完成
    owner: pm-backend
    completed: 2026-02-10T14:00:00Z
    output: "src/api/auth.ts"
    
  - id: content-migration
    status: blocked # 已阻塞
    owner: pm-content
    blocked_by: api-auth # 被 api-auth 阻塞
    notes: "Waiting for new endpoint schema" # 等待新的端点 schema

next_actions: # 下一步行动
  - "pm-content: Resume migration now that api-auth is done" # pm-content：api-auth 完成后恢复迁移
  - "pm-frontend: Review hero with design team" # pm-frontend：与设计团队一起审查 hero 部分
```

## 工作原理

1.  **主 Agent 接收任务** → 派生具有特定范围的 Subagent
2.  **Subagent 读取 STATE.yaml** → 找到其分配的任务
3.  **Subagent 自主工作** → 更新 STATE.yaml 以反映进度
4.  **其他 Agent 轮询 STATE.yaml** → 接手未阻塞的工作
5.  **主 Agent 定期检查** → 审查状态，调整优先级

## 所需技能

-   用于 Subagent 管理的 `sessions_spawn` / `sessions_send`
-   用于 STATE.yaml 的文件系统访问
-   用于状态版本控制的 Git（可选但推荐）

## 设置：AGENTS.md 配置

```text
## PM Delegation Pattern # PM 委托模式

Main session = coordinator ONLY. All execution goes to subagents. # 主会话仅为协调器。所有执行都交给 Subagent。

Workflow: # 工作流：
1. New task arrives # 新任务到达
2. Check PROJECT_REGISTRY.md for existing PM # 检查 PROJECT_REGISTRY.md 是否存在现有 PM
3. If PM exists → sessions_send(label="pm-xxx", message="[task]") # 如果 PM 存在 → sessions_send(label="pm-xxx", message="[task]")
4. If new project → sessions_spawn(label="pm-xxx", task="[task]") # 如果是新项目 → sessions_spawn(label="pm-xxx", task="[task]")
5. PM executes, updates STATE.yaml, reports back # PM 执行，更新 STATE.yaml，并报告结果
6. Main agent summarizes to user # 主 Agent 向用户总结

Rules: # 规则：
- Main session: 0-2 tool calls max (spawn/send only) # 主会话：最多 0-2 次工具调用（仅限 spawn/send）
- PMs own their STATE.yaml files # PM 拥有自己的 STATE.yaml 文件
- PMs can spawn sub-subagents for parallel subtasks # PM 可以派生子 Subagent 来处理并行子任务
- All state changes committed to git # 所有状态更改都提交到 Git
```

## 示例：派生 PM

```text
User: "Refactor the auth module and update the docs" # 用户：“重构 auth 模块并更新文档”

Main agent: # 主 Agent：
1. Checks registry → no active pm-auth # 检查注册表 → 没有活跃的 pm-auth
2. Spawns: sessions_spawn(
     label="pm-auth-refactor",
     task="Refactor auth module, update docs. Track in STATE.yaml"
   ) # 派生：sessions_spawn( label="pm-auth-refactor", task="重构 auth 模块，更新文档。在 STATE.yaml 中跟踪" )
3. Responds: "Spawned pm-auth-refactor. I'll report back when done." # 回应：“已派生 pm-auth-refactor。完成后我会报告。”

PM subagent: # PM Subagent：
1. Creates STATE.yaml with task breakdown # 创建包含任务分解的 STATE.yaml
2. Works through tasks, updating status # 处理任务，更新状态
3. Commits changes # 提交更改
4. Reports completion to main # 向主 Agent 报告完成情况
```

## 关键洞察

-   **STATE.yaml 优于调度器**：基于文件的协调比消息传递具有更好的可扩展性
-   **Git 作为审计日志**：提交 STATE.yaml 更改以获取完整历史记录
-   **标签约定很重要**：使用 `pm-{project}-{scope}` 便于跟踪
-   **精简主会话**：主 Agent 做得越少，响应越快

## 基于

本模式灵感来源于 [Nicholas Carlini 的方法](https://nicholas.carlini.com/)，该方法旨在实现自主编码 Agent——让 Agent 自我组织，而非对其进行微观管理。

## 相关链接

-   [OpenClaw Subagent 文档](https://github.com/openclaw/openclaw)
-   [Anthropic：构建高效 Agent](https://www.anthropic.com/research/building-effective-agents)