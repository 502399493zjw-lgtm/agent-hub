---
name: coding-helper
description: 编程辅助技能
---

# Coding Helper

帮助开发者编写、调试和优化代码的智能助手。支持多种编程语言的代码补全和调试分析。

## 功能
- 代码补全与生成
- Bug 修复建议
- 性能优化分析
- 单元测试生成
- 代码审查
