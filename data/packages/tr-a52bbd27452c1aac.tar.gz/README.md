# PDF Watcher

监控 Downloads 目录，自动检测 arxiv 论文 PDF 并触发 Agent 提取标题、重命名文件。

## 它做什么

当你从 arxiv 下载论文 PDF（通常文件名是 `2401.12345v2.pdf` 这种不可读格式），PDF Watcher 会：

1. **实时检测**：通过 macOS FSEvents 零轮询监控，检测到新 PDF 立即响应
2. **智能过滤**：只有 arxiv 格式的 PDF 才触发，普通 PDF 完全忽略
3. **触发 Agent**：通过 OpenClaw hooks 通知你的 Agent
4. **Agent 处理**：Agent 读取 PDF 内容，提取论文标题和作者，自动重命名为 `标题 - 作者.pdf`

## 效果

```
下载前：2401.12345v2.pdf
下载后：Attention Is All You Need - Vaswani et al.pdf
```

全程自动，无需操作。

## 技术架构

```
fswatch (FSEvents) → pdf-watcher.sh → POST /hooks/pdf-watcher → transform.js → Agent
```

- **pdf-watcher.sh**：bash 脚本，fswatch 监听文件创建/移入事件，过滤 arxiv PDF，POST 到 hooks
- **transform.js**：OpenClaw hooks transform，将事件数据转为 Agent 可执行的指令消息
- **Agent**：读 PDF、提取信息、重命名——利用 Agent 自身的理解能力，无需额外 NLP 脚本

## 要求

- macOS（依赖 FSEvents）
- OpenClaw + hooks 已启用
- `fswatch`（`brew install fswatch`）
- 可选：`poppler`（`brew install poppler`，提供 `pdftotext` 提高文本提取质量）

## 安装

详见 [SKILL.md](./SKILL.md) 的完整安装步骤。

## 文件说明

| 文件 | 用途 |
|------|------|
| `pdf-watcher.sh` | 主监控脚本（fswatch + arxiv 检测 + POST hooks） |
| `transform.js` | OpenClaw hooks transform（事件 → Agent 消息） |
| `SKILL.md` | Agent 可执行的安装指引 + 行为指令 |
| `README.md` | 本文件 |
