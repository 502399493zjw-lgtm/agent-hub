#!/bin/bash
# pdf-watcher.sh — 监控 ~/Downloads，检测 arxiv 论文 PDF 并通知 Agent
# 仅 arxiv 格式触发（文件名含 arxiv 或匹配 YYMM.NNNNN 模式），普通 PDF 静默忽略

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:${PATH}"

WATCH_DIR="${PDF_WATCH_DIR:-${HOME}/Downloads}"
HOOK_PORT="${OPENCLAW_HOOK_PORT:-18789}"
HOOK_URL="http://127.0.0.1:${HOOK_PORT}/hooks/pdf-watcher"

# 从 openclaw.json 读取 hooks token
HOOK_TOKEN="$(python3 -c "
import json, os
conf = os.path.expanduser('~/.openclaw/openclaw.json')
try:
    c = json.load(open(conf))
    print(c.get('hooks', {}).get('token', ''))
except: pass
" 2>/dev/null)"

if [ -z "$HOOK_TOKEN" ]; then
    echo "[pdf-watcher] ERROR: hooks token not found in ~/.openclaw/openclaw.json"
    echo "[pdf-watcher] Make sure hooks.enabled=true and hooks.token is set"
    exit 1
fi

echo "[pdf-watcher] Watching ${WATCH_DIR} for arxiv PDFs..."

# macOS bash 3 兼容：用 tr 替代 ${,,}
to_lower() { echo "$1" | tr '[:upper:]' '[:lower:]'; }

# 判断是否 arxiv 格式
is_arxiv() {
    local name="$1"
    local lower=$(to_lower "$name")
    # 含 arxiv 关键字
    case "$lower" in
        *arxiv*) return 0 ;;
    esac
    # 匹配 YYMM.NNNNN 格式（如 2401.12345）
    if echo "$name" | grep -qE '^[0-9]{4}\.[0-9]{4,5}'; then
        return 0
    fi
    return 1
}

fswatch -0 --event Created --event MovedTo --event Renamed "${WATCH_DIR}" | while IFS= read -r -d '' filepath; do
    filename=$(basename "$filepath")
    lower_name=$(to_lower "$filename")

    # 只处理 PDF
    case "$lower_name" in
        *.pdf) ;;
        *) continue ;;
    esac

    # 只处理 arxiv 格式
    if ! is_arxiv "$filename"; then
        continue
    fi

    echo "[pdf-watcher] arxiv PDF detected: ${filename}"

    # 用 Python 构造 JSON 避免 shell 转义问题
    python3 -c "
import json, sys, time, uuid
payload = {
    'event': 'arxiv_pdf_detected',
    'filename': sys.argv[1],
    'filepath': sys.argv[2],
    'watch_dir': sys.argv[3],
    'detected_at': int(time.time() * 1000),
    'event_id': str(uuid.uuid4())
}
print(json.dumps(payload))
" "$filename" "$filepath" "$WATCH_DIR" | curl -s -X POST "${HOOK_URL}" \
        -H "Authorization: Bearer ${HOOK_TOKEN}" \
        -H "Content-Type: application/json" \
        -d @- > /dev/null 2>&1

    echo "[pdf-watcher] → Notified Agent"
done
