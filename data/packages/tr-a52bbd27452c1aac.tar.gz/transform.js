// transform.js — PDF Watcher hooks transform
// 将 arxiv PDF 检测事件转为 Agent 可执行的消息
module.exports = function transform(body) {
  if (!body || body.event !== 'arxiv_pdf_detected') {
    return null;
  }

  const filename = body.filename || 'unknown.pdf';
  const filepath = body.filepath || '';

  const message = `[arxiv 论文检测] 新下载的 arxiv PDF：

文件名: \`${filename}\`
路径: \`${filepath}\`

请执行以下步骤：
1. 读取该 PDF 的前 2-3 页内容（用 exec 运行 pdftotext 或直接 read）
2. 从内容中提取论文标题和作者列表
3. 用格式 "标题 - 第一作者 et al.pdf" 重命名文件（mv 命令）
4. 简短告知处理结果`;

  return {
    message,
    name: 'pdf-watcher',
    wakeMode: 'now',
    deliver: true,
    channel: 'last'
  };
};
