---
name: pdf-watcher
description: >
  监控 Downloads 目录，检测 arxiv 论文 PDF 并自动触发 Agent 提取标题、重命名文件。
  仅 arxiv 格式 PDF 触发（文件名含 arxiv 或匹配 YYMM.NNNNN 模式），普通 PDF 静默忽略。
metadata:
  openclaw:
    type: trigger
    platform: macos
    requires:
      bins: [fswatch]
    tags: [pdf, arxiv, file-watcher, automation]
---

# PDF Watcher — arxiv 论文自动检测与重命名

当你下载 arxiv 论文 PDF 时，自动检测并触发 Agent 提取标题、作者，重命名为可读格式。

## 安装

### 前置条件

- macOS（使用 FSEvents 实现零轮询监控）
- OpenClaw hooks 已启用（`openclaw.json` 中 `hooks.enabled: true`）
- Homebrew（用于安装 fswatch）

### 步骤 1：安装依赖

```bash
# fswatch — 文件系统监控（必需）
brew install fswatch

# poppler — PDF 文本提取（可选，提高提取质量）
brew install poppler
```

### 步骤 2：部署脚本文件

```bash
# 复制监控脚本
cp pdf-watcher.sh ~/.openclaw/hooks/pdf-watcher.sh
chmod +x ~/.openclaw/hooks/pdf-watcher.sh

# 复制 transform
cp transform.js ~/.openclaw/hooks/transforms/pdf-watcher.js
```

### 步骤 3：配置 hooks mapping

在 `~/.openclaw/openclaw.json` 的 `hooks.mappings` 数组中添加：

```json
{
  "match": { "path": "pdf-watcher" },
  "action": "agent",
  "deliver": true,
  "allowUnsafeExternalContent": true,
  "channel": "last",
  "transform": { "module": "pdf-watcher.js" }
}
```

### 步骤 4：创建 LaunchAgent（开机自启）

写入 `~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist`：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.openclaw.pdf-watcher</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>${HOME}/.openclaw/hooks/pdf-watcher.sh</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${HOME}/.openclaw/logs/pdf-watcher.log</string>
    <key>StandardErrorPath</key>
    <string>${HOME}/.openclaw/logs/pdf-watcher.log</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin</string>
    </dict>
</dict>
</plist>
```

注意：将 `${HOME}` 替换为实际的用户主目录路径。

### 步骤 5：启动服务

```bash
mkdir -p ~/.openclaw/logs
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist
```

### 验证

```bash
# 查看日志
tail -f ~/.openclaw/logs/pdf-watcher.log

# 测试：下载一个 arxiv PDF 到 ~/Downloads
# 应该看到 "[pdf-watcher] arxiv PDF detected: ..." 并触发 Agent
```

## 卸载

```bash
launchctl bootout gui/$(id -u) ~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist
rm ~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist
rm ~/.openclaw/hooks/pdf-watcher.sh
rm ~/.openclaw/hooks/transforms/pdf-watcher.js
```

然后从 `openclaw.json` 中移除对应的 hooks mapping 条目。

## 配置

环境变量（可在 plist 中设置）：

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `PDF_WATCH_DIR` | `~/Downloads` | 监控目录 |
| `OPENCLAW_HOOK_PORT` | `18789` | OpenClaw hooks 端口 |

## Agent 行为

收到 arxiv PDF 事件后，Agent 会：

1. 读取 PDF 前 2-3 页内容
2. 提取论文标题和作者
3. 重命名文件为 `标题 - 第一作者 et al.pdf`
4. 告知处理结果

## 检测规则

仅以下文件名模式会触发 Agent：

- 文件名含 `arxiv`（不区分大小写）
- 文件名以 `YYMM.NNNNN` 开头（如 `2401.12345v2.pdf`）

其他 PDF 静默忽略，不打扰 Agent。
