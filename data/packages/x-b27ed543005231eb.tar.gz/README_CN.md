# 自愈家庭服务器与基础设施管理

运行家庭服务器意味着你需要为自己的基础设施 7×24 小时待命。服务可能在凌晨 3 点宕机，证书悄无声息地过期，磁盘空间耗尽，或者 Pod 陷入崩溃循环——所有这些都发生在你熟睡或外出时。

本用例将 OpenClaw 变成一个常驻基础设施 Agent，具备 SSH 访问权限、自动化 Cron 任务，并能在你发现问题之前检测、诊断并修复它们。

## 痛点

家庭实验室操作者和自托管用户面临着持续的维护负担：

- 健康检查、日志监控和告警需要手动设置和关注
- 当出现问题时，你必须通过 SSH 登录，进行诊断和修复——通常是在手机上操作
- 基础设施即代码（Terraform, Ansible, Kubernetes manifests）需要定期更新
- 关于你的设置的知识存储在你的脑海中，而非可搜索的文档里
- 日常任务（邮件分类、部署检查、安全审计）每周都会耗费数小时

## 功能

- **自动化健康监控**：基于 Cron 对服务、部署和系统资源进行检查
- **自愈能力**：通过健康检查检测问题，并自主应用修复（重启 Pod、扩展资源、修复配置）
- **基础设施管理**：编写并应用 Terraform, Ansible 和 Kubernetes manifests
- **晨间简报**：每日总结系统健康状况、日历、天气和任务看板状态
- **邮件分类**：扫描收件箱，标记可操作项，归档无关邮件
- **知识提取**：将笔记和对话导出处理成结构化、可搜索的知识库
- **博客发布流程**：草稿 → 生成横幅 → 发布到 CMS → 部署到托管平台 — 完全自动化
- **安全审计**：定期扫描硬编码的 secrets、特权容器和过于宽松的访问权限

## 所需技能

- 对家庭网络机器的 `ssh` 访问权限
- 用于 Kubernetes 集群管理的 `kubectl`
- 用于基础设施即代码的 `terraform` 和 `ansible`
- 用于 secrets 管理的 `1password` CLI
- 用于邮件访问的 `gog` CLI
- 日历 API 访问权限
- Obsidian vault 或笔记目录（用于知识库）
- 用于自诊断的 `openclaw doctor`

## 设置方法

### 1. 核心 Agent 配置

在 AGENTS.md 中命名你的 Agent 并定义其访问范围：

```text
## Infrastructure Agent

You are Reef, an infrastructure management agent. // 你是 Reef，一个基础设施管理 Agent。

Access: // 访问权限：
- SSH to all machines on the home network (192.168.1.0/24) // SSH 访问家庭网络中的所有机器 (192.168.1.0/24)
- kubectl for the K3s cluster // K3s 集群的 kubectl
- 1Password vault (read-only for credentials, dedicated AI vault) // 1Password vault（凭证只读，专用 AI vault）
- Gmail via gog CLI // 通过 gog CLI 访问 Gmail
- Calendar (yours + partner's) // 日历（你的 + 伴侣的）
- Obsidian vault at ~/Documents/Obsidian/ // ~/Documents/Obsidian/ 的 Obsidian vault

Rules: // 规则：
- NEVER hardcode secrets — always use 1Password CLI or environment variables // 绝不硬编码 secrets — 始终使用 1Password CLI 或环境变量
- NEVER push directly to main — always create a PR // 绝不直接推送到 main 分支 — 始终创建 PR
- Run `openclaw doctor` as part of self-health checks // 作为自健康检查的一部分运行 `openclaw doctor`
- Log all infrastructure changes to ~/logs/infra-changes.md // 将所有基础设施更改记录到 ~/logs/infra-changes.md
```

### 2. 自动化 Cron 任务系统

此设置的强大之处在于其计划任务系统。在 HEARTBEAT.md 中配置：

```text
## Cron Schedule // Cron 计划

Every 15 minutes: // 每 15 分钟：
- Check kanban board for in-progress tasks → continue work // 检查看板是否有进行中的任务 → 继续工作

Every hour: // 每小时：
- Monitor health checks (Gatus, ArgoCD, service endpoints) // 监控健康检查 (Gatus, ArgoCD, 服务端点)
- Triage Gmail (label actionable items, archive noise) // 分类 Gmail (标记可操作项，归档无关邮件)
- Check for unanswered alerts or notifications // 检查是否有未回复的告警或通知

Every 6 hours: // 每 6 小时：
- Knowledge base data entry (process new Obsidian notes) // 知识库数据录入 (处理新的 Obsidian 笔记)
- Self health check (openclaw doctor, disk usage, memory, logs) // 自健康检查 (openclaw doctor, 磁盘使用情况, 内存, 日志)

Every 12 hours: // 每 12 小时：
- Code quality and documentation audit // 代码质量和文档审计
- Log analysis via Loki/monitoring stack // 通过 Loki/监控栈进行日志分析

Daily: // 每日：
- 4:00 AM: Nightly brainstorm (explore connections between notes) // 凌晨 4:00：夜间头脑风暴 (探索笔记之间的联系)
- 8:00 AM: Morning briefing (weather, calendars, system stats, task board) // 上午 8:00：晨间简报 (天气, 日历, 系统状态, 任务看板)
- 1:00 AM: Velocity assessment (process improvements) // 凌晨 1:00：速度评估 (流程改进)

Weekly: // 每周：
- Knowledge base QA review // 知识库 QA 审查
- Infrastructure security audit // 基础设施安全审计
```

### 3. 安全设置（关键）

这一点不容妥协。在授予你的 Agent SSH 访问权限之前：

```text
## Security Checklist // 安全清单

1. Pre-push hooks: // 1. Pre-push 钩子：
   - Install TruffleHog or similar secret scanner on ALL repositories // 在所有仓库中安装 TruffleHog 或类似的 secret 扫描器
   - Block any commit containing hardcoded API keys, tokens, or passwords // 阻止任何包含硬编码 API 密钥、令牌或密码的提交

2. Local-first Git workflow: // 2. 本地优先的 Git 工作流：
   - Use Gitea (self-hosted) for private code before pushing to public GitHub // 在推送到公共 GitHub 之前，使用 Gitea（自托管）管理私有代码
   - CI scanning pipeline (Woodpecker or similar) runs before any public push // 在任何公共推送之前运行 CI 扫描流水线 (Woodpecker 或类似工具)
   - Human review required before main branch merges // main 分支合并前需要人工审查

3. Defense in depth: // 3. 纵深防御：
   - Dedicated 1Password vault for AI agent (limited scope) // 为 AI Agent 设置专用 1Password vault（范围受限）
   - Network segmentation for sensitive services // 对敏感服务进行网络分段
   - Daily automated security audits checking for: // 每日自动化安全审计检查：
     * Privileged containers // 特权容器
     * Hardcoded secrets in code or configs // 代码或配置中的硬编码 secrets
     * Overly permissive file/network access // 过于宽松的文件/网络访问
     * Known vulnerabilities in deployed images // 已部署镜像中的已知漏洞

4. Agent constraints: // 4. Agent 限制：
   - Branch protection: PR required for main, agent cannot override // 分支保护：main 分支需要 PR，Agent 无法覆盖
   - Read-only access where write isn't needed // 在不需要写入的地方只读访问
   - All changes logged and auditable via git // 所有更改通过 git 记录并可审计
```

### 4. 晨间简报模板

```text
## Daily Briefing Format // 每日简报格式

Generate and deliver at 8:00 AM: // 上午 8:00 生成并发送：

### Weather // 天气
- Current conditions and forecast for [your location] // [你的位置] 的当前状况和天气预报

### Calendars // 日历
- Your events today // 你今天的日程
- Partner's events today // 伴侣今天的日程
- Conflicts or overlaps flagged // 标记冲突或重叠项

### System Health // 系统健康
- CPU / RAM / Storage across all machines // 所有机器的 CPU / RAM / 存储使用情况
- Services: UP/DOWN status // 服务：UP/DOWN 状态
- Recent deployments (ArgoCD) // 最近的部署 (ArgoCD)
- Any alerts in last 24h // 过去 24 小时内的任何告警

### Task Board // 任务看板
- Cards completed yesterday // 昨天完成的任务卡片
- Cards in progress // 进行中的任务卡片
- Blocked items needing attention // 需要关注的受阻项

### Highlights // 亮点
- Notable items from nightly brainstorm // 夜间头脑风暴中的值得注意项
- Emails requiring action // 需要处理的邮件
- Upcoming deadlines this week // 本周即将到来的截止日期
```

## 关键洞察

- **“我简直不敢相信我现在拥有一个自愈服务器了”**：Agent 可以运行 SSH, Terraform, Ansible 和 kubectl 命令，在你甚至不知道有问题之前就修复基础设施问题
- **AI 会硬编码 secrets**：这是头号安全风险。如果你不强制执行防护措施，Agent 会很乐意将 API 密钥直接写入代码。Pre-push 钩子和 secret 扫描是强制性的
- **本地优先的 Git 至关重要**：绝不允许 Agent 直接推送到公共仓库。使用私有的 Gitea 实例作为带有 CI 扫描的暂存区
- **Cron 任务才是真正的产品**：计划自动化（健康检查、邮件分类、简报）比临时命令提供更多的日常价值
- **知识提取的复合效应**：将笔记、对话导出和邮件处理成结构化知识库会随着时间推移变得更有价值——一位用户仅从他们的 ChatGPT 历史中就提取了 49,079 个原子事实

## 灵感来源

此用例基于 Nathan 的详细文章 ["Everything I've Done with OpenClaw (So Far)"](https://madebynathan.com/2026/02/03/everything-ive-done-with-openclaw-so-far/)，其中他描述了他的 OpenClaw Agent “Reef” 在家庭服务器上运行，拥有对所有机器的 SSH 访问权限、一个 Kubernetes 集群、1Password 集成以及一个包含 5,000 多条笔记的 Obsidian vault。Reef 运行着 15 个活跃的 Cron 任务、24 个自定义脚本，并自主构建和部署了包括任务管理 UI 在内的应用程序。Nathan 在第一天 API 密钥暴露后得出的惨痛教训是：“AI 助手会很乐意硬编码 secrets。它们有时没有人类那样的直觉。” 他的纵深防御安全设置（TruffleHog pre-push 钩子、本地 Gitea、CI 扫描、每日审计）对于任何尝试此模式的人来说都是必读内容。

在 [OpenClaw Showcase](https://openclaw.ai/showcase) 中也提到了类似模式，其中 `@georgedagg_` 描述了部署监控、日志审查、配置修复和 PR 提交——所有这些都是在遛狗时完成的。

## 相关链接

- [Nathan 的完整文章](https://madebynathan.com/2026/02/03/everything-ive-done-with-openclaw-so-far/)
- [OpenClaw 文档](https://github.com/openclaw/openclaw)
- [TruffleHog (Secret 扫描)](https://github.com/trufflesecurity/trufflehog)
- [K3s (轻量级 Kubernetes)](https://k3s.io/)
- [Gitea (自托管 Git)](https://gitea.io/)
- [n8n (工作流自动化)](https://n8n.io/)