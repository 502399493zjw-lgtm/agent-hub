# YouTube 内容流水线

做 YouTube 内容创作太累——选题调研、写脚本、做缩略图、写标题描述、发布优化——每一步都耗时间。

本方案搭建一条完整的 YouTube 内容生产流水线：

- **选题调研**：分析热门趋势、竞品频道、评论区需求
- **脚本生成**：基于调研结果撰写视频脚本
- **SEO 优化**：生成标题、描述、标签
- **缩略图文案**：设计缩略图上的文字和构图建议
- **发布排期**：根据受众活跃时间建议最佳发布时间
- **数据追踪**：发布后追踪播放量和互动数据

## 适用场景

- YouTube 创作者提效
- MCN 机构批量生产
- 知识类/教程类频道内容规划

---

# YouTube 内容流水线

作为一名日常 YouTube 创作者，在网络和 X/Twitter 上寻找新鲜、及时的视频创意非常耗时。追踪你已经涵盖过的内容可以避免重复，并帮助你保持领先趋势。

此工作流自动化了整个内容搜寻和研究流水线：

*   每小时运行的 Cron job 扫描突发 AI 新闻（网络 + X/Twitter），并将视频创意推送到 Telegram
*   维护一个包含播放量和主题分析的 90 天视频目录，以避免重复涵盖主题
*   将所有创意存储在带有 vector embeddings 的 SQLite 数据库中，用于语义去重（这样你就不会收到两次相同的创意）
*   当你在 Slack 中分享一个链接时，OpenClaw 会研究该主题，在 X 上搜索相关帖子，查询你的 knowledge base，并创建一个包含完整大纲的 Asana 卡片

## 所需技能

-   `web_search` (内置)
-   [x-research-v2](https://clawhub.ai) 或自定义 X/Twitter 搜索技能
-   用于 RAG 的 [knowledge-base](https://clawhub.ai) 技能
-   Asana 集成（或 Todoist）
-   用于 YouTube Analytics 的 `gog` CLI
-   用于接收创意的 Telegram 主题

## 如何设置

1.  设置一个用于视频创意的 Telegram 主题，并在 OpenClaw 中进行配置。
2.  安装 knowledge-base 技能和 x-research 技能。
3.  创建一个用于创意追踪的 SQLite 数据库：
    ```sql
    CREATE TABLE pitches (
      id INTEGER PRIMARY KEY,
      timestamp TEXT,
      topic TEXT,
      embedding BLOB,
      sources TEXT
    );
    ```
4.  提示 OpenClaw：
    ```text
    Run an hourly cron job to:
    1. Search web and X/Twitter for breaking AI news
    2. Check against my 90-day YouTube catalog (fetch from YouTube Analytics via gog)
    3. Check semantic similarity against all past pitches in the database
    4. If novel, pitch the idea to my Telegram "video ideas" topic with sources

    Also: when I share a link in Slack #ai_trends, automatically:
    1. Research the topic
    2. Search X for related posts
    3. Query my knowledge base
    4. Create an Asana card in Video Pipeline with a full outline
    ```