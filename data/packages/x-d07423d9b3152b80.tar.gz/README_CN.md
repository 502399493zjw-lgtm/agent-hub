# 目标驱动自主任务

你的 AI Agent 功能强大，但却被动——它只在你发出指令时才工作。如果它能了解你的目标，并每天主动提出任务，让你更接近目标，而无需你吩咐，那会怎样？

此工作流将 OpenClaw 转化为一个自主工作的“员工”。你只需一次性倾倒你的所有目标，Agent 就会自主生成、安排并完成推进这些目标的任务——包括在夜间为你构建惊喜小应用。

## 功能介绍

- 你将所有个人和职业目标、使命和目的倾倒给 OpenClaw
- 每天早上，Agent 会生成 4-5 个它可以在你的电脑上自主完成的任务
- 任务范围超越应用构建：包括研究、编写脚本、开发功能、创作内容、分析竞争对手
- Agent 自行执行任务，并在它为你构建的自定义 Kanban board 上跟踪进度
- 你还可以让它每晚为你构建一个惊喜小应用——一个全新的 SaaS 想法，一个自动化你生活中无聊部分的工具，以 MVP 形式交付

## 痛点

大多数人都有宏伟目标，但却难以将其分解为日常可操作的步骤。即使分解了，执行也耗费了他们所有的时间。本系统将规划和执行都卸载给你的 AI Agent。你定义目的地；Agent 负责找出并完成每日的步骤。

## 所需技能

- Telegram 或 Discord 集成
- 用于自主任务执行的 `sessions_spawn` / `sessions_send`
- Next.js 或类似框架（用于 Kanban board——OpenClaw 会为你构建）

## 设置方法

### 步骤 1：倾倒你的目标

这是最重要的一步。将你想要完成的一切都通过文本发送给 OpenClaw：

```text
Here are my goals and missions. Remember all of this:

Career:
- Grow my YouTube channel to 100k subscribers
- Launch my SaaS product by Q3
- Build a community around AI education

Personal:
- Read 2 books per month
- Learn Spanish

Business:
- Scale revenue to $10k/month
- Build partnerships with 5 companies in my space
- Automate as much of my workflow as possible

Use this context for everything you do going forward.
```

### 步骤 2：设置自主日常任务

```text
Every morning at 8:00 AM, come up with 4-5 tasks that you can complete
on my computer today that bring me closer to my goals.

Then schedule and complete those tasks yourself. Examples:
- Research competitors and write analysis reports
- Draft video scripts based on trending topics
- Build new features for my apps
- Write and schedule social media content
- Research potential business partnerships
- Build me a surprise mini-app MVP that gets me closer to one of my goals

Track all tasks on a Kanban board. Update the board as you complete them.
```

### 步骤 3：构建 Kanban board（可选）

```text
Build me a Kanban board in Next.js where I can see all the tasks you're
working on. Show columns for To Do, In Progress, and Done. Update it
in real-time as you complete tasks.
```

## 核心洞察

- **倾倒目标至关重要**。你提供关于目标的上下文越多，Agent 生成的日常任务就越好。不要有所保留。
- Agent 会发现你意想不到的任务。它能将你的目标串联起来，并找到你可能会错过的机会。
- Kanban board 将你的 Agent 变成一个可追踪的“员工”。你可以清楚地看到它在做什么，并进行纠正。
- 特别是对于夜间应用构建：明确告诉它构建 MVP，不要过度复杂化。你每天早上醒来都会有一个新的惊喜。
- 这会随着时间推移而产生复利效应——Agent 会学习哪些任务最有帮助并进行调整。

## 基于

灵感来自 [Alex Finn](https://www.youtube.com/watch?v=UTCi_q6iuCM&t=414s) 及其[关于改变生活的 OpenClaw 用例视频](https://www.youtube.com/watch?v=41_TNGDDnfQ)。

## 相关链接

- [OpenClaw 记忆系统](https://github.com/openclaw/openclaw)
- [OpenClaw Subagent 文档](https://github.com/openclaw/openclaw)