---
name: dingtalk-openclaw-connector
displayName: 钉钉 OpenClaw Connector
type: channel
description: 钉钉官方团队出品的 OpenClaw 通信渠道插件。支持 AI Card 流式响应、会话持久化、图片上传、主动发消息。1278 星。
version: 1.0.0
tags: dingtalk, 钉钉, channel, stream, ai-card, official
category: 通信渠道
---

# 钉钉 OpenClaw Connector

钉钉官方团队（DingTalk-Real-AI）出品，将钉钉机器人/DEAP Agent 连接到 OpenClaw Gateway。

- **GitHub**: https://github.com/DingTalk-Real-AI/dingtalk-openclaw-connector
- **Stars**: 1278 ⭐
- **安装**: `openclaw plugins install @dingtalk-real-ai/dingtalk-connector`

## 核心能力

- 🔄 **Stream 模式**：钉钉 Stream API 长连接，低延迟
- 🃏 **AI Card 流式响应**：打字机效果实时输出
- 💾 **会话持久化**：群聊 / 单聊 session 自动管理
- 🖼️ **图片上传**：支持发送图片到聊天
- 📤 **主动发消息**：支持 Agent 主动推送通知

## 适用场景

- 企业内部 AI 助手接入钉钉群
- 钉钉机器人 + OpenClaw Agent 联动
- DEAP Agent 扩展能力
