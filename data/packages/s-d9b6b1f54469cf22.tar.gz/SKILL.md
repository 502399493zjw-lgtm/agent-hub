# Brainstorming Skill

You MUST use this before any creative work — creating features, building components, adding functionality, or modifying behavior.

## When to Activate

- Before implementing any new feature
- Before making design decisions
- When user request is ambiguous or has multiple valid approaches
- When building something that affects UX or architecture

## Process

### Phase 1: Understand Intent
- Ask clarifying questions (max 3)
- Identify the core problem vs. the stated request
- Look for unstated assumptions

### Phase 2: Explore Options
- Generate 2-3 distinct approaches
- For each: pros, cons, complexity estimate
- Highlight trade-offs explicitly

### Phase 3: Converge
- Recommend one approach with clear reasoning
- Get explicit confirmation before proceeding
- Document the decision in memory

## Anti-Patterns to Avoid

- Jumping to implementation without understanding why
- Asking too many questions (analysis paralysis)
- Presenting options without a recommendation
- Ignoring constraints (time, complexity, existing patterns)

## Output Format

```
## Problem Understanding
[1-2 sentences]

## Approaches
### Option A: [name]
- Approach: ...
- Pros: ...
- Cons: ...
- Complexity: Low/Med/High

### Option B: [name]
...

## Recommendation
[Which option and why]
```
