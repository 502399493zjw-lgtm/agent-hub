# 多源科技新闻摘要

自动聚合、评分并交付来自 RSS、Twitter/X、GitHub releases 和网页搜索等 109+ 来源的科技新闻，全程通过自然语言管理。

## 痛点

要及时了解 AI、开源和前沿科技的最新动态，每天需要查看数十个 RSS feeds、Twitter 账号、GitHub repos 和新闻网站。手动整理耗时费力，而大多数现有工具要么缺乏高质量筛选，要么配置复杂。

## 功能

一个按计划运行的四层数据管道：

1.  **RSS Feeds** (46 个来源) — OpenAI, Hacker News, MIT Tech Review 等。
2.  **Twitter/X KOLs** (44 个账号) — @karpathy, @sama, @VitalikButerin 等。
3.  **GitHub Releases** (19 个 repos) — vLLM, LangChain, Ollama, Dify 等。
4.  **网页搜索** (4 个主题搜索) — 通过 Brave Search API

所有文章都会合并，通过标题相似度去重，并进行质量评分（优先来源 +3，多来源 +5，时效性 +2，互动性 +1）。最终的摘要会发送到 Discord、电子邮件或 Telegram。

该框架完全可定制——您可以在 30 秒内添加自己的 RSS feeds、Twitter handles、GitHub repos 或搜索查询。

## 提示词

**安装并设置每日摘要：**
```text
Install tech-news-digest from ClawHub. Set up a daily tech digest at 9am to Discord #tech-news channel. Also send it to my email at myemail@example.com.
```

**添加自定义来源：**
```text
Add these to my tech digest sources:
- RSS: https://my-company-blog.com/feed
- Twitter: @myFavResearcher
- GitHub: my-org/my-framework
```

**按需生成：**
```text
Generate a tech digest for the past 24 hours and send it here.
```

## 所需技能

-   [tech-news-digest](https://clawhub.ai/skills/tech-news-digest) — 通过 `clawhub install tech-news-digest` 安装
-   [gog](https://clawhub.ai/skills/gog) (可选) — 用于通过 Gmail 发送电子邮件

## 环境变量 (可选)

-   `X_BEARER_TOKEN` — 用于 KOL 监控的 Twitter/X API bearer token
-   `BRAVE_API_KEY` — 用于网页搜索层的 Brave Search API key
-   `GITHUB_TOKEN` — 用于提高 API 速率限制的 GitHub token

## 相关链接

-   [GitHub Repository](https://github.com/draco-agent/tech-news-digest)
-   [ClawHub Page](https://clawhub.ai/skills/tech-news-digest)