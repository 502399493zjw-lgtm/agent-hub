# 📄 PDF Watcher

基于 macOS fswatch（FSEvents 内核级事件）的 PDF 文件监控触发器。

## 功能

- **实时文件监控**：使用 macOS 原生 FSEvents 内核事件，零轮询，零延迟
- **arXiv 论文智能识别**：自动检测 arXiv 论文 ID 模式（如 `2401.12345.pdf`）和文件名中的 "arxiv" 关键字
- **OpenClaw Hooks 集成**：检测到新 PDF 后通过 Hooks webhook 唤醒 Agent 处理
- **自动重命名**：arXiv 论文自动读取标题和作者，以 "标题 - 作者.pdf" 格式重命名

## 架构

```
fswatch (FSEvents) → pdf-watcher.sh → HTTP POST → OpenClaw Hooks → ommata-pdf.js transform → Agent Session
```

## 组件

| 文件 | 说明 |
|------|------|
| `pdf-watcher.sh` | 主监控脚本，检测新 PDF 并发送事件 |
| `transforms/ommata-pdf.js` | OpenClaw Hooks transform，将事件转换为 Agent 指令 |
| `com.openclaw.pdf-watcher.plist` | macOS LaunchAgent 配置，开机自启 |

## 安装

1. 确保已安装 `fswatch`：`brew install fswatch`
2. 将 plist 复制到 `~/Library/LaunchAgents/`
3. 加载服务：`launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist`

## 配置

- 监控目录：默认 `~/Downloads`（在 `pdf-watcher.sh` 中修改 `WATCH_DIR`）
- Hooks 地址：默认 `http://127.0.0.1:18789/hooks/ommata`
- 日志路径：`~/.openclaw/logs/pdf-watcher.log`

## 兼容性

- macOS 专用（依赖 FSEvents + fswatch）
- 兼容 macOS 自带 bash 3.x（避免使用 bash 4+ 语法）
