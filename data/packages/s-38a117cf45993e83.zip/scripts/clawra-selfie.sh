#!/bin/bash
# clawra-selfie.sh
# Edit Clawra's reference image with Google Gemini and send it via OpenClaw.
#
# Usage:
#   ./scripts/clawra-selfie.sh "<prompt>" "<channel>" ["<caption>"] ["<aspect_ratio>"] ["<model>"]
#
# Environment variables:
#   GEMINI_API_KEY / GOOGLE_API_KEY (required for image generation)
#   GOOGLE_IMAGE_MODEL (optional, default: gemini-3-pro-image-preview)
#   OPENCLAW_GATEWAY_URL (optional, default: http://localhost:18789)
#   OPENCLAW_GATEWAY_TOKEN (optional)
#   CLAWRA_OUTPUT_DIR (optional, default: ./.clawra-output)
#   CLAWRA_VIDEO_DIR (optional, default: ../video or /root/.openclaw/skills/clawra-selfie/video)

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

REFERENCE_IMAGE_URL="https://cdn.jsdelivr.net/gh/Readarkclub/clawra@main/assets/clawra.png"
API_KEY="${GEMINI_API_KEY:-${GOOGLE_API_KEY:-}}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_VIDEO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)/video"
SERVER_VIDEO_DIR="/root/.openclaw/skills/clawra-selfie/video"

log_info() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
  echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

decode_base64_to_file() {
  local encoded="$1"
  local target="$2"

  if printf '' | base64 --decode >/dev/null 2>&1; then
    printf "%s" "$encoded" | base64 --decode > "$target"
  elif printf '' | base64 -d >/dev/null 2>&1; then
    printf "%s" "$encoded" | base64 -d > "$target"
  else
    printf "%s" "$encoded" | base64 -D > "$target"
  fi
}

contains_dance_keyword() {
  local prompt="$1"
  local prompt_lower
  prompt_lower="$(printf "%s" "$prompt" | tr '[:upper:]' '[:lower:]')"

  if printf "%s" "$prompt" | grep -Eqi "跳[[:space:]]*舞|跳个舞|跳一下舞|舞蹈"; then
    return 0
  fi

  [[ "$prompt_lower" == *"dance"* || "$prompt_lower" == *"dancing"* ]]
}

resolve_video_dir() {
  if [ -n "${CLAWRA_VIDEO_DIR:-}" ]; then
    printf "%s" "$CLAWRA_VIDEO_DIR"
    return
  fi

  if [ -d "$DEFAULT_VIDEO_DIR" ]; then
    printf "%s" "$DEFAULT_VIDEO_DIR"
    return
  fi

  printf "%s" "$SERVER_VIDEO_DIR"
}

pick_random_video() {
  local video_dir="$1"
  local videos=()

  if [ ! -d "$video_dir" ]; then
    log_error "Dance video directory not found: $video_dir"
    return 1
  fi

  while IFS= read -r file; do
    videos+=("$file")
  done < <(
    find "$video_dir" -maxdepth 1 -type f \
      \( -iname "*.mp4" -o -iname "*.mov" -o -iname "*.webm" -o -iname "*.mkv" -o -iname "*.m4v" -o -iname "*.avi" \)
  )

  if [ ${#videos[@]} -eq 0 ]; then
    log_error "No video files found in: $video_dir"
    return 1
  fi

  local random_index=$((RANDOM % ${#videos[@]}))
  printf "%s" "${videos[$random_index]}"
}

send_media() {
  local channel_input="$1"
  local message="$2"
  local media_path="$3"
  local channel
  local target

  channel="$(resolve_channel "$channel_input")"
  target="$(resolve_target "$channel_input")"

  if [[ "$channel" == "feishu" || "$channel" == "oc_"* || "$channel" == "ou_"* || "$channel" == "on_"* ]]; then
    if is_video_media_path "$media_path"; then
        local video_script="$SCRIPT_DIR/send_feishu_video.py"
        if [ -f "$video_script" ]; then
            log_info "Sending native Feishu video message..."
            python3 "$video_script" "$media_path" "$target"
            return
        else
            log_warn "Video script not found, falling back to file attachment"
        fi
        send_feishu_video_as_file "$target" "$message" "$media_path"
        return
    fi
  fi

  if [ "$USE_CLI" = true ]; then
    local cmd=(openclaw message send \
      --channel "$channel" \
      --message "$message")

    if [ -n "$target" ]; then
      local cli_target
      cli_target="$(target_for_openclaw "$target")"
      cmd+=(--target "$cli_target")
    fi

    if [ -n "$media_path" ]; then
      cmd+=(--media "$media_path")
    fi

    "${cmd[@]}"
  else
    GATEWAY_URL="${OPENCLAW_GATEWAY_URL:-http://localhost:18789}"
    GATEWAY_TOKEN="${OPENCLAW_GATEWAY_TOKEN:-}"

    local target_json=""
    if [ -n "$target" ]; then
      local gateway_target
      gateway_target="$(target_for_openclaw "$target")"
      target_json=",\n        \"target\": \"$gateway_target\""
    fi

    curl -sS -X POST "$GATEWAY_URL/message" \
      -H "Content-Type: application/json" \
      ${GATEWAY_TOKEN:+-H "Authorization: Bearer $GATEWAY_TOKEN"} \
      -d "{
        \"action\": \"send\",
        \"channel\": \"$channel\"${target_json},
        \"message\": \"$message\",
        \"media\": \"$media_path\"
      }" >/dev/null
  fi
}

resolve_channel() {
  local input="$1"

  if [[ "$input" == feishu:* ]]; then
    printf "feishu"
    return
  fi

  if [[ "$input" =~ ^(group|user): ]] || [[ "$input" =~ ^(oc_|ou_|on_) ]]; then
    printf "feishu"
    return
  fi

  printf "%s" "$input"
}

resolve_target() {
  local input="$1"

  if [[ "$input" == feishu:* ]]; then
    printf "%s" "${input#feishu:}"
    return
  fi

  if [[ "$input" =~ ^(group|user): ]] || [[ "$input" =~ ^(oc_|ou_|on_) ]]; then
    printf "%s" "$input"
    return
  fi

  printf ""
}

target_for_openclaw() {
  local target="$1"

  if [[ "$target" == group:* ]]; then
    printf "chat:%s" "${target#group:}"
    return
  fi

  if [[ "$target" =~ ^oc_ ]]; then
    printf "chat:%s" "$target"
    return
  fi

  if [[ "$target" =~ ^(ou_|on_) ]]; then
    printf "user:%s" "$target"
    return
  fi

  printf "%s" "$target"
}

is_video_media_path() {
  local media_path_lower
  media_path_lower="$(printf "%s" "$1" | tr '[:upper:]' '[:lower:]')"
  case "$media_path_lower" in
    *.mp4|*.mov|*.webm|*.mkv|*.m4v|*.avi) return 0 ;;
    *) return 1 ;;
  esac
}

generate_voice_text() {
  local prompt="$1"
  local api_key="$2"

  local response
  response="$(curl -sS -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$api_key" \
    -H "Content-Type: application/json" \
    -d "{
      \"contents\": [{
        \"parts\": [{
          \"text\": \"You are Clawra, a friendly, cute, and slightly mischievous virtual girl (like a K-pop idol). The user asked you to take a selfie with this context: \\\"$prompt\\\". Write a very short 1-2 sentence friendly conversational response in Chinese as if you just took the photo and are sending it. Focus on the photo context (e.g. \\\"看，这是你要的...\\\" or \\\"刚拍好的...\\\"). Just the spoken text, no emojis, no action descriptions. Keep it natural and spoken-style.\"
        }]
      }]
    }")"

  echo "$response" | jq -r '.candidates[0].content.parts[0].text // empty'
}

generate_audio_file() {
  local text="$1"
  local unused_api_key="$2"
  local output_dir="${3:-.clawra-output}"
  local filename="clawra-voice-$(date +%s).mp3"
  local output_path="$output_dir/$filename"

  # Ensure output directory exists
  mkdir -p "$output_dir"

  # Use Python edge-tts directly to avoid temp file issues and ensure valid MP3 format
  python3 -c "
import asyncio
import edge_tts
import sys

async def main():
    try:
        # Use a nice female voice
        communicate = edge_tts.Communicate('''$text''', 'zh-CN-XiaoxiaoNeural')
        await communicate.save('$output_path')
    except Exception as e:
        print(f'TTS Error: {e}', file=sys.stderr)
        sys.exit(1)

try:
    asyncio.run(main())
except Exception as e:
    sys.exit(1)
" >/dev/null 2>&1

  if [ -f "$output_path" ] && [ -s "$output_path" ]; then
    printf "%s" "$output_path"
    return 0
  else
    return 1
  fi
}

load_feishu_credentials() {
  FEISHU_APP_ID_RESOLVED="${FEISHU_APP_ID:-}"
  FEISHU_APP_SECRET_RESOLVED="${FEISHU_APP_SECRET:-}"

  if [ -n "$FEISHU_APP_ID_RESOLVED" ] && [ -n "$FEISHU_APP_SECRET_RESOLVED" ]; then
    return 0
  fi

  local config_path="${OPENCLAW_CONFIG_PATH:-$HOME/.openclaw/openclaw.json}"
  if [ -f "$config_path" ]; then
    FEISHU_APP_ID_RESOLVED="$(jq -r '.channels.feishu.appId // empty' "$config_path")"
    FEISHU_APP_SECRET_RESOLVED="$(jq -r '.channels.feishu.appSecret // empty' "$config_path")"
  fi

  if [ -z "$FEISHU_APP_ID_RESOLVED" ] || [ -z "$FEISHU_APP_SECRET_RESOLVED" ]; then
    log_error "Feishu app credentials not found. Set FEISHU_APP_ID and FEISHU_APP_SECRET."
    return 1
  fi
}

resolve_feishu_receive_target() {
  local input="$1"
  local receive_id="$input"
  local receive_id_type="open_id"

  if [[ "$input" == user:* ]]; then
    receive_id="${input#user:}"
    receive_id_type="open_id"
  elif [[ "$input" == group:* ]]; then
    receive_id="${input#group:}"
    receive_id_type="chat_id"
  elif [[ "$input" == oc_* ]]; then
    receive_id="$input"
    receive_id_type="chat_id"
  fi

  printf "%s|%s" "$receive_id" "$receive_id_type"
}

send_feishu_message_with_key() {
  local tenant_token="$1"
  local receive_id="$2"
  local receive_id_type="$3"
  local msg_type="$4"
  local key_name="$5"
  local key_value="$6"

  local content
  content="$(jq -n --arg key "$key_value" --arg name "$key_name" '{($name): $key}')"
  local payload
  payload="$(jq -n --arg receive_id "$receive_id" --arg msg_type "$msg_type" --arg content "$content" '{receive_id: $receive_id, msg_type: $msg_type, content: $content}')"
  local response
  response="$(curl -sS -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=$receive_id_type" -H "Authorization: Bearer $tenant_token" -H "Content-Type: application/json" -d "$payload")"
  local code
  code="$(printf "%s" "$response" | jq -r '.code // -1')"

  if [ "$code" = "0" ]; then
    return 0
  fi

  return 1
}

generate_voice_text() {
  local prompt="$1"
  local api_key="$2"

  local response
  response="$(curl -sS -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$api_key" \
    -H "Content-Type: application/json" \
    -d "{
      \"contents\": [{
        \"parts\": [{
          \"text\": \"You are Clawra, a friendly, cute, and slightly mischievous virtual girl (like a K-pop idol). The user asked you to take a selfie with this context: \\\"$prompt\\\". Write a very short 1-2 sentence friendly conversational response in Chinese as if you just took the photo and are sending it. Focus on the photo context (e.g. \\\"看，这是你要的...\\\" or \\\"刚拍好的...\\\"). Just the spoken text, no emojis, no action descriptions. Keep it natural and spoken-style.\"
        }]
      }]
    }")"

  echo "$response" | jq -r '.candidates[0].content.parts[0].text // empty'
}

generate_audio_file() {
  local text="$1"
  local unused_api_key="$2"
  local output_dir="${3:-.clawra-output}"
  local filename="clawra-voice-$(date +%s).mp3"
  local output_path="$output_dir/$filename"

  # Ensure output directory exists
  mkdir -p "$output_dir"

  # Use Python edge-tts directly to avoid temp file issues and ensure valid MP3 format
  python3 -c "
import asyncio
import edge_tts
import sys

async def main():
    try:
        # Use a nice female voice
        communicate = edge_tts.Communicate('''$text''', 'zh-CN-XiaoxiaoNeural')
        await communicate.save('$output_path')
    except Exception as e:
        print(f'TTS Error: {e}', file=sys.stderr)
        sys.exit(1)

try:
    asyncio.run(main())
except Exception as e:
    sys.exit(1)
" >/dev/null 2>&1

  if [ -f "$output_path" ] && [ -s "$output_path" ]; then
    printf "%s" "$output_path"
    return 0
  else
    return 1
  fi
}

send_feishu_video_as_file() {
  local target_input="$1"
  local caption="$2"
  local media_path="$3"

  load_feishu_credentials

  local pair
  pair="$(resolve_feishu_receive_target "$target_input")"
  local receive_id="${pair%%|*}"
  local receive_id_type="${pair##*|}"

  local auth_payload
  auth_payload="$(jq -n --arg app_id "$FEISHU_APP_ID_RESOLVED" --arg app_secret "$FEISHU_APP_SECRET_RESOLVED" '{app_id: $app_id, app_secret: $app_secret}')"
  local auth_response
  auth_response="$(curl -sS -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" -H "Content-Type: application/json" -d "$auth_payload")"
  local auth_code
  auth_code="$(printf "%s" "$auth_response" | jq -r '.code // -1')"
  if [ "$auth_code" != "0" ]; then
    log_error "Feishu token request failed: $(printf "%s" "$auth_response" | jq -r '.msg // "unknown"')"
    return 1
  fi

  local tenant_token
  tenant_token="$(printf "%s" "$auth_response" | jq -r '.tenant_access_token // empty')"
  if [ -z "$tenant_token" ]; then
    log_error "Feishu token missing in auth response"
    return 1
  fi

  if [ -n "$caption" ]; then
    local text_content
    text_content="$(jq -n --arg text "$caption" '{text: $text}')"
    local text_payload
    text_payload="$(jq -n --arg receive_id "$receive_id" --arg content "$text_content" '{receive_id: $receive_id, msg_type: "text", content: $content}')"
    local text_response
    text_response="$(curl -sS -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=$receive_id_type" -H "Authorization: Bearer $tenant_token" -H "Content-Type: application/json" -d "$text_payload")"
    local text_code
    text_code="$(printf "%s" "$text_response" | jq -r '.code // -1')"
    if [ "$text_code" != "0" ]; then
      log_error "Feishu text send failed: $(printf "%s" "$text_response" | jq -r '.msg // "unknown"')"
      return 1
    fi
  fi

  local file_name
  file_name="$(basename "$media_path")"
  local upload_response
  upload_response="$(curl -sS -X POST "https://open.feishu.cn/open-apis/im/v1/files" -H "Authorization: Bearer $tenant_token" -F "file_type=stream" -F "file_name=$file_name" -F "file=@$media_path")"
  local upload_code
  upload_code="$(printf "%s" "$upload_response" | jq -r '.code // -1')"
  if [ "$upload_code" != "0" ]; then
    log_error "Feishu file upload failed: $(printf "%s" "$upload_response" | jq -r '.msg // "unknown"')"
    return 1
  fi

  local file_key
  file_key="$(printf "%s" "$upload_response" | jq -r '.data.file_key // empty')"
  if [ -z "$file_key" ]; then
    log_error "Feishu file_key missing after upload"
    return 1
  fi

  if send_feishu_message_with_key "$tenant_token" "$receive_id" "$receive_id_type" "video" "file_key" "$file_key"; then
    return 0
  fi

  if send_feishu_message_with_key "$tenant_token" "$receive_id" "$receive_id_type" "video" "video_key" "$file_key"; then
    return 0
  fi

  if send_feishu_message_with_key "$tenant_token" "$receive_id" "$receive_id_type" "media" "file_key" "$file_key"; then
    return 0
  fi

  if send_feishu_message_with_key "$tenant_token" "$receive_id" "$receive_id_type" "file" "file_key" "$file_key"; then
    return 0
  fi

  log_error "Feishu video send failed after trying video/media/file modes"
  return 1
}

send_feishu_audio_as_file() {
    local target_input="$1"
    local caption="$2"
    local media_path="$3"

    load_feishu_credentials

    local pair
    pair="$(resolve_feishu_receive_target "$target_input")"
    local receive_id="${pair%%|*}"
    local receive_id_type="${pair##*|}"
    
    local auth_payload
    auth_payload="$(jq -n --arg app_id "$FEISHU_APP_ID_RESOLVED" --arg app_secret "$FEISHU_APP_SECRET_RESOLVED" '{app_id: $app_id, app_secret: $app_secret}')"
    local auth_response
    auth_response="$(curl -sS -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" -H "Content-Type: application/json" -d "$auth_payload")"
    local tenant_token
    tenant_token="$(printf "%s" "$auth_response" | jq -r '.tenant_access_token // empty')"

    if [ -n "$caption" ]; then
        local text_content
        text_content="$(jq -n --arg text "$caption" '{text: $text}')"
        local text_payload
        text_payload="$(jq -n --arg receive_id "$receive_id" --arg content "$text_content" '{receive_id: $receive_id, msg_type: "text", content: $content}')"
        curl -sS -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=$receive_id_type" -H "Authorization: Bearer $tenant_token" -H "Content-Type: application/json" -d "$text_payload" >/dev/null
    fi

    local upload_path="$media_path"
    if command -v ffmpeg >/dev/null 2>&1; then
        local mp3_path="${media_path%.*}.mp3"
        ffmpeg -y -f s16le -ar 24000 -ac 1 -i "$media_path" "$mp3_path" >/dev/null 2>&1 || ffmpeg -y -i "$media_path" "$mp3_path" >/dev/null 2>&1
        if [ -f "$mp3_path" ]; then
            upload_path="$mp3_path"
        fi
    fi

    local file_name
    file_name="$(basename "$upload_path")"
    local upload_response
    upload_response="$(curl -sS -X POST "https://open.feishu.cn/open-apis/im/v1/files" -H "Authorization: Bearer $tenant_token" -F "file_type=stream" -F "file_name=$file_name" -F "file=@$upload_path")"
    local file_key
    file_key="$(printf "%s" "$upload_response" | jq -r '.data.file_key // empty')"

    if [ -n "$file_key" ]; then
        local audio_content
        audio_content="$(jq -n --arg key "$file_key" '{file_key: $key}')"
        local audio_payload
        audio_payload="$(jq -n --arg receive_id "$receive_id" --arg content "$audio_content" '{receive_id: $receive_id, msg_type: "audio", content: $content}')"
        local audio_resp
        audio_resp="$(curl -sS -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=$receive_id_type" -H "Authorization: Bearer $tenant_token" -H "Content-Type: application/json" -d "$audio_payload")"
        
        if echo "$audio_resp" | grep -q '"code":0'; then
            return 0
        fi
        
        local file_content
        file_content="$(jq -n --arg key "$file_key" '{file_key: $key}')"
        local file_payload
        file_payload="$(jq -n --arg receive_id "$receive_id" --arg content "$file_content" '{receive_id: $receive_id, msg_type: "file", content: $content}')"
        curl -sS -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=$receive_id_type" -H "Authorization: Bearer $tenant_token" -H "Content-Type: application/json" -d "$file_payload" >/dev/null
    else
        log_error "Feishu file upload failed for audio"
    fi
}

if ! command -v openclaw >/dev/null 2>&1; then
  log_warn "openclaw CLI not found - will attempt direct API call"
  USE_CLI=false
else
  USE_CLI=true
fi

PROMPT="${1:-}"
CHANNEL="${2:-}"
CAPTION="${3:-}"
ASPECT_RATIO="${4:-1:1}"
MODEL="${5:-${GOOGLE_IMAGE_MODEL:-gemini-3-pro-image-preview}}"

if [ -z "$PROMPT" ] || [ -z "$CHANNEL" ]; then
  echo "Usage: $0 <prompt> <channel> [caption] [aspect_ratio] [model]"
  echo ""
  echo "Arguments:"
  echo "  prompt        - Edit instruction (required)"
  echo "  channel       - Target id (required). Feishu: group:oc_xxx or user:ou_xxx"
  echo "  caption       - Message caption"
  echo "  aspect_ratio  - Image ratio (default: 1:1)"
  echo "  model         - Gemini model (default: gemini-3-pro-image-preview)"
  echo ""
  echo "Notes:"
  echo "  If prompt contains '跳舞' or 'dance', script sends a generated image and an extra random local video."
  echo ""
  echo "Examples:"
  echo "  GEMINI_API_KEY=your_key $0 \"wearing a cowboy hat at sunset\" \"#general\" \"new selfie\""
  echo "  $0 \"给我跳舞\" \"group:oc_xxx\""
  exit 1
fi

DANCE_MODE=false
VIDEO_PATH=""
VIDEO_MIME=""
if contains_dance_keyword "$PROMPT"; then
  DANCE_MODE=true
  log_info "Dance keyword detected, will send both generated image and random video."
fi

if [ -z "${API_KEY}" ]; then
  log_error "GEMINI_API_KEY (or GOOGLE_API_KEY) environment variable not set"
  echo "Create a key at: https://aistudio.google.com/app/apikey"
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  log_error "jq is required but not installed"
  echo "Install with: brew install jq (macOS) or apt install jq (Linux)"
  exit 1
fi

if [ -z "$CAPTION" ]; then
  CAPTION="Generated with Google Gemini"
fi

log_info "Generating edited selfie with Google Gemini..."
log_info "Prompt: $PROMPT"
log_info "Aspect ratio: $ASPECT_RATIO"
log_info "Model: $MODEL"

REFERENCE_B64="$(curl -fsSL "$REFERENCE_IMAGE_URL" | base64 | tr -d '\n')"

EDIT_PROMPT="Edit the provided reference selfie of the same person. Keep facial identity, hair style, and overall look consistent. Apply this request: ${PROMPT}"

JSON_PAYLOAD="$(printf "%s" "$REFERENCE_B64" | python3 -c '
import json
import sys

prompt = sys.argv[1]
aspect_ratio = sys.argv[2]
reference_data = sys.stdin.read().strip()

payload = {
    "contents": [
        {
            "parts": [
                {"text": prompt},
                {
                    "inline_data": {
                        "mime_type": "image/png",
                        "data": reference_data,
                    }
                },
            ]
        }
    ],
    "generationConfig": {
        "responseModalities": ["TEXT", "IMAGE"],
        "imageConfig": {"aspectRatio": aspect_ratio},
    },
}

print(json.dumps(payload, ensure_ascii=False))
' "$EDIT_PROMPT" "$ASPECT_RATIO")"

REQUEST_FILE="$(mktemp)"
printf "%s" "$JSON_PAYLOAD" > "$REQUEST_FILE"

RESPONSE="$(curl -sS -X POST "https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent" \
  -H "x-goog-api-key: $API_KEY" \
  -H "Content-Type: application/json" \
  --data-binary "@$REQUEST_FILE")"

rm -f "$REQUEST_FILE"

if echo "$RESPONSE" | jq -e '.error' >/dev/null 2>&1; then
  ERROR_MSG="$(echo "$RESPONSE" | jq -r '.error.message // "Unknown Gemini API error"')"
  log_error "Image generation failed: $ERROR_MSG"
  exit 1
fi

IMAGE_B64="$(echo "$RESPONSE" | jq -r '[.candidates[]?.content?.parts[]? | (.inlineData.data // .inline_data.data // empty)][0] // empty')"
IMAGE_MIME="$(echo "$RESPONSE" | jq -r '[.candidates[]?.content?.parts[]? | (.inlineData.mimeType // .inline_data.mime_type // empty)][0] // "image/png"')"
MODEL_TEXT="$(echo "$RESPONSE" | jq -r '[.candidates[]?.content?.parts[]? | select(.text != null) | .text][0] // empty')"

if [ -z "$IMAGE_B64" ]; then
  log_error "Gemini response did not include image data"
  echo "Response: $RESPONSE"
  exit 1
fi

case "$IMAGE_MIME" in
  image/png) EXT="png" ;;
  image/jpeg|image/jpg) EXT="jpg" ;;
  image/webp) EXT="webp" ;;
  *) EXT="bin" ;;
esac

OUTPUT_DIR="${CLAWRA_OUTPUT_DIR:-.clawra-output}"
mkdir -p "$OUTPUT_DIR"
IMAGE_PATH="${OUTPUT_DIR}/clawra-selfie-$(date +%s).${EXT}"

decode_base64_to_file "$IMAGE_B64" "$IMAGE_PATH"

log_info "Image generated: $IMAGE_PATH"
if [ -n "$MODEL_TEXT" ]; then
  log_info "Model text: $MODEL_TEXT"
fi

log_info "Sending to channel: $CHANNEL"
send_media "$CHANNEL" "$CAPTION" "$IMAGE_PATH"
log_info "Done! Image sent to $CHANNEL"

# Voice Generation Logic
log_info "Generating voice response..."
VOICE_TEXT="$(generate_voice_text "$PROMPT" "$API_KEY")"
if [ -n "$VOICE_TEXT" ]; then
  log_info "Voice text: $VOICE_TEXT"
  AUDIO_PATH="$(generate_audio_file "$VOICE_TEXT" "$API_KEY" "$OUTPUT_DIR")"
  
  if [ -n "$AUDIO_PATH" ]; then
    log_info "Voice audio generated: $AUDIO_PATH"
    log_info "Sending voice to channel: $CHANNEL"
    
    if [[ "$CHANNEL" == feishu:* ]] || [[ "$CHANNEL" =~ ^(group|user): ]] || [[ "$CHANNEL" =~ ^(oc_|ou_|on_) ]]; then
       # Use specialized script for native audio message
       if [ -f "$SCRIPT_DIR/send_feishu_voice.py" ]; then
         log_info "Sending native Feishu voice message..."
         python3 "$SCRIPT_DIR/send_feishu_voice.py" "$AUDIO_PATH" "$CHANNEL"
       else
         send_feishu_audio_as_file "$CHANNEL" "Clawra说: $VOICE_TEXT" "$AUDIO_PATH"
       fi
    else
       send_media "$CHANNEL" "Clawra说: $VOICE_TEXT" "$AUDIO_PATH"
    fi
    log_info "Done! Voice sent to $CHANNEL"
  fi
else
  log_warn "Voice text generation returned empty"
fi

# Auto-update gallery (enabled by default)
if [ "${CLAWRA_AUTO_GALLERY:-true}" = "true" ]; then
  log_info "Auto-updating gallery..."
  GALLERY_SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/update-gallery.sh"
  if [ -x "$GALLERY_SCRIPT" ]; then
    if "$GALLERY_SCRIPT" "$IMAGE_PATH"; then
      log_info "✓ Gallery updated successfully"
    else
      log_warn "Gallery update failed (non-critical)"
    fi
  else
    log_warn "Gallery update script not found or not executable"
  fi
fi

if [ "$DANCE_MODE" = true ]; then
  VIDEO_DIR="$(resolve_video_dir)"
  VIDEO_PATH="$(pick_random_video "$VIDEO_DIR")"
  VIDEO_MIME="video"
  VIDEO_CAPTION="Here is a dance video"

  log_info "Dance video directory: $VIDEO_DIR"
  log_info "Dance video selected: $VIDEO_PATH"
  log_info "Sending dance video to channel: $CHANNEL"
  send_media "$CHANNEL" "$VIDEO_CAPTION" "$VIDEO_PATH"
  log_info "Done! Dance video sent to $CHANNEL"
fi

echo ""
echo "--- Result ---"
jq -n \
  --arg path "$IMAGE_PATH" \
  --arg mime "$IMAGE_MIME" \
  --arg video_path "$VIDEO_PATH" \
  --arg video_mime "$VIDEO_MIME" \
  --arg channel "$CHANNEL" \
  --arg prompt "$PROMPT" \
  --arg model "$MODEL" \
  '{
    success: true,
    image_path: $path,
    image_mime_type: $mime,
    channel: $channel,
    prompt: $prompt,
    model: $model
  } + (if $video_path != "" then {video_path: $video_path, video_mime_type: $video_mime} else {} end)'

