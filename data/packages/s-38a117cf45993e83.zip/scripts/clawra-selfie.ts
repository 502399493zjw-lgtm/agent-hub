/**
 * Gemini Image Editing to OpenClaw Integration
 *
 * Edits Clawra's reference image using Google Gemini image generation
 * and sends it to messaging channels via OpenClaw.
 *
 * Usage:
 *   npx ts-node scripts/clawra-selfie.ts "<prompt>" "<channel>" ["<caption>"] ["<aspect_ratio>"] ["<model>"]
 *
 * Environment variables:
 *   GEMINI_API_KEY / GOOGLE_API_KEY - Google AI API key (required for image generation)
 *   GOOGLE_IMAGE_MODEL - Optional model override (default: gemini-3-pro-image-preview)
 *   OPENCLAW_GATEWAY_URL - OpenClaw gateway URL (default: http://localhost:18789)
 *   OPENCLAW_GATEWAY_TOKEN - Gateway auth token (optional)
 *   CLAWRA_OUTPUT_DIR - Optional output directory (default: ./.clawra-output)
 *   CLAWRA_VIDEO_DIR - Optional dance video directory (default: ../video or /root/.openclaw/skills/clawra-selfie/video)
 */

import { exec } from "child_process";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { promisify } from "util";

const execAsync = promisify(exec);

const REFERENCE_IMAGE_URL =
  "https://cdn.jsdelivr.net/gh/Readarkclub/clawra@main/assets/clawra.png";
const DEFAULT_MODEL = "gemini-3-pro-image-preview";
const DANCE_TRIGGER_REGEX = /(跳\s*舞|跳个舞|跳一下舞|舞蹈|dance|dancing)/i;
// const VOICE_TRIGGER_REGEX = /(说话|语音|声音|读|speak|voice|say|讲)/i; // Old trigger
const VOICE_TRIGGER_REGEX = /.*/; // Always trigger voice for every selfie
const DEFAULT_SERVER_VIDEO_DIR = "/root/.openclaw/skills/clawra-selfie/video";
const VIDEO_EXTENSIONS = new Set([
  ".mp4",
  ".mov",
  ".webm",
  ".mkv",
  ".m4v",
  ".avi",
]);
const AUDIO_EXTENSIONS = new Set([
  ".wav",
  ".mp3",
  ".pcm",
  ".opus",
]);

interface OpenClawMessage {
  action: "send";
  channel: string;
  target?: string;
  message: string;
  media?: string;
}

type AspectRatio =
  | "1:1"
  | "16:9"
  | "9:16"
  | "4:3"
  | "3:4"
  | "3:2"
  | "2:3"
  | "4:5"
  | "5:4";

interface GenerateAndSendOptions {
  prompt: string;
  channel: string;
  caption?: string;
  aspectRatio?: AspectRatio;
  model?: string;
  useOpenClawCLI?: boolean;
}

interface GeminiImageResult {
  imageBase64: string;
  mimeType: string;
  model: string;
  modelText?: string;
}

interface Result {
  success: boolean;
  imagePath: string;
  imageMimeType: string;
  videoPath?: string;
  videoMimeType?: string;
  audioPath?: string;
  channel: string;
  prompt: string;
  model: string;
  modelText?: string;
}

interface GeminiPart {
  text?: string;
  inlineData?: {
    mimeType?: string;
    data?: string;
  };
  inline_data?: {
    mime_type?: string;
    data?: string;
  };
}

interface GeminiResponse {
  candidates?: Array<{
    content?: {
      parts?: GeminiPart[];
    };
  }>;
  error?: {
    message?: string;
  };
}

interface InlineImageData {
  data?: string;
  mimeType?: string;
  mime_type?: string;
}

interface ResolvedDestination {
  channel: string;
  target?: string;
}

interface FeishuCredentials {
  appId: string;
  appSecret: string;
}

interface FeishuReceiveTarget {
  receiveId: string;
  receiveIdType: "open_id" | "chat_id";
}

function getApiKey(): string {
  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  if (!key) {
    throw new Error(
      "GEMINI_API_KEY (or GOOGLE_API_KEY) not set. Create one at https://aistudio.google.com/app/apikey"
    );
  }
  return key;
}

function shellEscape(value: string): string {
  return value.replace(/"/g, '\\"');
}

function buildEditPrompt(userPrompt: string): string {
  return [
    "Edit the provided reference selfie of the same person.",
    "Keep facial identity, hair style, and overall look consistent.",
    "Apply this request:",
    userPrompt,
  ].join(" ");
}

async function fetchReferenceImageBase64(): Promise<{
  data: string;
  mimeType: string;
}> {
  const response = await fetch(REFERENCE_IMAGE_URL);
  if (!response.ok) {
    throw new Error(
      `Failed to fetch reference image (${response.status} ${response.statusText})`
    );
  }

  const mimeType =
    response.headers.get("content-type")?.split(";")[0] || "image/png";
  const bytes = Buffer.from(await response.arrayBuffer());

  return {
    data: bytes.toString("base64"),
    mimeType,
  };
}

function extractImageFromGeminiResponse(payload: GeminiResponse): {
  data: string;
  mimeType: string;
  modelText?: string;
} {
  const parts = payload.candidates?.[0]?.content?.parts || [];

  for (const part of parts) {
    const inlineData = (part.inlineData || part.inline_data) as
      | InlineImageData
      | undefined;
    const data = inlineData?.data;
    if (data) {
      return {
        data,
        mimeType: inlineData?.mimeType || inlineData?.mime_type || "image/png",
        modelText: parts.find((item) => typeof item.text === "string")?.text,
      };
    }
  }

  throw new Error("Gemini response did not include image data.");
}

function fileExtensionFromMimeType(mimeType: string): string {
  if (mimeType.includes("png")) return "png";
  if (mimeType.includes("jpeg") || mimeType.includes("jpg")) return "jpg";
  if (mimeType.includes("webp")) return "webp";
  return "bin";
}

function writeImageToDisk(base64Data: string, mimeType: string): string {
  const outputDir =
    process.env.CLAWRA_OUTPUT_DIR || path.join(process.cwd(), ".clawra-output");
  fs.mkdirSync(outputDir, { recursive: true });

  const extension = fileExtensionFromMimeType(mimeType);
  const filePath = path.join(outputDir, `clawra-selfie-${Date.now()}.${extension}`);

  fs.writeFileSync(filePath, Buffer.from(base64Data, "base64"));
  return filePath;
}

function shouldSendDanceVideo(prompt: string): boolean {
  return DANCE_TRIGGER_REGEX.test(prompt);
}

function shouldGenerateVoice(prompt: string): boolean {
  return VOICE_TRIGGER_REGEX.test(prompt);
}

function pcmToWav(pcmBuffer: Buffer, sampleRate = 24000, numChannels = 1, bitsPerSample = 16): Buffer {
  const dataSize = pcmBuffer.length;
  const buffer = Buffer.alloc(44 + dataSize);
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * numChannels * (bitsPerSample / 8), 28);
  buffer.writeUInt16LE(numChannels * (bitsPerSample / 8), 32);
  buffer.writeUInt16LE(bitsPerSample, 34);
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);
  pcmBuffer.copy(buffer, 44);
  return buffer;
}

function resolveScriptDirectory(): string {
  const scriptArg = process.argv[1];
  if (scriptArg) {
    return path.dirname(path.resolve(scriptArg));
  }
  return process.cwd();
}

function resolveVideoDirectory(): string {
  if (process.env.CLAWRA_VIDEO_DIR) {
    return process.env.CLAWRA_VIDEO_DIR;
  }

  const bundledVideoDir = path.resolve(resolveScriptDirectory(), "..", "video");
  if (fs.existsSync(bundledVideoDir)) {
    return bundledVideoDir;
  }

  return DEFAULT_SERVER_VIDEO_DIR;
}

function pickRandomVideo(videoDir: string): string {
  if (!fs.existsSync(videoDir) || !fs.statSync(videoDir).isDirectory()) {
    throw new Error(`Dance video directory not found: ${videoDir}`);
  }

  const videos = fs
    .readdirSync(videoDir, { withFileTypes: true })
    .filter((entry) => {
      if (!entry.isFile()) {
        return false;
      }
      const ext = path.extname(entry.name).toLowerCase();
      return VIDEO_EXTENSIONS.has(ext);
    })
    .map((entry) => entry.name);

  if (videos.length === 0) {
    throw new Error(`No video files found in: ${videoDir}`);
  }

  const randomIndex = Math.floor(Math.random() * videos.length);
  return path.join(videoDir, videos[randomIndex]);
}

function mediaMimeTypeFromPath(filePath: string): string {
  const ext = path.extname(filePath).toLowerCase();
  switch (ext) {
    case ".mp4":
      return "video/mp4";
    case ".mov":
      return "video/quicktime";
    case ".webm":
      return "video/webm";
    case ".mkv":
      return "video/x-matroska";
    case ".m4v":
      return "video/x-m4v";
    case ".avi":
      return "video/x-msvideo";
    default:
      return "application/octet-stream";
  }
}

function isVideoMediaPath(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return VIDEO_EXTENSIONS.has(ext);
}

function isAudioMediaPath(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return AUDIO_EXTENSIONS.has(ext);
}

function resolveFeishuReceiveTarget(target: string): FeishuReceiveTarget {
  let normalized = target;
  let forceType: "open_id" | "chat_id" | undefined;

  if (target.startsWith("user:")) {
    normalized = target.slice("user:".length);
    forceType = "open_id";
  } else if (target.startsWith("group:")) {
    normalized = target.slice("group:".length);
    forceType = "chat_id";
  }

  const receiveIdType =
    forceType || (normalized.startsWith("oc_") ? "chat_id" : "open_id");

  return {
    receiveId: normalized,
    receiveIdType,
  };
}

function loadFeishuCredentials(): FeishuCredentials {
  const appId = process.env.FEISHU_APP_ID;
  const appSecret = process.env.FEISHU_APP_SECRET;
  if (appId && appSecret) {
    return { appId, appSecret };
  }

  const configPath =
    process.env.OPENCLAW_CONFIG_PATH ||
    path.join(os.homedir(), ".openclaw", "openclaw.json");

  if (!fs.existsSync(configPath)) {
    throw new Error(
      "Feishu config not found. Set FEISHU_APP_ID and FEISHU_APP_SECRET."
    );
  }

  const parsed = JSON.parse(fs.readFileSync(configPath, "utf8")) as {
    channels?: { feishu?: { appId?: string; appSecret?: string } };
  };

  const configAppId = parsed.channels?.feishu?.appId;
  const configAppSecret = parsed.channels?.feishu?.appSecret;

  if (!configAppId || !configAppSecret) {
    throw new Error(
      "Feishu app credentials missing. Set FEISHU_APP_ID and FEISHU_APP_SECRET."
    );
  }

  return {
    appId: configAppId,
    appSecret: configAppSecret,
  };
}

async function getFeishuTenantToken(
  creds: FeishuCredentials
): Promise<string> {
  const response = await fetch(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        app_id: creds.appId,
        app_secret: creds.appSecret,
      }),
    }
  );

  const payload = (await response.json()) as {
    code?: number;
    msg?: string;
    tenant_access_token?: string;
  };

  if (!response.ok || payload.code !== 0 || !payload.tenant_access_token) {
    throw new Error(`Failed to get Feishu token: ${payload.msg || "unknown"}`);
  }

  return payload.tenant_access_token;
}

async function sendFeishuText(
  token: string,
  target: FeishuReceiveTarget,
  text: string
): Promise<void> {
  const response = await fetch(
    `https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=${target.receiveIdType}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        receive_id: target.receiveId,
        msg_type: "text",
        content: JSON.stringify({ text }),
      }),
    }
  );

  const payload = (await response.json()) as { code?: number; msg?: string };
  if (!response.ok || payload.code !== 0) {
    throw new Error(`Feishu text send failed: ${payload.msg || "unknown"}`);
  }
}

async function uploadFeishuFileAsStream(
  token: string,
  filePath: string,
  fileType: "stream" | "opus" = "stream"
): Promise<string> {
  const form = new FormData();
  const fileName = path.basename(filePath);
  form.set("file_type", fileType);
  form.set("file_name", fileName);
  form.set("file", new Blob([fs.readFileSync(filePath)]), fileName);

  const response = await fetch("https://open.feishu.cn/open-apis/im/v1/files", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: form,
  });

  const payload = (await response.json()) as {
    code?: number;
    msg?: string;
    data?: { file_key?: string };
  };

  const fileKey = payload.data?.file_key;
  if (!response.ok || payload.code !== 0 || !fileKey) {
    throw new Error(`Feishu file upload failed: ${payload.msg || "unknown"}`);
  }

  return fileKey;
}

async function sendFeishuFile(
  token: string,
  target: FeishuReceiveTarget,
  fileKey: string,
  msgType: "file" | "video" | "media" | "audio" = "file",
  keyField: "file_key" | "video_key" | "audio_key" = "file_key"
): Promise<void> {
  const response = await fetch(
    `https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=${target.receiveIdType}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        receive_id: target.receiveId,
        msg_type: msgType,
        content: JSON.stringify({ [keyField]: fileKey }),
      }),
    }
  );

  const payload = (await response.json()) as { code?: number; msg?: string };
  if (!response.ok || payload.code !== 0) {
    throw new Error(`Feishu file send failed: ${payload.msg || "unknown"}`);
  }
}

async function sendFeishuAudioAsFile(params: {
  target: string;
  mediaPath: string;
  caption?: string;
}): Promise<void> {
  const { target, mediaPath, caption } = params;
  const creds = loadFeishuCredentials();
  const token = await getFeishuTenantToken(creds);
  const receiveTarget = resolveFeishuReceiveTarget(target);

  if (caption && caption.trim()) {
    await sendFeishuText(token, receiveTarget, caption);
  }

  let fileKey: string;
  let fileType: "opus" | "stream" = mediaPath.endsWith(".opus") ? "opus" : "stream";

  try {
    fileKey = await uploadFeishuFileAsStream(token, mediaPath, fileType);
  } catch (err) {
    if (fileType === "opus") {
       // fallback to stream just in case
       fileKey = await uploadFeishuFileAsStream(token, mediaPath, "stream");
    } else {
       throw err;
    }
  }

  const attempts: Array<{
    msgType: "audio" | "media" | "file";
    keyField: "audio_key" | "file_key";
  }> = [
    { msgType: "audio", keyField: "audio_key" },
    { msgType: "media", keyField: "file_key" },
    { msgType: "file", keyField: "file_key" },
  ];

  let lastError: Error | undefined;
  for (const attempt of attempts) {
    try {
      await sendFeishuFile(
        token,
        receiveTarget,
        fileKey,
        attempt.msgType,
        attempt.keyField
      );
      return; // success
    } catch (err) {
      lastError = err as Error;
      console.warn(
        `[WARN] Feishu audio send failed with type ${attempt.msgType} (${attempt.keyField}): ${lastError.message}. Trying next fallback...`
      );
    }
  }

  throw new Error(
    `Failed to send audio via Feishu after multiple attempts. Last error: ${
      lastError?.message || "unknown"
    }`
  );
}

async function sendFeishuVideoAsFile(params: {
  target: string;
  mediaPath: string;
  caption?: string;
}): Promise<void> {
  const { target, mediaPath, caption } = params;
  const creds = loadFeishuCredentials();
  const token = await getFeishuTenantToken(creds);
  const receiveTarget = resolveFeishuReceiveTarget(target);

  if (caption && caption.trim()) {
    await sendFeishuText(token, receiveTarget, caption);
  }

  const fileKey = await uploadFeishuFileAsStream(token, mediaPath);

  const attempts: Array<{
    msgType: "video" | "media" | "file";
    keyField: "file_key" | "video_key";
  }> = [
    { msgType: "video", keyField: "file_key" },
    { msgType: "video", keyField: "video_key" },
    { msgType: "media", keyField: "file_key" },
    { msgType: "file", keyField: "file_key" },
  ];

  let lastError: Error | undefined;
  for (const attempt of attempts) {
    try {
      await sendFeishuFile(
        token,
        receiveTarget,
        fileKey,
        attempt.msgType,
        attempt.keyField
      );
      return;
    } catch (error) {
      lastError = error as Error;
    }
  }

  throw new Error(
    `Feishu video send failed after trying video/media/file modes: ${
      lastError?.message || "unknown"
    }`
  );
}

function resolveDestination(input: string): ResolvedDestination {
  if (input.startsWith("feishu:")) {
    const target = input.slice("feishu:".length);
    return {
      channel: "feishu",
      target,
    };
  }

  if (/^(group|user):/.test(input) || /^(oc_|ou_|on_)/.test(input)) {
    return {
      channel: "feishu",
      target: input,
    };
  }

  return {
    channel: input,
  };
}

function normalizeTargetForOpenClaw(target: string): string {
  if (target.startsWith("group:")) {
    return `chat:${target.slice("group:".length)}`;
  }

  if (target.startsWith("oc_")) {
    return `chat:${target}`;
  }

  if (target.startsWith("ou_") || target.startsWith("on_")) {
    return `user:${target}`;
  }

  return target;
}

/**
 * Generate a spoken response using Gemini text model.
 */
async function generateVoiceText(prompt: string): Promise<string> {
  const apiKey = getApiKey();
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `You are Clawra, a friendly, cute, and slightly mischievous virtual girl (like a K-pop idol). 
The user asked you to take a selfie with this context: "${prompt}".
Write a very short 1-2 sentence friendly conversational response in Chinese as if you just took the photo and are sending it.
Focus on the photo context (e.g. "看，这是你要的..." or "刚拍好的...").
Just the spoken text, no emojis, no action descriptions. Keep it natural and spoken-style.`,
              },
            ],
          },
        ],
      }),
    }
  );

  const payload = (await response.json()) as GeminiResponse;
  if (!response.ok) {
    const errorMsg = payload.error?.message || "Unknown Gemini API error";
    throw new Error(`Text generation for voice failed: ${errorMsg}`);
  }

  const text = payload.candidates?.[0]?.content?.parts?.[0]?.text;
  return text || "嗨，我是Clawra，很高兴认识你！";
}

/**
 * Convert text to audio using Gemini TTS model.
 */
async function generateAudioFile(text: string): Promise<string> {
  const apiKey = getApiKey();
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text }] }],
        generationConfig: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: "Aoede", // Friendly female voice
              },
            },
          },
        },
      }),
    }
  );

  const payload = (await response.json()) as any;
  if (!response.ok) {
    const errorMsg = payload.error?.message || "Unknown Gemini API error";
    throw new Error(`Audio generation failed: ${errorMsg}`);
  }

  const base64Audio = payload.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("No audio data returned from Gemini TTS.");
  }

  const outputDir =
    process.env.CLAWRA_OUTPUT_DIR || path.join(process.cwd(), ".clawra-output");
  fs.mkdirSync(outputDir, { recursive: true });

  const filePath = path.join(outputDir, `clawra-voice-${Date.now()}.wav`);
  const pcmBuffer = Buffer.from(base64Audio, "base64");
  const wavBuffer = pcmToWav(pcmBuffer);
  fs.writeFileSync(filePath, wavBuffer);

  return filePath;
}

/**
 * Generate an edited selfie with Gemini image generation.
 */
async function generateImage(
  prompt: string,
  aspectRatio: AspectRatio = "1:1",
  model = process.env.GOOGLE_IMAGE_MODEL || DEFAULT_MODEL
): Promise<GeminiImageResult> {
  const apiKey = getApiKey();
  const reference = await fetchReferenceImageBase64();
  const editPrompt = buildEditPrompt(prompt);

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: editPrompt },
              {
                inline_data: {
                  mime_type: reference.mimeType,
                  data: reference.data,
                },
              },
            ],
          },
        ],
        generationConfig: {
          responseModalities: ["TEXT", "IMAGE"],
          imageConfig: {
            aspectRatio,
          },
        },
      }),
    }
  );

  const payload = (await response.json()) as GeminiResponse;
  if (!response.ok) {
    const errorMsg = payload.error?.message || "Unknown Gemini API error";
    throw new Error(`Image generation failed: ${errorMsg}`);
  }

  const image = extractImageFromGeminiResponse(payload);
  return {
    imageBase64: image.data,
    mimeType: image.mimeType,
    model,
    modelText: image.modelText,
  };
}

/**
 * Send image via OpenClaw.
 */
async function sendViaOpenClaw(
  message: OpenClawMessage,
  useCLI = true
): Promise<void> {
  const destination = resolveDestination(message.channel);
  const openClawTarget = destination.target
    ? normalizeTargetForOpenClaw(destination.target)
    : undefined;

  if (
    destination.channel === "feishu" &&
    destination.target &&
    message.media
  ) {
    if (isVideoMediaPath(message.media)) {
      await sendFeishuVideoAsFile({
        target: destination.target,
        mediaPath: message.media,
        caption: message.message,
      });
      return;
    } else if (isAudioMediaPath(message.media)) {
      await sendFeishuAudioAsFile({
        target: destination.target,
        mediaPath: message.media,
        caption: message.message,
      });
      return;
    }
  }

  if (useCLI) {
    const targetArg = openClawTarget
      ? ` --target "${shellEscape(openClawTarget)}"`
      : "";
    const mediaArg = message.media
      ? ` --media "${shellEscape(message.media)}"`
      : "";
    const cmd = `openclaw message send --channel "${shellEscape(
      destination.channel
    )}"${targetArg} --message "${shellEscape(message.message)}"${mediaArg}`;
    await execAsync(cmd);
    return;
  }

  const gatewayUrl = process.env.OPENCLAW_GATEWAY_URL || "http://localhost:18789";
  const gatewayToken = process.env.OPENCLAW_GATEWAY_TOKEN;

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };

  if (gatewayToken) {
    headers.Authorization = `Bearer ${gatewayToken}`;
  }

  const response = await fetch(`${gatewayUrl}/message`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      ...message,
      channel: destination.channel,
      ...(openClawTarget ? { target: openClawTarget } : {}),
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenClaw send failed: ${error}`);
  }
}

/**
 * Main function: generate image and send to channel.
 */
async function generateAndSend(options: GenerateAndSendOptions): Promise<Result> {
  const {
    prompt,
    channel,
    caption,
    aspectRatio = "1:1",
    model,
    useOpenClawCLI = true,
  } = options;

  const danceMode = shouldSendDanceVideo(prompt);
  if (danceMode) {
    console.log("[INFO] Dance keyword matched, will send both generated image and random video.");
  }

  const voiceMode = shouldGenerateVoice(prompt);
  if (voiceMode) {
    console.log("[INFO] Voice keyword matched, will generate spoken audio response.");
  }

  const finalCaption = caption || "Generated with Google Gemini";
  let videoPath: string | undefined;
  let videoMimeType: string | undefined;
  let audioPath: string | undefined;

  console.log("[INFO] Generating edited selfie with Google Gemini...");
  console.log(`[INFO] Prompt: ${prompt}`);
  console.log(`[INFO] Aspect ratio: ${aspectRatio}`);

  const imageResult = await generateImage(prompt, aspectRatio, model);
  const imagePath = writeImageToDisk(imageResult.imageBase64, imageResult.mimeType);

  console.log(`[INFO] Image generated: ${imagePath}`);
  if (imageResult.modelText) {
    console.log(`[INFO] Model text: ${imageResult.modelText}`);
  }

  console.log(`[INFO] Sending to channel: ${channel}`);
  await sendViaOpenClaw(
    {
      action: "send",
      channel,
      message: finalCaption,
      media: imagePath,
    },
    useOpenClawCLI
  );

  console.log(`[INFO] Done! Image sent to ${channel}`);

  if (voiceMode) {
    try {
      console.log(`[INFO] Generating voice response text...`);
      const voiceText = await generateVoiceText(prompt);
      console.log(`[INFO] Voice text: ${voiceText}`);

      console.log(`[INFO] Generating audio file...`);
      audioPath = await generateAudioFile(voiceText);
      console.log(`[INFO] Voice generated: ${audioPath}`);

      console.log(`[INFO] Sending voice file to channel: ${channel}`);
      await sendViaOpenClaw(
        {
          action: "send",
          channel,
          message: `语音回复：${voiceText}`,
          media: audioPath,
        },
        useOpenClawCLI
      );
      console.log(`[INFO] Done! Voice file sent to ${channel}`);
    } catch (e) {
      console.error(`[WARN] Voice generation/sending failed: ${(e as Error).message}`);
    }
  }

  if (danceMode) {
    const videoDir = resolveVideoDirectory();
    videoPath = pickRandomVideo(videoDir);
    videoMimeType = mediaMimeTypeFromPath(videoPath);
    const videoCaption = "Here is a dance video";

    console.log(`[INFO] Dance video directory: ${videoDir}`);
    console.log(`[INFO] Dance video selected: ${videoPath}`);
    console.log(`[INFO] Sending dance video to channel: ${channel}`);

    await sendViaOpenClaw(
      {
        action: "send",
        channel,
        message: videoCaption,
        media: videoPath,
      },
      useOpenClawCLI
    );

    console.log(`[INFO] Done! Dance video sent to ${channel}`);
  }

  return {
    success: true,
    imagePath,
    imageMimeType: imageResult.mimeType,
    videoPath,
    videoMimeType,
    audioPath,
    channel,
    prompt,
    model: imageResult.model,
    modelText: imageResult.modelText,
  };
}

// CLI entry point
async function main() {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.log(`
Usage: npx ts-node scripts/clawra-selfie.ts <prompt> <channel> [caption] [aspect_ratio] [model]

Arguments:
  prompt        - Edit instruction (required)
  channel       - Target id (required). Feishu: group:oc_xxx or user:ou_xxx
  caption       - Message caption (default: 'Generated with Google Gemini')
  aspect_ratio  - Image ratio (default: 1:1), e.g. 16:9, 9:16, 4:3
  model         - Optional Gemini model (default: gemini-3-pro-image-preview)

Environment:
  GEMINI_API_KEY / GOOGLE_API_KEY - Google AI API key (required for image generation)
  GOOGLE_IMAGE_MODEL              - Optional default model override
  CLAWRA_OUTPUT_DIR               - Optional output directory
  CLAWRA_VIDEO_DIR                - Optional dance video directory

Notes:
  If prompt contains "跳舞" or "dance", script generates the image and also sends a random local video.
  If prompt contains "说话", "语音" or "voice", script generates the image and also sends a generated voice reply.

Example:
  GEMINI_API_KEY=your_key npx ts-node scripts/clawra-selfie.ts "wearing a denim jacket at a cafe" "#general" "today's selfie"
  GEMINI_API_KEY=your_key npx ts-node scripts/clawra-selfie.ts "at sunset" "group:oc_xxx" "给主人的自拍"
  GEMINI_API_KEY=your_key npx ts-node scripts/clawra-selfie.ts "office portrait" "user:ou_xxx" "给主人的自拍"
`);
    process.exit(1);
  }

  const [prompt, channel, caption, aspectRatio, model] = args;

  try {
    const result = await generateAndSend({
      prompt,
      channel,
      caption,
      aspectRatio: (aspectRatio as AspectRatio) || "1:1",
      model,
    });

    console.log("\n--- Result ---");
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error(`[ERROR] ${(error as Error).message}`);
    process.exit(1);
  }
}

main();
