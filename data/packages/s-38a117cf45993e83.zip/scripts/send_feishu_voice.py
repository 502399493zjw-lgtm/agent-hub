import os
import sys
import json
import subprocess
import requests

# Configuration
APP_ID = os.environ.get("FEISHU_APP_ID", "cli_a90bdb509e395bb3")
APP_SECRET = os.environ.get("FEISHU_APP_SECRET", "0mQU3JixOYI147iTprFqjhuCqJhYL6Kn")

def get_tenant_access_token():
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json; charset=utf-8"}
    data = {
        "app_id": APP_ID,
        "app_secret": APP_SECRET
    }
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        return response.json().get("tenant_access_token")
    except Exception as e:
        print(f"Error getting token: {e}")
        return None

def convert_to_opus(input_path):
    if not os.path.exists(input_path) or os.path.getsize(input_path) == 0:
        print(f"Error: Input file {input_path} is missing or empty.")
        return None

    output_path = os.path.splitext(input_path)[0] + ".opus"
    # Overwrite if exists (-y)
    cmd = [
        "ffmpeg", "-y", "-i", input_path,
        "-c:a", "libopus", "-b:a", "16k",
        "-vbr", "on", "-compression_level", "10",
        output_path
    ]
    try:
        # Capture stderr for debugging
        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return output_path
    except subprocess.CalledProcessError as e:
        print(f"FFmpeg conversion failed (Code {e.returncode}):")
        print(e.stderr) # Print the actual error from FFmpeg
        return None

def upload_file(token, file_path, duration_ms=3000):
    url = "https://open.feishu.cn/open-apis/im/v1/files"
    headers = {"Authorization": f"Bearer {token}"}
    
    file_name = os.path.basename(file_path)
    
    # Multipart upload
    try:
        with open(file_path, "rb") as f:
            files = {
                "file": (file_name, f, "application/octet-stream")
            }
            data = {
                "file_type": "opus",
                "file_name": file_name,
                "duration": duration_ms
            }
            response = requests.post(url, headers=headers, data=data, files=files)
            response.raise_for_status()
            res_json = response.json()
            if res_json.get("code") != 0:
                print(f"Upload API error: {res_json}")
                return None
            return res_json.get("data", {}).get("file_key")
    except Exception as e:
        print(f"Upload failed: {e}")
        return None

def send_audio_message(token, receive_id, file_key):
    # Determine receive_id_type based on prefix
    receive_id_type = "chat_id" # Default
    real_id = receive_id
    
    if receive_id.startswith("chat:"):
        receive_id_type = "chat_id"
        real_id = receive_id[5:]
    elif receive_id.startswith("user:"):
        receive_id_type = "open_id" # Assuming open_id for users mostly
        real_id = receive_id[5:]
    elif receive_id.startswith("ou_"):
        receive_id_type = "open_id"
    elif receive_id.startswith("oc_"):
        receive_id_type = "chat_id"

    url = f"https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type={receive_id_type}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8"
    }
    
    content = json.dumps({"file_key": file_key})
    data = {
        "receive_id": real_id,
        "msg_type": "audio",
        "content": content
    }
    
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        print(json.dumps(response.json(), indent=2))
    except Exception as e:
        print(f"Send message failed: {e}")

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 send_feishu_voice.py <audio_file_path> <target_id>")
        sys.exit(1)

    audio_path = sys.argv[1]
    target_id = sys.argv[2]

    if not os.path.exists(audio_path):
        print(f"File not found: {audio_path}")
        sys.exit(1)

    print(f"Processing audio: {audio_path}")
    
    # 1. Convert if not opus
    opus_path = audio_path
    if not audio_path.endswith(".opus"):
        print("Converting to OPUS...")
        opus_path = convert_to_opus(audio_path)
        if not opus_path:
            sys.exit(1)

    # 2. Get Token
    token = get_tenant_access_token()
    if not token:
        sys.exit(1)

    # 3. Upload
    print("Uploading to Feishu...")
    file_key = upload_file(token, opus_path)
    if not file_key:
        sys.exit(1)
        
    # 4. Send
    print(f"Sending audio to {target_id}...")
    send_audio_message(token, target_id, file_key)

if __name__ == "__main__":
    main()
