#!/bin/bash
# update-gallery.sh
# Automatically update clawra-gallery when new Clawra images are generated

set -euo pipefail

GALLERY_DIR="${CLAWRA_GALLERY_DIR:-/root/.openclaw/workspace/clawra-gallery}"
GALLERY_REPO="${CLAWRA_GALLERY_REPO:-https://github.com/Readarkclub/clawra-gallery.git}"
IMAGE_PATH="$1"
IMAGE_FILENAME=$(basename "$IMAGE_PATH")

# Check if gallery directory exists
if [ ! -d "$GALLERY_DIR" ]; then
  echo "Gallery directory not found: $GALLERY_DIR"
  exit 1
fi

# Check if image exists
if [ ! -f "$IMAGE_PATH" ]; then
  echo "Image not found: $IMAGE_PATH"
  exit 1
fi

echo "Updating gallery with new image: $IMAGE_FILENAME"

# Copy image to gallery
cp "$IMAGE_PATH" "$GALLERY_DIR/$IMAGE_FILENAME"
echo "✓ Image copied to gallery"

# Update index.html
INDEX_FILE="$GALLERY_DIR/index.html"
if [ ! -f "$INDEX_FILE" ]; then
  echo "index.html not found"
  exit 1
fi

# Get current timestamp
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
DATE_DISPLAY=$(date '+%Y年%m月%d日 %H:%M')

# Extract scene description from filename or use default
SCENE_DESC="Clawra的新自拍"
if [[ "$IMAGE_FILENAME" =~ morning ]]; then
  SCENE_DESC="清晨的自拍 ☀️"
elif [[ "$IMAGE_FILENAME" =~ night ]]; then
  SCENE_DESC="夜晚的自拍 🌙"
elif [[ "$IMAGE_FILENAME" =~ dance ]]; then
  SCENE_DESC="跳舞的自拍 💃"
fi

# Create new image HTML block using the original photo-card structure
NEW_IMAGE_BLOCK="            <!-- Auto-generated photo: $TIMESTAMP -->
            <div class=\"photo-card\">
                <img src=\"$IMAGE_FILENAME\" alt=\"Clawra Selfie\">
                <div class=\"caption\">
                    <p>$SCENE_DESC</p>
                </div>
                <div class=\"timestamp\">$DATE_DISPLAY</div>
            </div>"

# Insert new image at the beginning of gallery (after the opening gallery tag)
# Find the line with <div class="gallery"> and insert after it
# Use awk instead of sed for multiline insert
awk -v block="$NEW_IMAGE_BLOCK" '
/<div class="gallery">/ {
    print $0
    print block
    next
}
{ print }
' "$INDEX_FILE" > "$INDEX_FILE.tmp" && mv "$INDEX_FILE.tmp" "$INDEX_FILE"

echo "✓ index.html updated"

# Git operations
cd "$GALLERY_DIR"

# Check if there are changes
if git diff --quiet && git diff --staged --quiet; then
  echo "No changes to commit"
  exit 0
fi

# Add changes
git add "$IMAGE_FILENAME" index.html

# Commit
git commit -m "feat: Add new Clawra selfie - $IMAGE_FILENAME"

# Push to GitHub
git push origin master

echo "✓ Changes pushed to GitHub"
echo "✓ Gallery will auto-deploy on Vercel"
echo ""
echo "View at: https://clawra-gallery.vercel.app"

# Send notification to Feishu group
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

log "Sending notification to Feishu group..."

# Get Feishu access token
FEISHU_TOKEN=$(curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
    -H "Content-Type: application/json" \
    -d '{"app_id":"cli_a90bdb509e395bb3","app_secret":"0mQU3JixOYI147iTprFqjhuCqJhYL6Kn"}' \
    | jq -r '.tenant_access_token')

if [ -z "$FEISHU_TOKEN" ] || [ "$FEISHU_TOKEN" = "null" ]; then
    log "✗ Failed to get Feishu token"
    exit 0
fi

# Build message content
MESSAGE_TEXT="📸 **Clawra Gallery已更新！**

$SCENE_DESC
📅 $DATE_DISPLAY

🔗 查看: https://clawra-gallery.vercel.app"

MESSAGE_JSON=$(jq -n --arg msg "$MESSAGE_TEXT" '{text: $msg}')

# Send message to Feishu group
curl -s -X POST "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id" \
    -H "Authorization: Bearer $FEISHU_TOKEN" \
    -H "Content-Type: application/json" \
    -d "$(jq -n \
        --arg chat "oc_46a813437a5efb4e366c6449a5a9cc20" \
        --argjson content "$MESSAGE_JSON" \
        '{
            receive_id: $chat,
            msg_type: "text",
            content: ($content | tojson)
        }')" | jq -r '.code' | grep -q "0" && log "✓ Feishu notification sent" || log "✗ Failed to send Feishu notification"
