import os
import sys
import json
import subprocess
import requests

# Configuration
APP_ID = os.environ.get("FEISHU_APP_ID", "cli_a90bdb509e395bb3")
APP_SECRET = os.environ.get("FEISHU_APP_SECRET", "0mQU3JixOYI147iTprFqjhuCqJhYL6Kn")

def get_tenant_access_token():
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    headers = {"Content-Type": "application/json; charset=utf-8"}
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        return response.json().get("tenant_access_token")
    except Exception as e:
        print(f"Error getting token: {e}")
        return None

def extract_cover_image(video_path):
    # Extract first frame as cover image
    cover_path = os.path.splitext(video_path)[0] + "_cover.jpg"
    cmd = [
        "ffmpeg", "-y", "-i", video_path,
        "-ss", "00:00:00.000", "-vframes", "1",
        cover_path
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if os.path.exists(cover_path):
            return cover_path
        return None
    except subprocess.CalledProcessError as e:
        print(f"FFmpeg cover extraction failed: {e}")
        return None

def upload_file(token, file_path, file_type):
    url = "https://open.feishu.cn/open-apis/im/v1/files"
    headers = {"Authorization": f"Bearer {token}"}
    file_name = os.path.basename(file_path)
    
    try:
        with open(file_path, "rb") as f:
            files = {"file": (file_name, f, "application/octet-stream")}
            data = {"file_type": file_type, "file_name": file_name}
            response = requests.post(url, headers=headers, data=data, files=files)
            response.raise_for_status()
            res_json = response.json()
            if res_json.get("code") != 0:
                print(f"Upload {file_type} error: {res_json}")
                return None
            
            # Return image_key for images, file_key for other files
            data = res_json.get("data", {})
            return data.get("image_key") if file_type == "image" else data.get("file_key")
    except Exception as e:
        print(f"Upload {file_type} failed: {e}")
        return None

def upload_image(token, image_path):
    url = "https://open.feishu.cn/open-apis/im/v1/images"
    headers = {"Authorization": f"Bearer {token}"}
    
    try:
        with open(image_path, "rb") as f:
            files = {"image": f}
            data = {"image_type": "message"}
            response = requests.post(url, headers=headers, data=data, files=files)
            response.raise_for_status()
            res_json = response.json()
            if res_json.get("code") != 0:
                print(f"Upload image error: {res_json}")
                return None
            return res_json.get("data", {}).get("image_key")
    except Exception as e:
        print(f"Upload image failed: {e}")
        return None

def send_video_message(token, receive_id, file_key, image_key):
    # Determine receive_id_type
    receive_id_type = "chat_id"
    real_id = receive_id
    
    if receive_id.startswith("chat:"):
        receive_id_type = "chat_id"
        real_id = receive_id[5:]
    elif receive_id.startswith("user:"):
        receive_id_type = "open_id"
        real_id = receive_id[5:]
    elif receive_id.startswith("ou_"):
        receive_id_type = "open_id"
    elif receive_id.startswith("oc_"):
        receive_id_type = "chat_id"

    url = f"https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type={receive_id_type}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8"
    }
    
    content = json.dumps({"file_key": file_key, "image_key": image_key})
    data = {
        "receive_id": real_id,
        "msg_type": "media",
        "content": content
    }
    
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        print(json.dumps(response.json(), indent=2))
    except Exception as e:
        if hasattr(e, 'response') and e.response is not None:
             print(f"Send video message failed: {e.response.text}")
        else:
             print(f"Send video message failed: {e}")

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 send_feishu_video.py <video_file_path> <target_id>")
        sys.exit(1)

    video_path = sys.argv[1]
    target_id = sys.argv[2]

    if not os.path.exists(video_path):
        print(f"File not found: {video_path}")
        sys.exit(1)

    print(f"Processing video: {video_path}")
    
    # 1. Get Token
    token = get_tenant_access_token()
    if not token:
        sys.exit(1)

    # 2. Extract Cover
    print("Extracting cover image...")
    cover_path = extract_cover_image(video_path)
    if not cover_path:
        print("Failed to extract cover image. Video send may fail.")
        # Try to continue? No, media message requires image_key.
        sys.exit(1)

    # 3. Upload Video (mp4 for media message)
    print("Uploading video file...")
    # Feishu file upload for media/stream
    file_key = upload_file(token, video_path, "mp4") 
    if not file_key:
        sys.exit(1)

    # 4. Upload Cover Image
    print("Uploading cover image...")
    image_key = upload_image(token, cover_path)
    if not image_key:
        sys.exit(1)

    # 5. Send Message
    print(f"Sending video to {target_id}...")
    send_video_message(token, target_id, file_key, image_key)

    # Cleanup cover image
    if os.path.exists(cover_path):
        os.remove(cover_path)

if __name__ == "__main__":
    main()
