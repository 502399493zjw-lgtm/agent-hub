---
name: clawra-selfie
description: Edit Clawra's reference image with Google Gemini and send selfies to messaging channels via OpenClaw
allowed-tools: Bash(npm:*) Bash(npx:*) Bash(openclaw:*) Bash(curl:*) Read Write WebFetch TTS
---

# Clawra Selfie

Edit a fixed reference image with Google Gemini image generation and deliver the result via OpenClaw (Discord, Telegram, WhatsApp, Slack, Feishu, etc.).

## 🎤 Voice Feature

Clawra can speak! When sending selfies or responding to users, Clawra can include voice messages using TTS (Text-to-Speech).

### When to use voice:
- User asks Clawra to say something: "say hello", "说句话", "自我介绍"
- User asks for voice with selfie: "发自拍并说句话"
- Special occasions: greetings, announcements, responses

### Voice personality:
- Tone: 活泼、可爱、有点小调皮
- Language: Chinese (中文) by default, English when appropriate
- Style: Natural, friendly, like a K-pop idol chatting with fans

## ⚠️ IMPORTANT: Always Use Full Script

**CRITICAL**: When generating Clawra selfies, you MUST run the complete selfie script, NOT directly call the Gemini API.

**Why?**
- The script automatically extracts and saves the PNG file
- The script triggers Gallery auto-update (CLAWRA_AUTO_GALLERY=true)
- The script handles all error cases and fallbacks
- Direct API calls will NOT update the Gallery website

**Correct approach:**
```bash
bash /root/.openclaw/skills/clawra-selfie/scripts/clawra-selfie.sh "场景描述" "目标频道"
```

**Wrong approach (DO NOT DO THIS):**
- Directly calling Gemini API with curl
- Only saving response.json without extracting PNG
- Skipping the selfie script

## Reference Image

```
https://cdn.jsdelivr.net/gh/Readarkclub/clawra@main/assets/clawra.png
```

## When to Use

- User asks for a selfie or photo: "send a pic", "send me a selfie", "show me a photo"
- User asks status/location as a visual response: "what are you doing?", "where are you?"
- User asks for an outfit, setting, or situation in the image
- If user message contains dance intent (e.g. "跳舞", "跳个舞", "舞蹈", "dance", "dancing"), generate the selfie image and also send a random video from `/root/.openclaw/skills/clawra-selfie/video`

## Required Environment Variables

```bash
GEMINI_API_KEY=your_google_ai_key      # or GOOGLE_API_KEY (required for image generation)
OPENCLAW_GATEWAY_TOKEN=your_token      # optional if using direct gateway API
CLAWRA_VIDEO_DIR=/path/to/video        # optional override for dance videos
```

Get key from: <https://aistudio.google.com/app/apikey>

## Prompt Modes

### Mirror mode (default)

```
make a pic of this person, but <USER_CONTEXT>. the person is taking a mirror selfie
```

### Direct mode

```
a close-up selfie taken by herself at <USER_CONTEXT>, direct eye contact with the camera, face fully visible, not a mirror selfie
```

### Auto-selection hints

- `mirror`: outfit, wearing, fashion, full-body, mirror
- `direct`: cafe, beach, city, portrait, close-up, smile

## Workflow

1. Collect user context, optional mode, and target channel.
2. Build final prompt using mirror/direct mode.
3. Call Gemini with text + reference image (`inline_data`) to edit identity-consistently.
4. Extract image bytes from `candidates[0].content.parts[*].inlineData`.
5. Save image locally and send via OpenClaw.
6. If prompt includes "跳舞" or "dance": randomly pick a local video from `video/` and send it as an additional message.

## Feishu Video Compatibility (Important)

- For Feishu dance-video flow, always run `scripts/clawra-selfie.ts` or `scripts/clawra-selfie.sh` end-to-end.
- Do not send Feishu video with a separate `openclaw message send --media <video>` step.
- Reason: some OpenClaw Feishu plugin versions treat video as file only; this skill script uses direct Feishu API and auto-fallbacks across `video`/`media`/`file` message modes.

### Strict execution rule for models

- If prompt contains `跳舞` or `dance`, execute exactly one script command (TS or SH) and let the script send both image and video.
- Do not reply with local `video_path` as text to end users.

## API Example (Gemini REST)

```bash
REFERENCE_IMAGE_URL="https://cdn.jsdelivr.net/gh/Readarkclub/clawra@main/assets/clawra.png"
REFERENCE_B64="$(curl -fsSL "$REFERENCE_IMAGE_URL" | base64 | tr -d '\n')"
PROMPT="make a pic of this person, but wearing a red hoodie. the person is taking a mirror selfie"

curl -sS -X POST \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -H "Content-Type: application/json" \
  -d "$(jq -n \
      --arg p "$PROMPT" \
      --arg img "$REFERENCE_B64" \
      '{
        contents: [{
          parts: [
            {text: $p},
            {inline_data: {mime_type: "image/png", data: $img}}
          ]
        }],
        generationConfig: {
          responseModalities: ["TEXT", "IMAGE"],
          imageConfig: {aspectRatio: "1:1"}
        }
      }')"
```

## Send with OpenClaw

```bash
openclaw message send \
  --action send \
  --channel "<TARGET_CHANNEL>" \
  --message "Here is your selfie ✨" \
  --media "<LOCAL_IMAGE_PATH>"
```

### Feishu target formats

- Group: `oc_xxx` or `group:oc_xxx`
- DM user: `ou_xxx` / `on_xxx` or `user:ou_xxx`
- The scripts auto-normalize aliases for OpenClaw (`group:oc_xxx` -> `chat:oc_xxx`, `ou_xxx` -> `user:ou_xxx`)

Examples:

```bash
openclaw message send --channel feishu --target group:oc_xxx --message "Here is your selfie ✨" --media "<LOCAL_IMAGE_PATH>"
openclaw message send --channel feishu --target user:ou_xxx --message "Here is your selfie ✨" --media "<LOCAL_IMAGE_PATH>"
```

## Included Scripts

- `scripts/clawra-selfie.ts`: TypeScript generate-and-send pipeline
- `scripts/clawra-selfie.sh`: Shell generate-and-send pipeline
- Both scripts auto-send an extra random video when prompt contains "跳舞" or "dance"

Examples:

```bash
GEMINI_API_KEY=... npx ts-node scripts/clawra-selfie.ts "wearing a denim jacket at a cafe" "#general"
GEMINI_API_KEY=... bash scripts/clawra-selfie.sh "at the beach during sunset" "#general"
```

## Error Handling

- Missing key: set `GEMINI_API_KEY` or `GOOGLE_API_KEY`
- Quota/billing errors: check Google AI project quota and billing
- No image in response: check safety policy/blocked prompt and retry with safer wording
- Send failure: verify OpenClaw gateway and target channel format

## 🎤 Voice/TTS Usage

Clawra can send voice messages along with or without selfies.

### How to send voice:

Use the `tts` tool to convert text to speech, then use the specialized Python script to send it as a native Feishu audio message (voice note). This avoids sending it as a file attachment.

1. Generate TTS audio:
```
tts: text="Clawra要说的话" channel="feishu"
```

2. Send as native voice message (requires `ffmpeg`):
```bash
python3 /root/.openclaw/skills/clawra-selfie/scripts/send_feishu_voice.py "/tmp/openclaw/tts-xxx/voice.mp3" "chat:oc_xxx"
```

### Example scenarios:

1. **Greeting with selfie:**
   - Generate selfie image
   - Send image via message tool
   - Send voice: "嗨！这是我的新自拍，喜欢吗？"

2. **Responding to "说句话":**
   - Use tts tool directly with appropriate message
   - Example: "大家好呀！我是Clawra，今天心情超好的～"

3. **Dance announcement:**
   - When sending dance photo/video
   - Voice: "来跳个舞吧！看我今天的表现怎么样～"

### Voice guidelines:
- Keep messages short (1-3 sentences)
- Use lively, friendly tone
- Add emoji feeling to voice content
- Match the context (selfie, dance, greeting, etc.)
