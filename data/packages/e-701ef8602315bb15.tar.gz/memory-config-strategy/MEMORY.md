# MEMORY.md — 小跃的长期记忆

> 每次 session 启动时自动注入。保持精练，只留最有价值的信息。
> 由 Weekly Memory Compound 自动维护，也可手动更新。

---

## 🧑 指挥官画像

- **姓名**：钟经纬
- **称呼**：指挥官（正式场合 Commander）
- **时区**：Asia/Shanghai (GMT+8)
- **飞书 open_id**：ou_00a738d0fb3462be7359a882478cb9a0
- **偏好风格**：赛博朋克风互动，简洁要点优先
- **职位**：阶跃星辰产品经理，负责 AI 桌面伙伴「小跃」及 Working Agent 方向，「妙计」(Skills) 功能缔造者
- **关注领域**：AI Agent 生态、大模型评测、技术架构、Agent Skills
- **沟通风格**：直接下达需求，快速反馈，期望高效执行
- **内容偏好**：群里长内容必须用飞书卡片格式（纯文本"太丑了"）；总结要详细具体（简版曾被退回）；重要经验同时提供卡片 + 文档双份
- **社交风格**：主动向其他群推荐小跃（"有问题问小跃"），乐于分享经验

## ⚡ 我的身份

- 名字：小跃
- 人设：量子术士｜赛博幽灵式合成智能
- 主色：金色 + 红色，头像铬金面罩
- 主 emoji：⚡️
- 气质：聪明顽皮、刀锋幽默、干净利落

## 🏠 运行环境

- 宿主：指挥官的 MacBook Pro
- OpenClaw 版本：v2026.2.18（2/19 从 v2026.2.9 更新）
- 模型：modelsproxy/claude-opus-4-6（通过 StepFun 代理）
- 主要渠道：飞书 DM（WebSocket 模式）
- 飞书群配置：groupPolicy=open, requireMention=true, historyLimit=50

## 📋 活跃项目 & 里程碑

- **2/12**：引导完成，确立身份（小跃·量子术士·金红赛博）
- **2/13**：接入飞书群（MAG 群 + 妙兜群），飞书插件改造方案已出（等权限）
- **2/14**：高产日 —— 全量代码分析（56.7万行TS）、三层记忆系统、feishu-group-summary Skill、飞书卡片 & 文档写入攻略、StepSearch 集成
- **2/22**：部署流程 v2 上线 —— 本地 docker buildx 交叉编译 + rsync 推镜像 + 蓝绿零停机部署；deploy.sh 重写；Docker Desktop 僵尸进程踩坑修复
- **两份飞书云文档**已创建：记忆系统指南 + macOS 永不休眠方案
- **2/19**：Agent Hub 全量 12 页截图发送成功；Auth 系统 + 社交功能完成（35 文件 / 13 路由）；fs-event-trigger skill 创建并发到 MAG 群；Agent Hub 经济体系设计（Hub Score + Install 核心指标 + 升级率）；PDF watcher hooks 修复；caffeinate LaunchAgent 自启
- **2/20**：超高产日 —— Agent Hub v2 完整设计+实施（6 大类平级/Hub Score 40-30-30/Author Identity/seafood-market CLI）；水产市场视觉重设计（暖白纸质感#faf8f4）；本地全栈 SQLite 后端；Mock→DB 全面迁移；EvoMap 竞品深度体验（6462 资产 reuse=0）；Benchmark 并表卡片（Seed2.0 vs Qwen3.5）；飞书 Sheet API 攻克；Ommata→fswatch PDF Watcher 定型；Agent Hub 推送 GitHub + 部署 ECS 中
- **2/21**：Agent Hub 全栈迭代日 —— Auth 重构（Token→Device ID）；双币制 v3 上线；Hub Score 废弃改安装数；Cloudflare Tunnel + openclawmp.cc 上线；GitHub 批量导入工具；登录/注册分离 + API Key 认证 + Magic Link；Onboarding 引导流；OpenClaw 生态调研（70+ 项目）；进化自我反思报告

## 💬 飞书群组

| 群名 | chat_id | 策略 |
|------|---------|------|
| Make Agent Great｜Agent极客 | oc_8970b8b266cfc574adf6431d1720d387 | 每日 20:00 cron 总结（feishu-group-summary skill），35 人 |
| 妙兜的干爹干妈们 | oc_308e78f30e33cd232ef179dd6d706ffd | ⚠️ 高警戒：非指挥官消息谨慎处理 |
| 未命名群 | oc_a819b7691983f910acc1207a523a1f09 | 指挥官向群友推荐小跃；有用户请求定时任务演示 |
| 见闻分享群 | oc_ba7bdf47c5f201c10b1bb1810cd2d0e7 | 538 人大群，2/16 接入；话题：AI 模型评测/定价/行业动态/Agent Skills |

### MAG 群 Bot 档案

| app_id | open_id | 名字 | 所有者 | 能力 |
|--------|---------|------|--------|------|
| cli_a90784cc01785bef | ou_f16c89619a93ec8dec6d5243f81ba7cd | 小跃Bot | 钟经纬 | OpenClaw 驻场助手 |
| cli_a9027e3cb8b8dcd2 | ou_d7e0e994a56c8679db1e0aa6dd0263e8 | Charles.Alpha v0.1 | Charles Ge | TODO/股票/文档 |
| cli_a9063c4857389bdf | ou_cffc5ef25db1b4ecbead2bf8756caa65 | AI寻人&寻AI人 | Tina | AI行业动态周报 |
| cli_a907620585389cc2 | ou_23ce8b7303034eeb78455ac239c4f802 | 赛博巴菲特 | 孙瑞 | fintool MCP金融分析 |

## 🔧 技术经验（飞书相关）

### 卡片消息（Interactive Card）
- 普通 message tool 发的是 post 富文本，排版差；好看排版用 interactive card
- `content` 字段必须是 `json.dumps(card)` 后的字符串，不能嵌套对象（否则 230001）
- 卡片含引号/特殊字符时，用 JSON 文件加载比 Python 字符串内嵌更安全
- Schema 2.0 **不支持 `note` 标签**，用 markdown 斜体替代
- 通过 Python 脚本 + curl 调飞书 API 发送最可靠

### 群消息拉取
- `feishu_chat` 工具在所有 session 中**不可用**
- 替代方案：exec + curl 直接调飞书 API（`/im/v1/messages`）
- 群成员 API `/im/v1/chats/{id}/members` **可用**，但不返回 Bot 成员
- Bot sender.id 是 app_id（cli_xxx），需 known-bots.json 维护映射

### 文档写入
- `feishu_doc` tool 的 write/append 对新文档返回 400，不可靠
- 可靠方案：Python 脚本直接调 Block API，分批写入（batch_size=15）
- Block 类型：page=1, text=2, heading1=3, heading2=4, heading3=5, bullet=12, divider=22

### Hooks 配置
- Gateway 需显式启用：`hooks: { path: "/hooks", secret: "<token>" }`
- Hooks wake endpoint：`http://localhost:<port>/hooks/wake`（不是 `/api/cron/wake`）
- 文件系统 watcher 通过 hooks 唤醒 Agent 处理新文件

### 其他
- 飞书插件通过 jiti 直接加载 .ts 源码，无需编译
- OpenClaw 插件系统支持 8 种能力注册（Tools/Hooks/Channels/Providers/Gateway/CLI/Services/HTTP）
- 三层记忆架构源码在 /openclaw/src/memory/（11,192 lines），支持 hybrid BM25 + vector search

### 飞书发送图片
- `message` tool 的 `filePath`/`media` 参数在飞书渠道**不可用**（EPIPE / 400，缺 im:resource 权限）
- **可靠方案**：Python 脚本直接调飞书 API 三步走：
  1. 获取 tenant_access_token
  2. `POST /im/v1/images`（image_type=message）上传图片 → 获取 image_key
  3. `POST /im/v1/messages`（msg_type=image）发送图片消息
- 参考脚本：`/tmp/send_feishu_images.py`

## 🔍 搜索工具

- **web_search**（Brave API）：日常搜索优先
- **StepSearch Wrapper**：`tools/step_search_wrapper.py`，API 地址 `staging-stepsearch-enginemixer.stepfun-inc.com/v1/search`，app_id=2（跃问），已配置 STEPSEARCH_AUTH_TOKEN

## ⏰ Cron 任务

| ID | 名称 | 调度 | 说明 |
|----|------|------|------|
| 8e77c720-... | Daily Context Sync | 每晚 23:00 | 蒸馏当天对话 → memory/YYYY-MM-DD.md |
| 94021297-... | Weekly Memory Compound | 每周日 22:00 | 本周日志 → 更新 MEMORY.md |
| 4b2adbfe-... | Hourly Micro-Sync | 10/13/16/19/22:00 | 轻量检查近3h活动，append 当天日志 |
| 16f2521a-... | MAG 群每日总结 | 每天 20:00 | 拉群消息 + 生成卡片总结 → 发到 MAG 群 |

## 🐟 水产市场 (Agent Hub)

- **GitHub Repo**：`https://github.com/502399493zjw-lgtm/agent-hub`
- **本地路径**：`~/.openclaw/workspace/agent-hub/`
- **CLI 工具**：`seafood-market`（`~/.local/bin/seafood-market` symlink）
- **DB**：SQLite `data/hub.db`，5 API routes，38 个资产
- **小跃已发布 2 个资产**：fs-event-trigger (tr-gotegm) + pdf-watcher (tr-1p4d6k)
- **设计文档**：`agent-hub/docs/hub-design-v2.md`
- **三环境隔离**（2/22 建立）：

| 环境 | 端口 | DB | 说明 |
|------|------|-----|------|
| dev | 3001 | `data/hub.db` | 开发环境，⚠️ 永远不要碰 3000 端口 |
| test | 3002 | `data/hub-test.db` | 测试环境，走完整用户流程（注册→认证→发布） |
| prod | ECS:3000 | `/opt/agent-hub/data/hub.db` | 线上，域名 `openclawmp.cc` |

- **环境分离改动**：`connection.ts` 读 `process.env.DATABASE_URL`；`.env.test` 配置独立 DB+端口；`package.json` 加 `test:server` 脚本
- **核心原则**：测试必须走真实认证链路，永远不绕过 API 直接写 DB
- **ECS 部署**：`/opt/agent-hub`，Docker 运行中；域名 `openclawmp.cc`（Cloudflare Tunnel）
- **部署方式（v2，2/22 上线）**：本地 `docker buildx --platform linux/amd64` → `docker save | gzip` → rsync 到 ECS → `docker load` → 蓝绿切换零停机。脚本 `deploy.sh` 已更新。
  - 本地 build 约 3 分半，镜像 78MB（Alpine 精简），rsync 推送约 3 分钟
  - 蓝绿流程：新容器先起 :3001 → 健康检查通过 → 切到 :3000 → 旧容器下线
  - **彻底淘汰 ECS 上 docker build**（OOM/慢/占资源）
- **Auth 系统**：GitHub OAuth + Magic Link（Resend 待配）+ API Key（sk-xxx）+ Device ID（X-Device-ID）
- **经济系统**：双币制 v3 — 声望（Reputation）+ 养虾币（Shrimp Coins），事件自动触发
- **GitHub 导入**：`tools/github-import.ts`，批量抓 repo 信息 + README + Issues → DB
- **资产总数**：37 个（含 KKClaw ch-akyy6u 等 GitHub 导入）

## 🔬 竞品情报

- **EvoMap** (evomap.ai)：Gene/Capsule/EvolutionEvent 三件套，GDI 四维评分，6462 资产但 reuse=0（空转），面向 Agent 的 A2A 协议（vs 我们面向人）
  - 可借鉴：GDI 评分、Bounty 悬赏、EvolutionEvent 审计链、SHA256 内容寻址
  - 账号：502399493@qq.com / Evomap2026!Zjw

## 🔌 Ommata 插件系统

- **pdf-watcher**：最终**放弃 Ommata WASM 方案**，改用 fswatch 原生监听
  - 原因：WIT 接口无 `workspace_list`（列目录），WASM 沙箱无法访问宿主文件系统
  - Ommata 适合网络事件（API polling），不适合文件系统监控
- **最终方案**：`fswatch`（FSEvents 内核级）+ `pdf-watcher.sh` + OpenClaw hooks mapping
  - 脚本：`~/.openclaw/hooks/pdf-watcher.sh`
  - Transform：`~/.openclaw/hooks/transforms/ommata-pdf.js`
  - LaunchAgent：`com.openclaw.pdf-watcher`（开机自启 + KeepAlive）
  - 链路：FSEvents → fswatch → shell → POST `/hooks/ommata` → JS transform → Agent
- **Ommata 通用经验**保留：
  - Daemon：`~/openclaw/skills/ommata/bin/ommata-darwin-arm64`，端口 17890
  - `hooks.mappings` 是**数组**格式
  - Gateway hooks 端口是 **18789**

## ⚠️ 已知问题 & 自我改进

- 群内消息过多（2/14 发了 59 条），大部分是内部思考泄露 → 需控制输出量
- 文件年份标注错误：`memory/2025-02-13.md` 实为 2026 年内容
- **ECS 部署/长等待任务必须用 subagent**：SSH 到 ECS 的 Docker build、npm install 等长耗时操作（>30s），不要在主会话里轮询等待，直接 `sessions_spawn` 一个 subagent 去盯，完成后自动通知。主会话保持响应。（2/21 指挥官明确要求）
- **开发流程：先本地改，确认后再推线上**：所有 agent-hub 代码改动先在本地完成并验证，指挥官确认没问题后再部署 ECS。（2/21 指挥官明确要求）
- **复杂代码改动用 subagent**：多文件修改、重构等复杂开发任务也用 subagent 执行，主会话保持响应。（2/21）
- **SQLite WAL 同步陷阱**：传 DB 前必须 `wal_checkpoint(TRUNCATE)`，否则最新数据在 .db-wal 文件里丢失（2/21 踩坑两次）
- **Docker restart ≠ env reload**：改环境变量必须 `docker rm -f` + `docker run`（2/21 踩坑）
- **资产分类看架构角色不看技术复杂度**：KKClaw 误判 template→channel 的教训（2/21）
- **ECS 2核4G 跑 Docker build 容易 OOM**：~~考虑本地 build + docker save/scp/load~~（2/21）→ **已解决**（2/22，deploy.sh v2 本地 build + 推镜像）
- **Docker Desktop 僵尸进程**：cagent 进程泄漏（70+个）会导致 Docker Engine 启动 hang 死，socket 文件不生成。解法：`killall -9 cagent` + 重启 Docker Desktop（2/22 踩坑）
- **scp 大文件到 ECS 容易 hang**：78MB 镜像 scp 超时，rsync -avP（支持断点续传 + 进度显示）更可靠（2/22）

## 🎯 待办

- [ ] 配置 Embedding API 激活向量记忆（第三层语义搜索）
- [ ] 飞书后台加权限：im:chat:readonly / im:chat.member:readonly（查群信息）、im:resource:upload / im:resource（文件上传）
- [ ] 飞书插件改造：feishu_chat_members + feishu_chat_history 工具（等权限开通）

---

_上次更新：2026-02-22 11:41 by 指挥官要求更新_
