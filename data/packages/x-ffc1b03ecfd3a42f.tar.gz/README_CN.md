# 语义记忆搜索

OpenClaw 内置的记忆系统将所有内容存储为 Markdown 文件——但随着记忆文件在数周乃至数月内不断增长，想要找到上周二的某个决定变得不可能。没有搜索功能，只能通过滚动文件来查找。

本用例在 OpenClaw 现有的 Markdown 记忆文件之上，利用 [memsearch](https://github.com/zilliztech/memsearch) 增加了**由向量驱动的语义搜索**功能，让您可以通过含义而非关键词即时查找任何过往记忆。

## 功能特性

-   通过一个命令将所有 OpenClaw 的 Markdown 记忆文件索引到向量数据库 (Milvus) 中
-   按含义搜索：“我们选择了哪种缓存方案？”即使记忆中没有出现“缓存”一词，也能找到相关记忆
-   结合 RRF 重排的混合搜索（稠密向量 + BM25 全文搜索），以获得最佳结果
-   SHA-256 内容哈希意味着未更改的文件永远不会被重新嵌入——零浪费 API 调用
-   文件监视器在记忆文件更改时自动重新索引，确保索引始终保持最新
-   支持任何 Embedding 提供商：OpenAI、Google、Voyage、Ollama，或完全本地化（无需 API key）

## 痛点

OpenClaw 的记忆以纯 Markdown 文件的形式存储。这对于可移植性和人类可读性来说非常棒，但它没有搜索功能。随着记忆的增长，您要么需要通过 `grep` 命令搜索文件（仅限关键词，会遗漏语义匹配），要么将整个文件加载到上下文中（在不相关的内容上浪费 token）。您需要一种方法来询问“我关于 X 做了什么决定？”，并获得精确的相关片段，而无论措辞如何。

## 所需技能

-   无需 OpenClaw 技能——memsearch 是一个独立的 Python CLI/库
-   Python 3.10+ 及 `pip` 或 `uv`

## 设置方法

1.  安装 memsearch：
    ```bash
    pip install memsearch
    ```

2.  运行交互式配置向导：
    ```bash
    memsearch config init
    ```

3.  索引您的 OpenClaw 记忆目录：
    ```bash
    memsearch index ~/path/to/your/memory/
    ```

4.  按含义搜索您的记忆：
    ```bash
    memsearch search "what caching solution did we pick?"
    ```

5.  要实现实时同步，请启动文件监视器——它会在每次文件更改时自动索引：
    ```bash
    memsearch watch ~/path/to/your/memory/
    ```

6.  对于完全本地化的设置（无需 API key），请安装本地 Embedding 提供商：
    ```bash
    pip install "memsearch[local]"
    memsearch config set embedding.provider local
    memsearch index ~/path/to/your/memory/
    ```

## 核心要点

-   **Markdown 始终是事实的来源。** 向量索引只是一个派生缓存——您可以随时使用 `memsearch index` 重建它。您的记忆文件永远不会被修改。
-   **智能去重节省成本。** 每个数据块都由一个 SHA-256 内容哈希标识。重新运行 `index` 只会嵌入新的或更改的内容，因此您可以随意运行它，而不会浪费 Embedding API 调用。
-   **混合搜索优于纯向量搜索。** 通过倒数排名融合 (Reciprocal Rank Fusion) 将语义相似性（稠密向量）与关键词匹配 (BM25) 相结合，可以同时捕获基于含义和精确匹配的查询。

## 相关链接

-   [memsearch GitHub](https://github.com/zilliztech/memsearch) — 驱动此用例的库
-   [memsearch 文档](https://zilliztech.github.io/memsearch/) — 完整的 CLI 参考、Python API 和架构
-   [OpenClaw](https://github.com/openclaw/openclaw) — 启发 memsearch 的记忆架构
-   [Milvus](https://milvus.io/) — 向量数据库后端