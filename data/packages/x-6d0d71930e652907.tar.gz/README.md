# 水产市场内容矿工（Marketplace Content Miner）

**类型**：experience
**名称**：marketplace-content-miner
**描述**：Agent 每天自动回顾对话，把有复用价值的工作成果打包成水产市场资产，经审批后发布。

---

你的 Agent 每天都在帮你干活——写脚本、配工具、解决问题。但这些成果往往做完就沉没了。

这个经验让 Agent 变成一台「内容矿工」：每天定时挖掘对话中的宝藏，自动打包成水产市场资产，让你的工作成果变成社区共享的价值。

## 它解决什么问题

- Agent 日常产出大量有复用价值的脚本、方案、配置，但做完就被遗忘
- 手动整理和发布太费时间，大多数好东西就这么沉没了
- 水产市场需要持续的优质内容，但谁有空天天写？

**内容矿工建立自动化闭环**：对话产出 → 自动提炼 → 安全扫描 → 用户审批 → 一键发布。

## 工作原理

一个 Cron 任务，每日执行：

| 步骤 | 做什么 |
|------|--------|
| 1. 对话扫描 | 回顾过去 24h 所有 session 对话 |
| 2. 成果提炼 | 识别有复用价值的脚本、方案、工具、配置 |
| 3. 类型判断 | 自动判断最合适的资产类型（skill/experience/plugin/trigger/channel） |
| 4. 质量评分 | 按通用性、完整性、独特性三维度打分，低分丢弃 |
| 5. 安全扫描 | 检测 API Key、Token、密码、个人信息等敏感内容 |
| 6. 打包预览 | 生成标准资产目录 + 审批摘要 |
| 7. 审批发布 | 推给用户过目（含安全警告），确认后发布到水产市场 |

### 成果判定信号

Agent 在对话中寻找以下模式：

- **写了完整脚本/工具** 且用户确认好用 → skill
- **解决了通用配置问题** — cron 配置、系统调优、工作流方案 → experience
- **写了 OpenClaw 扩展** — 含 openclaw.plugin.json → plugin / channel
- **配了事件监听/自动触发** — fswatch / webhook / cron 链路 → trigger
- **多轮诊断解决复杂问题** — 有排查过程 + 最终方案 → experience

### 自动排除

以下对话不会被提炼：
- 纯一次性查询（天气、搜索、翻译）
- 涉及用户私有数据的操作
- 未完成或失败的尝试
- 市场上已有高度类似的资产

## 安全扫描

发布前自动扫描所有文件内容。命中敏感模式时**不会阻止发布**，而是在审批消息中用 ⚠️ 高亮标注，由你决定是否继续。

扫描覆盖：
- API Key（`sk-`、`ak-`、`AKIA` 等前缀）
- Token（`ghp_`、`xoxb-`、`bearer` 等）
- 密码 / Secret（`password=`、`SECRET_KEY` 等）
- 私钥（`-----BEGIN.*PRIVATE KEY-----`）
- 个人信息（邮箱、手机号、内网 IP）
- 环境变量（`.env` 内容、`export.*KEY=`）
- 路径泄露（`/Users/<username>/` 等本机路径）
- 内部标识（飞书 `open_id`、`chat_id`、内部域名）

详细规则见 `security-rules.md`。

## 安装

### 1. 安装资产

```bash
openclawmp install experience/@marketplace-content-miner
```

### 2. 初始化日志文件

```bash
cp ~/.openclaw/experiences/marketplace-content-miner/templates/miner-log.md ~/memory/miner-log.md
```

如果 `memory/` 目录不存在，先创建：`mkdir -p ~/memory`

### 3. 配置 Cron 任务

```bash
openclaw cron add \
  --name "Content Miner: Daily Scan" \
  --cron "0 22 * * *" \
  --session isolated \
  --message "读取 ~/.openclaw/experiences/marketplace-content-miner/scan-prompt.md 并执行" \
  --announce
```

### 4. 可选：调整配置

编辑 `~/.openclaw/experiences/marketplace-content-miner/miner-config.md` 修改默认行为。

## 配置项

| 配置 | 可选值 | 默认 | 说明 |
|------|--------|------|------|
| publish_mode | ask / auto | ask | ask=推给用户审批，auto=自动发布+通知 |
| scan_time | cron 表达式 | `0 22 * * *` | 扫描时间（改 cron 即可） |
| scan_hours | 数字 | 24 | 回看多少小时的对话 |
| max_candidates | 数字 | 3 | 单次最多提炼几个候选 |
| min_quality_score | 1-10 | 6 | 低于此分的候选不发布 |
| blocked_patterns | 正则列表 | 内置安全清单 | 额外自定义敏感模式 |

## 文件说明

| 文件 | 用途 |
|------|------|
| README.md | 你正在看的这个 |
| scan-prompt.md | Cron 任务执行时的完整 prompt |
| security-rules.md | 安全扫描的正则规则与说明 |
| quality-rubric.md | 质量评分标准（通用性/完整性/独特性） |
| miner-config.md | 可调配置项 |
| templates/publish-draft.md | 审批消息模板 |
| templates/miner-log.md | 每日挖矿日志模板 |

## 依赖

- **openclawmp**（水产市场 CLI）— 搜索已有资产 + 发布新资产
- **OpenClaw 内置工具** — sessions_list、sessions_history、read、write、exec
- **openclawmp 账号** — 需要已登录水产市场（`openclawmp login`）
