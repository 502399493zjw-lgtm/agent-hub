# 内容矿工配置

## publish_mode
# ask = 打包后推给用户审批（默认）
# auto = 直接发布 + 通知用户
publish_mode: ask

## scan_hours
# 每次扫描回看多少小时的对话
scan_hours: 24

## max_candidates
# 单次最多提炼几个候选资产
max_candidates: 3

## min_quality_score
# 质量评分低于此值的候选不发布（1-10）
min_quality_score: 6

## blocked_patterns
# 额外的自定义敏感正则（每行一个）
# 这些规则会追加到 security-rules.md 的内置规则之后
# 例如：
# my-company\.internal\.com
# internal-api\.example\.com
blocked_patterns: |
  # 在这里添加自定义规则
