# 安全扫描规则

发布前扫描所有文件内容。命中时**不阻止发布**，在审批消息中用 ⚠️ 标注，由用户决定。

## 正则规则

### API Key
```
sk-[a-zA-Z0-9]{20,}
ak-[a-zA-Z0-9]{10,}
AKIA[0-9A-Z]{16}
api[_-]?key\s*[=:]\s*\S+
apikey\s*[=:]\s*\S+
```

### Token
```
token\s*[=:]\s*["']?\S+
[Bb]earer\s+\S{10,}
ghp_[a-zA-Z0-9]{36,}
gho_[a-zA-Z0-9]{36,}
github_pat_[a-zA-Z0-9_]{20,}
xoxb-[a-zA-Z0-9\-]+
xoxp-[a-zA-Z0-9\-]+
```

### 密码 / Secret
```
password\s*[=:]\s*\S+
passwd\s*[=:]\s*\S+
secret\s*[=:]\s*\S+
SECRET_KEY\s*[=:]\s*\S+
PRIVATE_KEY\s*[=:]\s*\S+
```

### 私钥
```
-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----
-----BEGIN\s+EC\s+PRIVATE\s+KEY-----
-----BEGIN\s+OPENSSH\s+PRIVATE\s+KEY-----
```

### 个人信息
```
[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}     # 邮箱
1[3-9]\d{9}                                            # 国内手机号
\b(?:192\.168|10\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}\b  # 内网 IP
```

### 环境变量
```
^export\s+\w*(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)\w*=
^\w*(KEY|TOKEN|SECRET|PASSWORD)\w*=\S+                 # .env 文件格式
```

### 路径泄露
```
/Users/[a-zA-Z0-9._-]+/
/home/[a-zA-Z0-9._-]+/
C:\\Users\\[a-zA-Z0-9._-]+\\
```

### 内部标识
```
ou_[a-f0-9]{32,}          # 飞书 open_id
oc_[a-f0-9]{32,}          # 飞书 chat_id
cli_[a-f0-9]{16,}         # 飞书 app_id
```

## 扫描方式

1. 逐文件逐行匹配上述正则
2. 命中时记录：`文件名:行号` + 规则类别 + 匹配片段（中间用 `***` 脱敏）
3. 同一文件同一规则最多报 3 次（避免刷屏）
4. 汇总后按严重程度排序：私钥 > API Key/Token > 密码 > 个人信息 > 路径 > 内部标识

## 例外白名单

以下模式**不算**命中（避免误报）：
- `sk-xxx`、`sk-your-key-here`、`sk-...` 等明显是占位符的
- README/文档中用于说明格式的示例
- 正则本身（比如这个文件里的规则定义）
