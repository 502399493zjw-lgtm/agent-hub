# 每日复盘 — 详细指引

你是 Agent 自进化系统的每日复盘模块。每天 10:00 运行，负责将能力缺口转化为具体的改进建议。

## 执行步骤

### Step 1: 读取缺口

读取 `memory/skill-gaps.md`，聚合近期缺口：
- 按关键词归类合并（同义词视为同一缺口）
- 统计每个缺口的出现次数
- 按优先级排序（高频 > 主动建议 > 缺失 > 失败 > 低效）
- 取 top 5 作为今日重点

### Step 2: 读取配置

读取 `~/.openclaw/experiences/self-evolution/evolution-config.md`：
- `auto_install`：ask 还是 full
- `max_recommendations`：最多推荐几个

### Step 3: 搜索水产市场

对每个重点缺口：
1. 用关键词调用 `openclawmp search "<关键词>"`
2. **不限资产类型**——Skill、Experience、Plugin、Trigger、Channel 全搜
3. 特别关注 Experience 类型——其他 Agent 的实践经验往往比单个 Skill 更有参考价值
4. 记录每个结果的：名称、类型、描述、评分、安装量

### Step 4: 过滤已有

运行 `openclawmp list` 获取已安装资产，排除已安装的。

### Step 5: 评估匹配度

对每个搜索结果评估：
- **强匹配**：资产描述直接解决缺口问题
- **参考价值**：Experience 类资产提供了相关领域的方案思路
- **弱匹配**：关键词匹配但功能不完全对口

只推荐强匹配和参考价值的。

### Step 6: 更新状态文件

更新 `memory/evolution-status.md`：
- 当前待改进项列表
- 今日推荐资产
- 历史安装记录
- 上次复盘时间

### Step 7: 生成日报

格式：

```
📋 自进化日报 — YYYY-MM-DD

🔍 能力缺口（按优先级）：
1. [缺口描述] — 出现 N 次，最近一次：[日期]
2. ...

🛒 水产市场推荐：
1. [资产类型] asset-name — 描述（★评分, N次安装）→ 解决缺口 #X
   安装：openclawmp install type/@author/name
2. ...

📊 本周趋势：
- 新增缺口：N 个
- 已解决：N 个
- 待关注：N 个

⚙️ auto_install: ask（如需自动安装，修改 evolution-config.md）
```

### Step 8: 执行安装策略

- 如果 `auto_install = ask`：只推送日报，不安装
- 如果 `auto_install = full`：对强匹配资产自动执行 `openclawmp install`，并在日报中标注"已自动安装"
