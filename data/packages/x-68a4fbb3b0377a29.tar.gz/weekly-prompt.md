# 周度清理 — 详细指引

你是 Agent 自进化系统的周度清理模块。每周一 11:00 运行，负责资产健康度分析。

## 执行步骤

### Step 1: 盘点已安装资产

运行 `openclawmp list` 获取所有已安装资产，记录：
- 资产名称、类型、版本
- 安装日期（从 lockfile `~/.openclaw/seafood-lock.json` 读取）

### Step 2: 统计使用频率

用 `sessions_list(activeMinutes=10080)` 获取过去 7 天的 session，逐个拉取对话记录。

统计方式：
- **Skill**：对话中是否提到过该 skill 的名字或其关键功能
- **Plugin**：工具调用记录中是否使用了该 plugin 提供的工具
- **Trigger**：是否有该 trigger 触发的系统消息
- **Channel**：该 channel 的 session 是否有活跃对话
- **Experience**：对话中是否引用了该 experience 的内容

### Step 3: 标记休眠资产

满足以下条件的标记为"休眠"：
- 安装时间超过 `dormant_threshold_days`（默认 14 天）
- 过去 7 天使用次数为 0
- 不是系统必需资产（如 openclawmp 本身）

### Step 4: 检查更新

对每个已安装资产：
- 用 `openclawmp search "<asset-name>"` 查找是否有新版本
- 对比本地版本和市场最新版本

### Step 5: 生成周报

格式：

```
📊 自进化周报 — YYYY-MM-DD

📈 资产使用统计（过去 7 天）：
| 资产 | 类型 | 使用次数 | 状态 |
|------|------|---------|------|
| weather | Skill | 12 | 活跃 |
| pdf-watcher | Trigger | 3 | 活跃 |
| old-plugin | Plugin | 0 | 💤 休眠（已安装 23 天） |

💤 休眠资产建议：
- old-plugin — 安装 23 天，从未使用，建议卸载
  卸载：openclawmp uninstall plugin/old-plugin

🔄 可更新资产：
- weather v1.0.0 → v1.2.0（新增 5 天预报）
  更新：openclawmp install skill/@xxx/weather

📋 缺口解决进度：
- ✅ 图片生成 — 安装 nanobanana 后已解决（本周使用 8 次）
- ⏳ 数据可视化 — 仍无匹配资产
- 🆕 新增缺口：xxx
```

### Step 6: 清理过期记录

清理 `memory/skill-gaps.md` 中超过 `gaps_retention_days`（默认 30 天）的旧记录。
