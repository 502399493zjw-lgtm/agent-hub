# 自进化配置

> 修改此文件调整自进化系统的行为。Cron 任务每次运行时会读取这些配置。

## auto_install

安装策略。

- `ask`：只推荐，所有安装需用户确认（默认）
- `full`：对强匹配资产自动安装，安装后在日报中告知

当前值：**ask**

## signal_scan_hours

信号采集时回看多少小时的对话记录。

当前值：**24**

## max_recommendations

每日复盘日报中最多推荐几个资产。

当前值：**5**

## dormant_threshold_days

已安装资产多少天未使用会被标记为"休眠"。

当前值：**14**

## gaps_retention_days

skill-gaps.md 中的缺口记录保留多少天，超过后由周度清理任务清除。

当前值：**30**
