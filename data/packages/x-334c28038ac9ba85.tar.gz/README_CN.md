# 第二大脑

你不断产生想法，发现有趣的链接，听到想读的书——但却从未有一个好的系统来捕捉它们。Notion 变得复杂，Apple Notes 成了堆积着上万条未读记录的墓地。你需要一个像给朋友发短信一样简单的系统。

本工作流将 OpenClaw 转化为一个记忆捕获系统，你可以通过短信与之互动，并由一个可随时浏览的自定义可搜索 UI 提供支持。

## 功能介绍

-   通过 Telegram、iMessage 或 Discord 向你的 OpenClaw 发送任何内容——例如“提醒我读一本关于本地 LLM 的书”——它会立即记住。
-   OpenClaw 内置的记忆系统会永久存储你告诉它的一切。
-   一个自定义的 Next.js 仪表盘让你能够搜索所有记忆、对话和笔记。
-   全局搜索 (Cmd+K) 覆盖所有记忆、文档和任务。
-   没有文件夹，没有标签，没有复杂的组织——只有文本和搜索。

## 痛点

每一个笔记应用最终都会变成一项苦差事。你停止使用它，因为整理的摩擦力高于遗忘的摩擦力。关键的洞察是：**捕捉应该像发短信一样简单，检索应该像搜索一样容易**。

## 所需技能

-   Telegram、iMessage 或 Discord 集成（用于基于文本的捕捉）
-   Next.js (OpenClaw 会为你构建，无需编码)

## 如何设置

1.  确保你的 OpenClaw 已连接到你偏好的消息平台（Telegram、Discord 等）。

2.  立即开始使用——只需向你的机器人发送任何你想记住的内容：
    ```text
    Hey, remind me to read "Designing Data-Intensive Applications"
    Save this link: https://example.com/interesting-article
    Remember: John recommended the restaurant on 5th street
    ```

3.  通过提示 OpenClaw 来构建可搜索的 UI：
    ```text
    I want to build a second brain system where I can review all our notes,
    conversations, and memories. Please build that out with Next.js.

    Include:
    - A searchable list of all memories and conversations
    - Global search (Cmd+K) across everything
    - Ability to filter by date and type
    - Clean, minimal UI
    ```

4.  OpenClaw 将为你构建并部署整个 Next.js 应用。导航到它提供的 URL，你就能拥有你的第二大脑仪表盘了。

5.  从现在起，无论何时你想到什么——在路上、在会议中、睡前——只需给你的机器人发短信。当你需要查找内容时，回到仪表盘即可。

## 核心洞察

-   力量在于**零摩擦捕捉**。你无需打开应用、选择文件夹或添加标签。只需发短信。
-   OpenClaw 的记忆系统是累积性的——它会记住你告诉它的一切，随着时间的推移变得更加强大。
-   你可以从手机上给你的机器人发短信，它会在你的电脑上构建内容。界面就是对话本身。

## 基于

灵感来自 [Alex Finn 关于改变生活的 OpenClaw 用例视频](https://www.youtube.com/watch?v=41_TNGDDnfQ)。

## 相关链接

-   [OpenClaw 记忆系统](https://github.com/openclaw/openclaw)
-   [构建第二大脑 (Tiago Forte)](https://www.buildingasecondbrain.com/)