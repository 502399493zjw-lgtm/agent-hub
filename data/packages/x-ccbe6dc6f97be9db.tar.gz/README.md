# 收件箱清理

订阅邮件堆积如山，大部分根本没打开过，但又怕错过重要内容。

## 所需技能

- [Gmail OAuth Setup](https://clawhub.ai/kai-jar/gmail-oauth)

## 配置方式

1. （可选）为 OpenClaw 创建一个专用 Gmail
2. （可选）将所有订阅转移到该邮箱
3. 安装 Gmail 技能并确保正常工作
4. 指示 OpenClaw：

```
每天晚上 8 点运行 Cron 任务，阅读过去 24 小时的所有订阅邮件，生成最重要内容的摘要和原文链接。然后询问我的反馈，根据我的偏好优化后续摘要质量。
```

---

# Original (English)

# Inbox De-clutter

Newsletters can take up the inbox like nothing else. Often times they pile-up without being opened at all. 

## Skills you Need
[Gmail OAuth Setup](https://clawhub.ai/kai-jar/gmail-oauth).

## How to Set it Up
1. [optional] Create a new gmail specifically for OpenClaw.
2. [optional] Unsubscribe from all newsletters from your main email and subscribe to them using the OpenClaw email.
3. Install the skill and make sure it works. 
4. Instruct OpenClaw:
```txt
I want you to run a cron job everyday at 8 p.m. to read all the newsletter emails of the past 24 hours and give me a digest of the most important bits along with links to read more. Then ask for my feedback on whether you picked good bits, and update your memory based on my preferences for better digests in the future jobs.
```