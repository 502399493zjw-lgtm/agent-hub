# YouTube 每日精选

用你喜爱 YouTube 频道的新视频个性化摘要开启新的一天——不再错过你真正想关注的创作者内容。

## 痛点

YouTube 通知不可靠。你订阅了频道，但新视频从未出现在你的主页动态中，也没有在通知里。它们就是……消失了。这并非你不想看，而是 YouTube 的算法将其埋没了。

此外：用精选内容洞察开启一天，而不是漫无目的地刷推荐动态，会更有趣。

## 功能

- 从你喜爱频道列表中获取最新视频
- 总结或提取每个视频转录稿中的关键洞察
- 每天（或按需）向你发送摘要

## 所需技能

安装 [youtube-full](https://clawhub.ai/therohitdas/youtube-full) skill。

只需告诉你的 OpenClaw：

```text
"Install the youtube-full skill and set it up for me"
```
或

```bash
npx clawhub@latest install youtube-full
```

就这样。Agent 会处理其余所有事项——包括账户创建和 API 密钥设置。注册即可获得 **100 免费 credits**，无需信用卡。

> 注意：创建账户后，skill 会根据操作系统自动将 API 密钥安全地存储在正确位置，因此 API 将在所有上下文中工作。

![youtube-full skill installation](https://pub-15904f15a44a4ea69350737e87660b92.r2.dev/media/1770620159490-e41e7baa.png)

### 为什么选择 TranscriptAPI.com 而非 yt-dlp？

| CLI 工具 (yt-dlp 等)       | TranscriptAPI                                                               |
|--------------------------|-----------------------------------------------------------------------------|
| 冗长的日志会淹没 Agent 上下文 | 简洁的 JSON 响应                                                            |
| 不适用于 GCP/云端 OpenClaw | 随处可用，速度快                                                            |
| 经常被 YouTube 随机屏蔽   | 为 [YouTubeToTranscript.com](https://youtubetotranscript.com) 提供支持，服务数百万用户。缓存且可靠。 |
| 需要安装二进制文件       | 无需二进制文件，只需 HTTP                                                   |

## 配置方式

### 选项 1：基于频道的摘要

提示 OpenClaw：

```text
Every morning at 8am, fetch the latest videos from these YouTube channels and give me a digest with key insights from each:

- @TED
- @Fireship
- @ThePrimeTimeagen
- @lexfridman

For each new video (uploaded in the last 24-48 hours):
1. Get the transcript
2. Summarize the main points in 2-3 bullets
3. Include the video title, channel name, and link

If a channel handle doesn't resolve, search for it and find the correct one.
Save my channel list to memory so I can add/remove channels later.
```

### 选项 2：基于关键词的摘要

追踪关于特定主题的新视频：

```text
Every day, search YouTube for new videos about "OpenClaw" (or "Claude Code", "AI agents", etc).

Maintain a file called seen-videos.txt with video IDs you've already processed.
Only fetch transcripts for videos NOT in that file.
After processing, add the video ID to seen-videos.txt.

For each new video:
1. Get the transcript
2. Give me a 3-bullet summary
3. Note anything relevant to my work

Run this every morning at 9am.
```

这样你就不会浪费 credits 重新获取已看过的视频。

## 提示

- `channel/latest` 和 `channel/resolve` 是**免费的**（0 credits）——检查新上传视频不花费任何费用
- 只有转录稿每个花费 1 credit
- 请求不同风格的摘要：关键要点、值得注意的引语、有趣时刻的时间戳
- 这已经作为产品存在 - [Recapio - Daily YouTube Recap](https://recapio.com/features/daily-recaps)