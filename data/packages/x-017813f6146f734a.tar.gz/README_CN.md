# 个人 CRM：自动联系人发现

手动追踪你认识了谁、何时认识、聊了什么几乎是不可能的。重要的后续工作可能会被遗漏，在重要会议前你也会忘记上下文信息。

本工作流自动构建并维护一个个人 CRM：

• 每日 Cron 任务扫描邮件和日历，发现新联系人和互动
• 将联系人存储在结构化数据库中，并附带关系上下文
• 支持自然语言查询：“我了解 [某人] 什么？”、“谁需要跟进？”、“我上次和 [某人] 什么时候聊的？”
• 每日会前准备简报：在每天的会议前，通过 CRM 和邮件历史记录研究外部参会者，并提供一份简报

## 所需技能

- `gog` CLI（用于 Gmail 和 Google Calendar）
- 自定义 CRM 数据库（SQLite 或类似）或使用 [crm-query](https://clawhub.ai) 技能（如果可用）
- 用于 CRM 查询的 Telegram 话题

## 如何设置

1.  创建一个 CRM 数据库：
    ```sql
    CREATE TABLE contacts (
      id INTEGER PRIMARY KEY,
      name TEXT,
      email TEXT,
      first_seen TEXT,
      last_contact TEXT,
      interaction_count INTEGER,
      notes TEXT
    );
    ```
2.  设置一个名为 "personal-crm" 的 Telegram 话题用于查询。
3.  提示 OpenClaw：
    ```text
    每天早上 6 点运行一个 Cron 任务来：
    1. 扫描我过去 24 小时的 Gmail 和日历
    2. 提取新联系人并更新现有联系人
    3. 记录互动（会议、邮件），包括时间戳和上下文

    另外，每天早上 7 点：
    1. 检查我今天的日历会议
    2. 对于每个外部参会者，搜索我的 CRM 和邮件历史记录
    3. 向 Telegram 发送一份简报，内容包括：他们是谁、我们上次何时交谈、我们讨论了什么以及任何后续事项

    当我在 personal-crm 话题中询问某个联系人时，搜索数据库并提供你所知道的一切。
    ```