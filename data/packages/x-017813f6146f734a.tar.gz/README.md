# 个人 CRM：自动联系人发现

保持对人脉网络的追踪很难——你认识了谁、聊了什么、下次该什么时候联系，全凭记忆。

本方案让 Agent 帮你打造个人 CRM：

- 从邮件、日历、聊天记录中自动发现新联系人
- 记录每次互动（见面、邮件、电话）
- 智能提醒：某人已经 30 天没联系了
- 联系人画像：兴趣、公司、上次话题
- 会前准备：开会前自动汇总与该联系人的历史互动

## 核心功能

- **自动发现**：不需要手动录入，Agent 从各渠道自动提取
- **关系维护**：基于互动频率智能提醒
- **上下文回忆**：再也不用尴尬地问"我们上次聊了什么来着"

---

# Original (English)

# Personal CRM with Automatic Contact Discovery

Keeping track of who you've met, when, and what you discussed is impossible to do manually. Important follow-ups slip through the cracks, and you forget context before important meetings.

This workflow builds and maintains a personal CRM automatically:

• Daily cron job scans email and calendar for new contacts and interactions
• Stores contacts in a structured database with relationship context
• Natural language queries: "What do I know about [person]?", "Who needs follow-up?", "When did I last talk to [person]?"
• Daily meeting prep briefing: before each day's meetings, researches external attendees via CRM + email history and delivers a briefing

## Skills you Need

- `gog` CLI (for Gmail and Google Calendar)
- Custom CRM database (SQLite or similar) or use the [crm-query](https://clawhub.ai) skill if available
- Telegram topic for CRM queries

## How to Set it Up

1. Create a CRM database:
```sql
CREATE TABLE contacts (
  id INTEGER PRIMARY KEY,
  name TEXT,
  email TEXT,
  first_seen TEXT,
  last_contact TEXT,
  interaction_count INTEGER,
  notes TEXT
);
```
2. Set up a Telegram topic called "personal-crm" for queries.
3. Prompt OpenClaw:
```text
Run a daily cron job at 6 AM to:
1. Scan my Gmail and Calendar for the past 24 hours
2. Extract new contacts and update existing ones
3. Log interactions (meetings, emails) with timestamps and context

Also, every morning at 7 AM:
1. Check my calendar for today's meetings
2. For each external attendee, search my CRM and email history
3. Deliver a briefing to Telegram with: who they are, when we last spoke, what we discussed, and any follow-up items

When I ask about a contact in the personal-crm topic, search the database and give me everything you know.
```
