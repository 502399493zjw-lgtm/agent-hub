---
name: brainstorming
displayName: Brainstorming
type: skill
description: 创意工作前的需求探索与设计技能。强制 Agent 在动手前先理解用户意图、探索需求边界、完成方案设计，避免盲目开工。
version: 1.0.0
tags: brainstorming, design, requirements, creative, planning
category: 开发工具
---

# Brainstorming Ideas Into Designs

## Overview

Help turn ideas into fully formed designs and specs through natural collaborative dialogue.

Start by understanding the current project context, then ask questions one at a time to refine the idea. Once you understand what you're building, present the design and get user approval.

<HARD-GATE>
Do NOT invoke any implementation skill, write any code, scaffold any project, or take any implementation action until you have presented a design and the user has approved it. This applies to EVERY project regardless of perceived simplicity.
</HARD-GATE>

## Anti-Pattern: "This Is Too Simple To Need A Design"

Every project goes through this process. A todo list, a single-function utility, a config change — all of them. "Simple" projects are where unexamined assumptions cause the most wasted work. The design can be short (a few sentences for truly simple projects), but you MUST present it and get approval.

## Workflow

1. **理解上下文**：读取项目文件，了解当前状态
2. **探索意图**：逐个问题深挖用户真正想要什么
3. **呈现设计**：结构化方案 + 技术选型 + 边界条件
4. **获得批准**：用户确认后才开始实施

## 核心价值

- 避免"做了一半发现方向错了"
- 暴露隐含假设和边界条件
- 在动手前对齐预期
