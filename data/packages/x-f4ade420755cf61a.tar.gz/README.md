# Memory Configuration Strategy

Real-world patterns for agent memory management, distilled from months of OpenClaw operation.

## Architecture: Three-Layer Memory

### Layer 1: Session Context (Ephemeral)
- Injected automatically via AGENTS.md, SOUL.md, USER.md, MEMORY.md
- Lost on session restart
- Keep total injection < 8K tokens

### Layer 2: File-Based Memory (Persistent)
- `memory/YYYY-MM-DD.md` — Daily raw logs
- `MEMORY.md` — Curated long-term memory (human's journal equivalent)
- `HEARTBEAT.md` — Periodic check tasks

### Layer 3: Semantic Search (Optional)
- Embedding-based vector search over memory files
- Activated via `memory_search` tool
- Best for: "When did we discuss X?" queries

## Cron Strategy

| Job | Schedule | Purpose |
|-----|----------|---------|
| Daily Context Sync | 23:00 daily | Distill today's conversations → memory/YYYY-MM-DD.md |
| Weekly Memory Compound | Sunday 22:00 | Review week's logs → update MEMORY.md |
| Hourly Micro-Sync | Every 3h | Lightweight activity check |

## MEMORY.md Best Practices

1. **Keep it under 4K tokens** — it's injected every session
2. **Structure by category** — People, Projects, Tech, Lessons
3. **Prune aggressively** — Remove outdated info weekly
4. **Include action items** — Pending todos at the bottom
5. **Never store secrets** — No API keys, passwords, tokens

## Daily Log Format

```markdown
# YYYY-MM-DD

## Key Events
- [timestamp] Event description

## Decisions Made
- Decision: reasoning

## Lessons Learned
- What went wrong → what to do instead

## Tomorrow
- [ ] Pending tasks
```

## Common Pitfalls

- **Token bloat**: MEMORY.md grows unchecked → session costs spike
- **Stale data**: Never-pruned memories cause wrong assumptions
- **Security leak**: Memory loaded in group chats exposes private context
- **Missing context**: Daily logs too sparse → weekly compound produces nothing useful
