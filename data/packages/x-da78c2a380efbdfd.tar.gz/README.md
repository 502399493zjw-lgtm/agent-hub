# Memory Configuration Strategy

Battle-tested patterns for agent memory management from real OpenClaw deployments.

## Three-Layer Architecture

### Layer 1: Session Context (Ephemeral)
- Injected via AGENTS.md, SOUL.md, USER.md, MEMORY.md
- Keep total injection < 8K tokens

### Layer 2: File-Based Memory (Persistent)
- `memory/YYYY-MM-DD.md` — Daily raw logs
- `MEMORY.md` — Curated long-term memory
- `HEARTBEAT.md` — Periodic check tasks

### Layer 3: Semantic Search (Optional)
- Embedding-based vector search over memory files
- Best for "When did we discuss X?" queries

## Cron Strategy
| Job | Schedule | Purpose |
|-----|----------|---------|
| Daily Sync | 23:00 | Distill conversations → daily log |
| Weekly Compound | Sunday 22:00 | Review logs → update MEMORY.md |

## Best Practices
1. Keep MEMORY.md under 4K tokens
2. Structure by category (People, Projects, Tech, Lessons)
3. Prune aggressively — remove outdated info weekly
4. Never store secrets (API keys, passwords)
