# 项目状态管理系统：看板的事件驱动替代方案

传统的 Kanban 看板是静态的，需要手动更新。你可能会忘记移动卡片，在不同会话之间丢失上下文，也无法追踪状态变化背后的“原因”。项目在缺乏清晰可见性的情况下容易偏离轨道。

此工作流用一个事件驱动系统取代 Kanban，自动追踪项目状态：

*   将项目状态存储在具有完整历史记录的数据库中
*   捕获上下文：决策、阻塞点、后续步骤、关键洞察
*   事件驱动更新：“刚完成 X，被 Y 阻塞” → 自动状态转换
*   自然语言查询：“[项目] 的状态是什么？”，“我们为什么在 [功能] 上做了调整？”
*   每日站会总结：昨天发生了什么，今天计划做什么，有什么被阻塞
*   Git 集成：将提交链接到项目事件以实现可追溯性

## 痛点

Kanban 看板会变得过时。你把时间浪费在更新卡片上，而不是实际工作。上下文容易丢失——三个月后，你可能不记得为什么做出了某个关键决策。代码更改和项目进度之间没有自动链接。

## 功能介绍

你无需拖动卡片，只需与你的助手对话：“完成了认证流程，开始做仪表盘。”系统会记录事件，更新项目状态，并保留上下文。当你询问“仪表盘的进展如何？”时，它会提供完整的故事：已完成什么，下一步是什么，什么阻塞了你，以及原因。

Git 提交会自动扫描并链接到项目。你的每日站会总结会自动生成。

## 所需技能

*   `postgres` 或 SQLite 用于项目状态数据库
*   `github` (gh CLI) 用于提交追踪
*   Discord 或 Telegram 用于更新和查询
*   Cron 任务用于每日总结
*   Sub-agents 用于并行项目分析

## 如何设置

1.  设置项目状态数据库：
    ```sql
    CREATE TABLE projects (
      id SERIAL PRIMARY KEY,
      name TEXT UNIQUE,
      status TEXT, -- e.g., "active", "blocked", "completed"
      current_phase TEXT,
      last_update TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE TABLE events (
      id SERIAL PRIMARY KEY,
      project_id INTEGER REFERENCES projects(id),
      event_type TEXT, -- e.g., "progress", "blocker", "decision", "pivot"
      description TEXT,
      context TEXT,
      timestamp TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE TABLE blockers (
      id SERIAL PRIMARY KEY,
      project_id INTEGER REFERENCES projects(id),
      blocker_text TEXT,
      status TEXT DEFAULT 'open', -- "open", "resolved"
      created_at TIMESTAMPTZ DEFAULT NOW(),
      resolved_at TIMESTAMPTZ
    );
    ```

2.  创建一个 Discord 频道用于项目更新（例如，#project-state）。

3.  提示 OpenClaw：
    ```text
    你是我项目状态管理器。我将以对话方式告诉你我正在做什么，而不是使用 Kanban。

    当我说以下内容时：
    - “完成了 [任务]” → 记录“progress”事件，更新项目状态
    - “被 [问题] 阻塞” → 创建一个 blocker 条目，将项目状态更新为“blocked”
    - “开始 [新任务]” → 记录“progress”事件，更新当前阶段
    - “决定 [决策]” → 记录“decision”事件并附带完整上下文
    - “转向 [新方法]” → 记录“pivot”事件并附带原因

    当我询问时：
    - “ [项目] 的状态是什么？” → 获取最新事件、blockers 和当前阶段
    - “我们为什么决定 [X]？” → 搜索事件以获取决策上下文
    - “什么阻塞了我们？” → 列出所有项目中未解决的 blockers

    每天早上 9 点，运行一个 cron 任务来：
    1. 扫描过去 24 小时内的 Git 提交（通过 gh CLI）
    2. 根据分支名称或提交消息将提交链接到项目
    3. 将每日站会总结发布到 Discord #project-state：
       - 昨天发生了什么（事件 + 提交）
       - 今天计划做什么（基于当前阶段和最近对话）
       - 有什么被阻塞（未解决的 blockers）

    当我计划冲刺时，生成一个 sub-agent 来分析每个项目的状态并提出优先级建议。
    ```

4.  与你的工作流集成：只需自然地与你的助手交流你正在做的事情。系统会捕获所有信息。

## 相关链接

-   [事件溯源模式](https://martinfowler.com/eaaDev/EventSourcing.html)
-   [为什么 Kanban 对独立开发者无效](https://blog.nuclino.com/why-kanban-doesnt-work-for-me)