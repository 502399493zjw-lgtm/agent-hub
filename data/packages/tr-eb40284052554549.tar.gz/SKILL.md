# PDF Watcher Trigger

Monitors a configured directory for new PDF files and sends webhook notifications to OpenClaw.

## How It Works
1. `fswatch` watches the target directory for `.pdf` files
2. On detection, a webhook POST is sent to OpenClaw hooks endpoint
3. Agent receives the event and processes the PDF

## Installation
```bash
brew install fswatch
```

## Configuration
Edit `config.json`:
- `watch_dir`: Directory to monitor (default: ~/Downloads)
- `extensions`: File extensions (default: ["pdf"])
- `webhook_url`: OpenClaw hooks endpoint
