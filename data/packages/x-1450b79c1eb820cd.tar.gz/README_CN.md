# 市场调研与产品工厂

你想开发产品却不知从何入手，或者已有业务但需要深入了解客户的真实痛点。本工作流利用 Last 30 Days 技能挖掘 Reddit 和 X 上的真实痛点，然后让 OpenClaw 构建解决方案。

## 功能特性

-   利用 [Last 30 Days](https://github.com/matvanhorde/last-30-days) 技能，跨 Reddit 和 X 调研任意话题近 30 天的讨论
-   挖掘用户发布的真实挑战、抱怨和功能需求
-   帮助你从真实的用户痛点中识别产品机会
-   更进一步：让 OpenClaw 针对某个挑战直接构建一个 MVP
-   为你打造从调研到产品的零代码全流程

## 痛点

大多数有抱负的创业者都困于“做什么产品”的问题。传统的市场调研意味着花费数小时手动浏览论坛、社交媒体和评论网站。本方案自动化了从发现到原型的整个流程。

## 所需技能

-   Matt Van Horde 的 [Last 30 Days](https://github.com/matvanhorde/last-30-days) 技能
-   用于接收调研报告的 Telegram 或 Discord 集成

## 如何设置

1.  安装 Last 30 Days 技能：
```text
Install this skill: https://github.com/matvanhorde/last-30-days
```

2.  对任意话题进行调研：
```text
Please use the Last 30 Days skill to research challenges people are
having with [your topic here].

Organize the findings into:
- Top pain points (ranked by frequency)
- Specific complaints and feature requests
- Gaps in existing solutions
- Opportunities for a new product
```

3.  选择一个痛点，让 OpenClaw 构建解决方案：
```text
Build me an MVP that solves [pain point from research].
Keep it simple — just the core functionality.
Ship it as a web app I can share with people.
```

4.  为了持续的市场情报，安排定期调研：
```text
Every Monday morning, use the Last 30 Days skill to research what
people are saying about [your niche] on Reddit and X. Summarize the
top opportunities and send them to my Telegram.
```

## 真实案例

```text
"Use the Last 30 Days skill to research challenges people are having with OpenClaw."
```

结果：
-   设置难度：许多用户在初始配置时遇到困难
-   技能发现：用户找不到满足其需求的技能
-   成本顾虑：用户希望有更便宜的模型替代方案

→ “为我构建一个简单的 Web 应用，通过引导式向导让 OpenClaw 设置更简单。”

OpenClaw 构建应用。你发布它。你拥有了一个产品。

## 核心洞察

-   这是**自动化创业**：发现问题 → 验证需求 → 构建解决方案，所有这些都通过文本消息完成。
-   Last 30 Days 技能为你提供真实、未经筛选的用户情绪——而非经过美化的调研数据。
-   你无需具备技术背景。OpenClaw 负责调研和构建。
-   安排每周调研，以掌握市场中不断变化的痛点。

## 基于

灵感来源于 [Alex Finn 关于改变生活的 OpenClaw 用例视频](https://www.youtube.com/watch?v=41_TNGDDnfQ) 以及 Matt Van Horde 的 [Last 30 Days 技能](https://github.com/matvanhorde/last-30-days)。

## 相关链接

-   [Last 30 Days Skill](https://github.com/matvanhorde/last-30-days)
-   [OpenClaw Skills Directory](https://github.com/openclaw/skills)