# 市场调研与产品工厂

你想做产品但不知道做什么，或者已有业务但不了解用户真正的痛点。

本方案利用 Last 30 Days 技能挖掘 Reddit 和 X 上的真实声音，然后让 Agent 直接构建解决方案：

- 跨 Reddit 和 X 调研任意话题近 30 天的讨论
- 挖掘真实的挑战、吐槽和功能诉求
- 识别产品机会
- 更进一步：让 Agent 针对某个痛点直接构建 MVP
- 从调研到原型的零代码全流程

## 痛点

大多数创业者卡在「做什么」的问题上。传统市场调研意味着数小时手动刷论坛、社交媒体和评价网站。本方案自动化了从发现到原型的整个流程。

## 所需技能

- [Last 30 Days](https://github.com/matvanhorde/last-30-days)
- Telegram/Discord 接收报告

---

# Original (English)

# Market Research & Product Factory

You want to build a product but don't know what to build. Or you have a business and need to understand what your customers are struggling with. This workflow uses the Last 30 Days skill to mine Reddit and X for real pain points, then has OpenClaw build solutions to those problems.

## What It Does

- Researches any topic across Reddit and X over the last 30 days using the [Last 30 Days](https://github.com/matvanhorde/last-30-days) skill
- Surfaces real challenges, complaints, and feature requests people are posting about
- Helps you identify product opportunities from genuine user pain points
- Takes it a step further: ask OpenClaw to build an MVP that solves one of those challenges
- Creates a full research-to-product pipeline with zero coding on your part

## Pain Point

Most aspiring entrepreneurs struggle with the "what to build" problem. Market research traditionally means hours of manual browsing through forums, social media, and review sites. This automates the entire discovery-to-prototype pipeline.

## Skills You Need

- [Last 30 Days](https://github.com/matvanhorde/last-30-days) skill by Matt Van Horde
- Telegram or Discord integration for receiving research reports

## How to Set It Up

1. Install the Last 30 Days skill:
```text
Install this skill: https://github.com/matvanhorde/last-30-days
```

2. Run research on any topic:
```text
Please use the Last 30 Days skill to research challenges people are
having with [your topic here].

Organize the findings into:
- Top pain points (ranked by frequency)
- Specific complaints and feature requests
- Gaps in existing solutions
- Opportunities for a new product
```

3. Pick a pain point and have OpenClaw build a solution:
```text
Build me an MVP that solves [pain point from research].
Keep it simple — just the core functionality.
Ship it as a web app I can share with people.
```

4. For ongoing market intelligence, schedule regular research:
```text
Every Monday morning, use the Last 30 Days skill to research what
people are saying about [your niche] on Reddit and X. Summarize the
top opportunities and send them to my Telegram.
```

## Real World Example

```text
"Use the Last 30 Days skill to research challenges people are having with OpenClaw."

Results:
- Setup difficulty: Many users struggle with initial configuration
- Skill discovery: People can't find skills that do what they need
- Cost concerns: Users want cheaper model alternatives

→ "Build me a simple web app that makes OpenClaw setup easier with a guided wizard."

OpenClaw builds the app. You ship it. You have a product.
```

## Key Insights

- This is **entrepreneurship on autopilot**: find problems → validate demand → build solutions, all through text messages.
- The Last 30 Days skill gives you real, unfiltered user sentiment — not sanitized survey data.
- You don't need to be technical. OpenClaw does the research AND the building.
- Schedule weekly research to stay on top of evolving pain points in your market.

## Based On

Inspired by [Alex Finn's video on life-changing OpenClaw use cases](https://www.youtube.com/watch?v=41_TNGDDnfQ) and the [Last 30 Days skill](https://github.com/matvanhorde/last-30-days) by Matt Van Horde.

## Related Links

- [Last 30 Days Skill](https://github.com/matvanhorde/last-30-days)
- [OpenClaw Skills Directory](https://github.com/openclaw/skills)
