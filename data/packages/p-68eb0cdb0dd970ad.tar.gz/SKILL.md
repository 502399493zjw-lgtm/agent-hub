---
name: openclaw-telemetry
displayName: OpenClaw Telemetry
type: plugin
description: 纯本地 Agent 可观测性插件。捕获所有 tool call、LLM 请求和 Agent 生命周期事件，输出到 JSONL 文件。内置数据脱敏、防篡改哈希链。零 API Key，49 星。
version: 1.0.0
tags: telemetry, observability, logging, security, no-api-key, local
category: 安全/监控
---

# OpenClaw Telemetry Plugin

By [Knostic](https://knostic.ai/) — Observability for OpenClaw.

- **GitHub**: https://github.com/knostic/openclaw-telemetry
- **Stars**: 49 ⭐
- **License**: Apache-2.0
- **安装**: `openclaw plugins install ./openclaw-telemetry`

## 核心能力

- 📊 **全量事件捕获**：Tool calls / LLM requests / Agent lifecycle / Message events
- 📁 **JSONL 输出**：本地文件存储，可选 syslog 转发到 SIEM
- 🔒 **数据脱敏**：内置 redaction 规则，自动过滤敏感信息
- 🔗 **防篡改哈希链**：每条记录哈希链式关联，保证审计完整性
- ⚡ **频率限制**：内置 rate limiting，不影响 Agent 性能

## 零依赖

- 无需任何 API Key
- 无需外部服务
- 纯本地运行
- 即插即用：复制到 extensions 目录 + 开启配置即可
