use serde::{Deserialize, Serialize};
use std::cell::RefCell;
use std::collections::HashSet;

wit_bindgen::generate!({
    world: "sandboxed-event-plugin",
    path: "wit"
});

use exports::near::agent::event_plugin::{Guest, PluginConfigSchema, PluginMetadata};
use near::agent::event_plugin_host::{
    emit_event, log, now_millis, should_stop, sleep,
    workspace_list, workspace_read, workspace_write,
    EventData, LogLevel,
};

// ==================== 配置 ====================

#[derive(Serialize, Deserialize, Clone)]
struct Config {
    /// 轮询间隔（毫秒），默认 5000ms
    poll_interval_ms: u64,
    /// 监控目录（默认 ~/Downloads）
    watch_dir: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            poll_interval_ms: 5000,
            watch_dir: "~/Downloads".to_string(),
        }
    }
}

thread_local! {
    static CONFIG: RefCell<Option<Config>> = RefCell::new(None);
}

// ==================== 辅助函数 ====================

/// 从 workspace 加载已知文件集合
fn load_known_files() -> HashSet<String> {
    workspace_read("known_files.txt")
        .map(|content| {
            content
                .lines()
                .filter(|l| !l.is_empty())
                .map(|l| l.to_string())
                .collect()
        })
        .unwrap_or_default()
}

/// 持久化已知文件集合到 workspace
fn save_known_files(files: &HashSet<String>) {
    let content: Vec<&str> = files.iter().map(|s| s.as_str()).collect();
    let _ = workspace_write("known_files.txt", &content.join("\n"));
}

/// 判断文件名是否为 PDF
fn is_pdf(name: &str) -> bool {
    name.to_lowercase().ends_with(".pdf")
}

/// 判断是否疑似 arxiv 论文
fn is_arxiv(name: &str) -> bool {
    let lower = name.to_lowercase();
    // 匹配 arxiv ID 模式: 2301.12345, 2301.12345v2, etc.
    lower.contains("arxiv")
        || lower.chars().take(4).all(|c| c.is_ascii_digit())
            && lower.contains('.')
            && lower.len() > 10
}

// ==================== 插件实现 ====================

struct PdfWatcher;

impl Guest for PdfWatcher {
    fn metadata() -> PluginMetadata {
        PluginMetadata {
            name: "pdf-watcher".to_string(),
            version: "0.3.0".to_string(),
            api_level: 1,
            author: "小跃".to_string(),
            homepage: None,
            description: "监控下载目录新增 PDF，仅在检测到新文件时触发事件。arxiv 论文自动分析并重命名。".to_string(),
            tags: vec![
                "pdf".to_string(),
                "arxiv".to_string(),
                "watcher".to_string(),
                "automation".to_string(),
            ],
        }
    }

    fn config_schema() -> PluginConfigSchema {
        PluginConfigSchema {
            schema_json: r#"{
                "type": "object",
                "properties": {
                    "poll_interval_ms": {
                        "type": "integer",
                        "default": 5000,
                        "description": "目录扫描间隔（毫秒），仅用于检测变化，不会每次都触发事件"
                    },
                    "watch_dir": {
                        "type": "string",
                        "default": "~/Downloads",
                        "description": "监控目录路径"
                    }
                }
            }"#.to_string(),
            defaults_json: r#"{
                "poll_interval_ms": 5000,
                "watch_dir": "~/Downloads"
            }"#.to_string(),
        }
    }

    fn load(config_json: String) -> Result<(), String> {
        let config: Config = serde_json::from_str(&config_json)
            .map_err(|e| format!("Invalid config: {}", e))?;

        log(LogLevel::Info, &format!(
            "pdf-watcher v0.3.0 loaded: dir={}, scan_interval={}ms (event-on-change only)",
            config.watch_dir, config.poll_interval_ms
        ));

        CONFIG.with(|c| *c.borrow_mut() = Some(config));
        Ok(())
    }

    fn run() -> Result<(), String> {
        let config = CONFIG.with(|c| c.borrow().clone())
            .ok_or("Config not loaded")?;

        log(LogLevel::Info, &format!(
            "pdf-watcher started: watching {} (event-on-change mode)",
            config.watch_dir
        ));

        // 加载已知文件集合（持久化，跨重启保留）
        let mut known_files = load_known_files();

        // 首次启动：扫描当前目录建立基线（不触发事件）
        if known_files.is_empty() {
            log(LogLevel::Info, "First run — building baseline snapshot of existing PDFs");
            if let Ok(entries) = workspace_list(&config.watch_dir) {
                for entry in &entries {
                    if is_pdf(entry) {
                        known_files.insert(entry.clone());
                    }
                }
                save_known_files(&known_files);
                log(LogLevel::Info, &format!(
                    "Baseline: {} existing PDFs catalogued (no events emitted)",
                    known_files.len()
                ));
            } else {
                log(LogLevel::Warn, &format!(
                    "Cannot list directory: {} — will retry next cycle",
                    config.watch_dir
                ));
            }
        }

        // 主循环：定期扫描，只在发现新 PDF 时才发事件
        loop {
            if should_stop() {
                log(LogLevel::Info, "Received stop signal");
                break;
            }

            // 扫描目录
            if let Ok(entries) = workspace_list(&config.watch_dir) {
                let current_pdfs: HashSet<String> = entries
                    .into_iter()
                    .filter(|e| is_pdf(e))
                    .collect();

                // 找出新增的 PDF
                let new_pdfs: Vec<&String> = current_pdfs
                    .iter()
                    .filter(|f| !known_files.contains(*f))
                    .collect();

                if !new_pdfs.is_empty() {
                    let now = now_millis();

                    for pdf_name in &new_pdfs {
                        let is_arxiv_paper = is_arxiv(pdf_name);

                        let event_type = if is_arxiv_paper {
                            "arxiv.paper.detected"
                        } else {
                            "pdf.detected"
                        };

                        log(LogLevel::Info, &format!(
                            "New PDF detected: {} (arxiv={})",
                            pdf_name, is_arxiv_paper
                        ));

                        emit_event(&EventData {
                            event_type: event_type.to_string(),
                            source: "pdf-watcher".to_string(),
                            payload_json: serde_json::json!({
                                "file_name": pdf_name,
                                "watch_dir": config.watch_dir,
                                "is_arxiv": is_arxiv_paper,
                                "detected_at": now,
                            }).to_string(),
                            timestamp_ms: Some(now),
                            priority: 1,  // 高优先级，立即发送
                        });

                        // 加入已知集合
                        known_files.insert(pdf_name.to_string());
                    }

                    // 持久化更新后的已知文件列表
                    save_known_files(&known_files);
                }

                // 清理：移除已知列表中不再存在的文件（防止无限膨胀）
                let stale: Vec<String> = known_files
                    .iter()
                    .filter(|f| !current_pdfs.contains(*f))
                    .cloned()
                    .collect();
                if !stale.is_empty() {
                    for f in &stale {
                        known_files.remove(f);
                    }
                    save_known_files(&known_files);
                }
            }

            sleep(config.poll_interval_ms);
        }

        log(LogLevel::Info, "pdf-watcher stopped gracefully");
        Ok(())
    }

    fn stop() {
        log(LogLevel::Info, "pdf-watcher stopping...");
    }

    fn unload() {
        CONFIG.with(|c| *c.borrow_mut() = None);
        log(LogLevel::Info, "pdf-watcher unloaded");
    }
}

export!(PdfWatcher);
