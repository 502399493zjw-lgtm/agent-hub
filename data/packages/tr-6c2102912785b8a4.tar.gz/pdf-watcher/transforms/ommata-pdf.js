// Transform Ommata-style batch events into OpenClaw agent hook payload
// Used by: hooks.mappings[ommata] → /hooks/ommata
module.exports = function transform(payload) {
  const events = payload.events || [];
  if (events.length === 0) return null;

  // Find PDF-related events
  const pdfEvents = events.filter(e => 
    e.type === 'pdf.detected' || e.type === 'arxiv.paper.detected'
  );
  
  if (pdfEvents.length === 0) return null;

  // Process each PDF event (usually just one)
  const parts = pdfEvents.map(e => {
    let data = {};
    try {
      data = typeof e.payload === 'string' ? JSON.parse(e.payload) : e.payload;
    } catch(err) {
      data = { raw: e.payload };
    }

    const fileName = data.file_name || 'unknown.pdf';
    const filePath = data.file_path || '';
    const isArxiv = data.is_arxiv || false;

    if (isArxiv) {
      return `[arxiv 论文检测] 新文件: ${fileName}\n路径: ${filePath}\n\n请：\n1. 读取该 PDF 前 2 页内容\n2. 分析论文标题和作者\n3. 用 "标题 - 作者.pdf" 格式重命名文件\n4. 简短告知指挥官处理结果`;
    } else {
      return `[新 PDF 检测] 文件: ${fileName}\n路径: ${filePath}\n\n已检测到新下载的 PDF，如有需要可以分析内容。`;
    }
  });

  return {
    message: parts.join('\n\n---\n\n'),
    name: 'pdf-watcher',
    wakeMode: 'now',
    deliver: true,
    channel: 'last'
  };
};
