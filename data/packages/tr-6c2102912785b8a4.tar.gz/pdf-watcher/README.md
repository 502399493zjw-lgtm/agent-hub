# 📄 PDF Watcher

FSEvents 内核级 PDF 文件监控触发器 — 通过 fswatch 监听 ~/Downloads 目录，新 PDF 到达时自动触发 Agent 处理链路（解析/归档/通知）

基于 macOS FSEvents 的高性能文件监控方案。原始方案使用 Ommata WASM 插件，因 WIT 接口缺少 workspace_list 无法访问宿主文件系统，最终改用 fswatch 原生监听。支持 LaunchAgent 开机自启、OpenClaw hooks 回调链路。
