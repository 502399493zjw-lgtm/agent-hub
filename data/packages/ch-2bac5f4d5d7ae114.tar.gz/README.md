# DingTalk OpenClaw Connector

A channel plugin that bridges OpenClaw agents with DingTalk (钉钉) messaging.

## Features

- Receive DM and group messages from DingTalk
- Send text and rich-text replies
- @mention filtering in group chats
- Webhook and Stream mode support
- Card message formatting

## Setup

### 1. Create DingTalk Robot

1. Go to DingTalk Open Platform (open.dingtalk.com)
2. Create a new application
3. Enable Robot capability
4. Get AppKey and AppSecret

### 2. Configure OpenClaw

Add to `openclaw.yaml`:

```yaml
channels:
  dingtalk:
    plugin: dingtalk-openclaw-connector
    appKey: ${DINGTALK_APP_KEY}
    appSecret: ${DINGTALK_APP_SECRET}
    mode: stream  # or webhook
    groupPolicy: mention  # only respond when @mentioned
```

### 3. Webhook Mode

Set callback URL: `https://your-domain/hooks/dingtalk`

### 4. Stream Mode (Recommended)

No public URL needed. The connector maintains a persistent WebSocket connection.

## Message Types

| Type | Send | Receive |
|------|------|---------|
| Text | ✅ | ✅ |
| Rich Text | ✅ | ✅ |
| Card | ✅ | ❌ |
| Image | ❌ | ✅ |
| File | ❌ | ✅ |

## Configuration Options

- `mode`: `stream` (recommended) or `webhook`
- `groupPolicy`: `open` (all messages) / `mention` (@mention only)
- `requireMention`: boolean, default true for groups
- `historyLimit`: max messages to fetch for context
