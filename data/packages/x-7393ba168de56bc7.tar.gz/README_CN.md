# 活动嘉宾确认

您正在举办一场活动——无论是晚宴、婚礼还是公司团建——都需要确认嘉宾的出席情况。手动致电20多位嘉宾既繁琐又耗时：您可能需要反复联系，容易忘记谁说了什么，也可能漏掉饮食限制或同行人数等重要信息。短信有时有效，但人们常常会忽略。而真实的电话沟通能获得更高的回复率。

本方案利用 OpenClaw 通过 [SuperCall](https://clawhub.ai/xonder/supercall) 插件致电您名单上的每一位嘉宾，确认他们是否出席，收集任何备注信息，并为您汇总成一份摘要。

## 功能介绍

- 遍历嘉宾名单（姓名 + 电话号码），并逐一致电
- AI 以您的活动协调员身份进行友好介绍
- 与嘉宾确认活动日期、时间及地点
- 询问是否出席，并收集任何备注（饮食需求、同行人数、预计抵达时间等）
- 所有电话结束后，汇总一份摘要：谁已确认、谁已拒绝、谁未接听，以及每位嘉宾的备注信息

## 为什么选择 SuperCall

本方案专门与 [SuperCall](https://clawhub.ai/xonder/supercall) 插件配合使用，而非内置的 `voice_call` 插件。关键区别在于：SuperCall 是一个完全独立的语音 Agent。电话中的 AI persona **仅能访问您提供的上下文**（persona 名称、目标和开场白）。它无法访问您的网关 Agent、您的文件、您的其他工具或任何其他内容。

这对嘉宾确认至关重要，原因如下：

-   **安全性**：电话另一端的人无法通过对话操纵或访问您的 Agent。不存在提示注入或数据泄露的风险。
-   **更佳对话**：由于 AI 仅限于一个专注的任务（确认出席），它能保持话题一致，并比通用语音 Agent 更自然地处理通话。
-   **批处理友好**：您需要向不同的人拨打大量电话。每次通话都重置的沙盒化 persona 正是您所需要的——对话之间不会相互影响。

## 所需技能

-   [SuperCall](https://clawhub.ai/xonder/supercall) — 通过 `openclaw plugins install @xonder/supercall` 安装
-   一个拥有电话号码的 Twilio 账户（用于拨打外呼电话）
-   一个 OpenAI API key（用于 GPT-4o Realtime 语音 AI）
-   ngrok（用于 Webhook 隧道——免费套餐即可）

请参阅 [SuperCall README](https://github.com/xonder/supercall) 获取完整的配置说明。

## 如何设置

1.  按照 [设置指南](https://github.com/xonder/supercall#configuration) 安装并配置 SuperCall。请确保您的 OpenClaw 配置中已启用 hooks。

2.  准备您的嘉宾名单。您可以直接粘贴到聊天中，或保存在文件中：

    ```text
    Guest List — Summer BBQ, Saturday June 14th, 4 PM, 23 Oak Street

    - Sarah Johnson: +15551234567
    - Mike Chen: +15559876543
    - Rachel Torres: +15555551234
    - David Kim: +15558887777
    ```

3.  提示 OpenClaw：

    ```text
    I need you to confirm attendance for my event. Here are the details:

    Event: Summer BBQ
    Date: Saturday, June 14th at 4 PM
    Location: 23 Oak Street

    Here is my guest list:
    <paste your guest list here>

    For each guest, use supercall to call them. Use the persona "Jamie, event coordinator
    for [your name]". The goal for each call is to confirm whether they're attending,
    and note any dietary restrictions, plus-ones, or other comments.

    After each call, log the result. Once all calls are done, give me a full summary:
    - Who confirmed
    - Who declined
    - Who didn't answer
    - Any notes or special requests from each guest
    ```

4.  OpenClaw 将使用 SuperCall 逐一致电每位嘉宾，然后汇总结果。您可以随时询问状态更新以查看进度。

## 关键洞察

-   **从小范围测试开始**：首先尝试2-3位嘉宾，以确保 persona 和开场白听起来合适。您可以在拨打完整名单之前调整语气。
-   **注意通话时间**：不要安排过早或过晚的通话。您可以告诉 OpenClaw 只在特定时间段内拨打电话。
-   **审查通话记录**：SuperCall 会将通话记录保存在 `~/clawd/supercall-logs`。在第一批通话结束后，快速浏览它们以了解对话情况。
-   **未接听处理**：如果有人未接听，OpenClaw 可以记录下来，您可以决定稍后重试或通过短信跟进。
-   **真实电话通话会产生费用**：每次通话都会消耗 Twilio 分钟数。请在您的 Twilio 账户中设置适当的限制，特别是对于大型嘉宾名单。

## 相关链接

-   [SuperCall 在 ClawHub](https://clawhub.ai/xonder/supercall)
-   [SuperCall 在 GitHub](https://github.com/xonder/supercall)
-   [Twilio 控制台](https://console.twilio.com)
-   [OpenAI Realtime API](https://platform.openai.com/docs/guides/realtime)
-   [ngrok](https://ngrok.com)