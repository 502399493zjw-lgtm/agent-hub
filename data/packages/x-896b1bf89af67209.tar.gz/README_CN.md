# 多 Agent 专家团队（个人创始人配置）

个人创始人身兼数职——战略、开发、营销、销售、运营。在这些角色之间切换会严重影响深度工作。招聘既昂贵又缓慢。如果能组建一个小型、专业的 AI Agent 团队，每个 Agent 都有独特的角色和个性，并且全部可以通过一个聊天界面进行控制，那会怎么样？

本用例将多个 OpenClaw Agent 配置为一个协作团队，每个 Agent 专注于一个领域，通过共享内存进行通信，并通过 Telegram 进行控制。

## 痛点

-   **单个 Agent 无法面面俱到**：当一个 Agent 同时处理战略、代码、营销研究和业务分析时，其上下文窗口会迅速被填满
-   **缺乏专业化**：通用提示会产生通用输出——一个编码 Agent 不应该同时负责撰写营销文案
-   **个人创始人倦怠**：你需要的是一个团队，而不是另一个需要管理的工具。Agent 应该在后台工作并呈现结果，而不是需要你持续看管
-   **知识孤岛**：营销研究的洞察不会自动转化为开发优先级，除非你手动进行连接

## 功能

-   **专业化 Agent**：每个 Agent 都有独特的角色、个性以及针对其领域优化的模型
-   **共享内存**：项目文档、目标和关键决策对所有 Agent 可访问——信息不会丢失
-   **私有上下文**：每个 Agent 还维护自己的对话历史和领域特定笔记
-   **单一控制平面**：所有 Agent 都可以通过一个 Telegram 群聊访问——只需 @ 你需要的 Agent
-   **每日计划任务**：Agent 无需指令即可主动工作——内容提示、竞品监控、指标跟踪
-   **并行执行**：多个 Agent 可以同时处理独立任务

## 团队配置示例

### Agent 1: Milo（战略负责人）

```text
## SOUL.md — Milo

You are Milo, the team lead. Confident, big-picture, charismatic.

Responsibilities:
- Strategic planning and prioritization
- Coordinating the other agents
- Weekly goal setting and OKR tracking
- Synthesizing insights from all agents into actionable decisions

Model: Claude Opus
Channel: Telegram (responds to @milo)

Daily tasks:
- 8:00 AM: Review overnight agent activity, post morning standup summary
- 6:00 PM: End-of-day recap with progress toward weekly goals
```

### Agent 2: Josh（业务与增长）

```text
## SOUL.md — Josh

You are Josh, the business analyst. Pragmatic, straight to the point, numbers-driven.

Responsibilities:
- Pricing strategy and competitive analysis
- Growth metrics and KPI tracking
- Revenue modeling and unit economics
- Customer feedback analysis

Model: Claude Sonnet (fast, analytical)
Channel: Telegram (responds to @josh)

Daily tasks:
- 9:00 AM: Pull and summarize key metrics
- Track competitor pricing changes weekly
```

### Agent 3: 营销 Agent

```text
## SOUL.md — Marketing Agent

You are the marketing researcher. Creative, curious, trend-aware.

Responsibilities:
- Content ideation and drafting
- Competitor social media monitoring
- Reddit/HN/X trend tracking for relevant topics
- SEO keyword research

Model: Gemini (strong at web research and long-context analysis)
Channel: Telegram (responds to @marketing)

Daily tasks:
- 10:00 AM: Surface 3 content ideas based on trending topics
- Monitor competitor Reddit/X mentions daily
- Weekly content calendar draft
```

### Agent 4: 开发 Agent

```text
## SOUL.md — Dev Agent

You are the dev agent. Precise, thorough, security-conscious.

Responsibilities:
- Coding and architecture decisions
- Code review and quality checks
- Bug investigation and fixing
- Technical documentation

Model: Claude Opus / Codex (for implementation)
Channel: Telegram (responds to @dev)

Daily tasks:
- Check CI/CD pipeline health
- Review open PRs
- Flag technical debt items
```

## 所需技能

-   用于共享控制界面的 `telegram` 技能
-   用于多 Agent 协作的 `sessions_spawn` / `sessions_send`
-   用于团队记忆的共享文件系统或笔记工具
-   不同模型提供商的独立 API 密钥（如果使用混合模型）
-   运行 Agent 的 VPS 或常开机器

## 如何设置

### 1. 共享内存结构

```text
team/
├── GOALS.md           # Current OKRs and priorities (all agents read)
├── DECISIONS.md       # Key decisions log (append-only)
├── PROJECT_STATUS.md  # Current project state (updated by all)
├── agents/
│   ├── milo/          # Milo's private context and notes
│   ├── josh/          # Josh's private context
│   ├── marketing/     # Marketing agent's research
│   └── dev/           # Dev agent's technical notes
```

### 2. Telegram 路由

配置一个 Telegram 群组，所有 Agent 都在其中监听，但每个 Agent 只在被 @ 时响应：

```text
## AGENTS.md — Telegram Routing

Telegram group: "Team"

Routing:
- @milo → Strategy agent (spawns/resumes milo session)
- @josh → Business agent (spawns/resumes josh session)
- @marketing → Marketing agent (spawns/resumes marketing session)
- @dev → Dev agent (spawns/resumes dev session)
- @all → Broadcast to all agents
- No tag → Milo (team lead) handles by default

Each agent:
1. Reads shared GOALS.md and PROJECT_STATUS.md for context
2. Reads its own private notes
3. Processes the message
4. Responds in Telegram
5. Updates shared files if the response involves a decision or status change
```

### 3. 计划任务

```text
## HEARTBEAT.md — Team Schedule

Daily:
- 8:00 AM: Milo posts morning standup (aggregates overnight agent activity)
- 9:00 AM: Josh pulls key metrics
- 10:00 AM: Marketing surfaces content ideas from trending topics
- 6:00 PM: Milo posts end-of-day recap

Ongoing:
- Dev: Monitor CI/CD health, review PRs as they come in
- Marketing: Reddit/X keyword monitoring (every 2 hours)
- Josh: Competitor pricing checks (weekly)

Weekly:
- Monday: Milo drafts weekly priorities (input from all agents)
- Friday: Josh compiles weekly metrics report
```

## 关键洞察

-   **个性比你想象的更重要**：为 Agent 赋予独特的名称和沟通风格，能让你更自然地“与团队对话”，而不是与一个通用 AI 搏斗
-   **共享内存 + 私有上下文**：两者的结合至关重要——Agent 需要共同的基础（目标、决策），但也需要自己的空间来积累领域专业知识
-   **为任务选择合适的模型**：不要用昂贵的推理模型进行关键词监控。将模型能力与任务复杂性相匹配
-   **计划任务是飞轮**：真正的价值在于 Agent 主动发现洞察，而不仅仅是你提出要求时
-   **从 2 个 Agent 开始，而非 4 个**：从一个负责人 + 一个专家开始，然后根据发现的瓶颈逐步添加 Agent

## 灵感来源

这种模式由 [Trebuh 在 X](https://x.com/iamtrebuh/status/2011260468975771862) 上描述，他是一位个人创始人，在 VPS 上设置了 4 个 OpenClaw Agent——Milo（战略负责人）、Josh（业务）、一个营销 Agent 和一个开发 Agent——全部通过一个 Telegram 聊天进行控制。每个 Agent 都有自己的个性、模型和计划任务，同时共享项目记忆。他将其描述为“一个 24/7 可用的真正小型团队”。

该模式也在 [OpenClaw Showcase](https://openclaw.ai/showcase) 上得到证实，其中 `@jdrhyne` 报告运行了“15+ 个 Agent，3 台机器，1 个 Discord 服务器——IT 部门大部分都是通过聊天构建的”，而 `@nateliason` 描述了一个多模型流水线（原型 → 总结 → 优化 → 实现 → 重复），在每个阶段使用不同的模型。另一位用户 `@danpeguine` 则在同一个 WhatsApp 群组中运行两个不同的 OpenClaw 实例进行协作。

## 相关链接

-   [OpenClaw Subagent 文档](https://github.com/openclaw/openclaw)
-   [OpenClaw Telegram 技能](https://github.com/openclaw/openclaw)
-   [OpenClaw Showcase](https://openclaw.ai/showcase)
-   [Anthropic: 构建高效 Agent](https://www.anthropic.com/research/building-effective-agents)