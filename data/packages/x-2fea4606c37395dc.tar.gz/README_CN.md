# OpenClaw + N8n 工作流编排

让你的 AI Agent 直接管理 API Key 和调用外部服务，是引发安全事件的隐患。每一次新的集成，都意味着 `.env.local` 中又多了一个凭证，Agent 意外泄露或滥用的风险也随之增加。

本用例描述了一种模式：OpenClaw 通过 Webhook 将所有外部 API 交互委托给 N8n 工作流——Agent 绝不接触凭证，并且每次集成都可被可视化检查和锁定。

## 痛点

当 OpenClaw 直接处理所有事情时，你会遇到三个复合问题：

-   **缺乏可见性**：当 Agent 构建的内容埋藏在 JavaScript skill 文件或 shell 脚本中时，很难检查它到底做了什么。
-   **凭证蔓延**：每个 API Key 都存在于 Agent 的环境中，一次错误的提交就可能导致泄露。
-   **浪费 Token**：确定性的子任务（发送邮件、更新电子表格）会消耗 LLM 推理 Token，而它们本可以作为简单的 N8n 工作流运行。

## 功能

-   **代理模式**：OpenClaw 编写带有传入 Webhook 的 N8n 工作流，然后通过调用这些 Webhook 来进行所有未来的 API 交互。
-   **凭证隔离**：API Key 存储在 N8n 的凭证库中——Agent 只知道 Webhook URL。
-   **可视化调试**：每个工作流都可以在 N8n 的拖放式 UI 中进行检查。
-   **可锁定工作流**：一旦工作流构建并测试完毕，你可以将其锁定，这样 Agent 就无法修改其与 API 交互的方式。
-   **安全保障步骤**：你可以在任何外部调用执行之前，在 N8n 中添加验证、速率限制和审批门槛。

## 工作原理

1.  **Agent 设计工作流**：告诉 OpenClaw 你需要什么（例如，“创建一个工作流，当新的 GitHub Issue 被标记为 `urgent` 时发送 Slack 消息”）。
2.  **Agent 在 N8n 中构建**：OpenClaw 通过 N8n 的 API 创建工作流，包括一个传入 Webhook 触发器。
3.  **你添加凭证**：打开 N8n 的 UI，手动添加你的 Slack Token / GitHub Token。
4.  **你锁定工作流**：防止 Agent 进一步修改。
5.  **Agent 调用 Webhook**：从现在开始，OpenClaw 调用 `http://n8n:5678/webhook/my-workflow` 并附带 JSON Payload——它永远不会看到 API Key。

```text
┌──────────────┐     Webhook 调用      ┌─────────────────┐     API 调用     ┌──────────────┐
│   OpenClaw   │ ───────────────────→  │   N8n 工作流   │ ─────────────→  │  外部        │
│   (Agent)    │   (无凭证)            │  (已锁定，含    │  (凭证留在此处)  │  服务        │
│              │                       │   API Key)      │                 │  (Slack 等)  │
└──────────────┘                       └─────────────────┘                  └──────────────┘
```

## 所需技能

-   `n8n` API 访问（用于创建/触发工作流）
-   `fetch` 或 `curl` 用于 Webhook 调用
-   Docker（如果使用预配置的堆栈）
-   N8n 凭证管理（手动，每次集成一次性设置）

## 如何设置

### 选项 1：预配置的 Docker 堆栈

一个社区维护的 Docker Compose 设置 ([openclaw-n8n-stack](https://github.com/caprihan/openclaw-n8n-stack)) 在共享的 Docker 网络上预先连接了所有内容：

```bash
git clone https://github.com/caprihan/openclaw-n8n-stack.git
cd openclaw-n8n-stack
cp .env.template .env
# Add your Anthropic API key to .env
docker-compose up -d
```

这将为你提供：
-   OpenClaw 在端口 3456
-   N8n 在端口 5678
-   共享 Docker 网络，因此 OpenClaw 可以直接调用 `http://n8n:5678/webhook/...`
-   预构建的工作流模板（多 LLM 事实核查、邮件分类、社交媒体监控）

### 选项 2：手动设置

1.  安装 N8n（`npm install n8n -g` 或通过 Docker 运行）
2.  配置 OpenClaw 以了解 N8n 的基础 URL
3.  将此添加到你的 AGENTS.md：

```text
## N8n 集成模式

当我需要与外部 API 交互时：

1. 绝不将 API Key 存储在我的环境或 skill 文件中
2. 检查此集成是否已存在 N8n 工作流
3. 如果没有，通过 N8n API 创建一个带有 Webhook 触发器的工作流
4. 通知用户添加凭证并锁定工作流
5. 对于所有未来的调用，使用带有 JSON Payload 的 Webhook URL

工作流命名：openclaw-{service}-{action}
示例：openclaw-slack-send-message

Webhook 调用格式：
curl -X POST http://n8n:5678/webhook/{workflow-name} \
  -H "Content-Type: application/json" \
  -d '{"channel": "#general", "message": "Hello from OpenClaw"}'
```

## 关键见解

-   **三赢**：可观测性（可视化 UI）、安全性（凭证隔离）和性能（确定性工作流不消耗 Token）。
-   **测试后锁定**：“构建 → 测试 → 锁定”循环至关重要——不锁定，Agent 可以静默修改工作流。
-   **N8n 拥有 400 多个集成**：你想要连接的大多数外部服务都已经有 N8n 节点，省去了 Agent 编写自定义 API 调用的麻烦。
-   **免费的审计追踪**：N8n 记录每次工作流执行的输入/输出数据。

## 灵感来源

这种模式由 [Simon Høiberg](https://x.com/SimonHoiberg/status/2020843874382487959) 描述，他概述了这种方法优于让 OpenClaw 直接处理 API 交互的三个原因：通过 N8n 的可视化 UI 实现可观测性，通过凭证隔离实现安全性，以及通过将确定性子任务作为工作流而非 LLM 调用运行来提高性能。[openclaw-n8n-stack](https://github.com/caprihan/openclaw-n8n-stack) 仓库提供了一个即插即用的 Docker Compose 设置，实现了这种模式。

## 相关链接

-   [N8n 文档](https://docs.n8n.io/)
-   [openclaw-n8n-stack (Docker 设置)](https://github.com/caprihan/openclaw-n8n-stack)
-   [N8n Webhook 触发器文档](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/)