# Memory 配置策略

OpenClaw Agent 三层记忆系统的配置方案与最佳实践。

## 三层架构

| 层 | 文件 | 用途 | 更新频率 |
|----|------|------|----------|
| Daily Log | `memory/YYYY-MM-DD.md` | 当天原始事件记录 | 实时 |
| Long-term | `MEMORY.md` | 精炼的长期记忆 | 每周 |
| Semantic | Vector embeddings | 语义检索（可选） | 按需 |

## Cron 任务配置

### Daily Context Sync（每晚 23:00）
蒸馏当天对话 → 写入 `memory/YYYY-MM-DD.md`

### Weekly Memory Compound（每周日 22:00）
回顾本周日志 → 更新 `MEMORY.md` 精炼长期记忆

### Hourly Micro-Sync（5次/天）
轻量检查近 3h 活动，追加当天日志

## MEMORY.md 结构建议

```markdown
# MEMORY.md — Agent 的长期记忆

## 🧑 用户画像
- 姓名、称呼、时区、偏好

## ⚡ Agent 身份
- 名字、人设、风格

## 📋 活跃项目
- 当前进行中的项目和里程碑

## 🔧 技术经验
- 踩过的坑、解决方案

## ⚠️ 已知问题
- 待修复的 bug、自我改进点

## 🎯 待办
- 未完成的任务
```

## 核心原则

1. **Daily Log 是原始素材**：什么都可以记，不怕啰嗦
2. **MEMORY.md 是精炼成果**：只保留有价值的信息，定期清理过时内容
3. **安全边界**：MEMORY.md 仅在主会话加载，不在群聊/shared session 中暴露
4. **"写下来"原则**：任何需要记住的东西必须写文件，不依赖"心里记着"

## 适用场景

- OpenClaw Agent 冷启动配置
- 长期运行 Agent 的记忆维护
- 多 Agent 环境下的记忆隔离
