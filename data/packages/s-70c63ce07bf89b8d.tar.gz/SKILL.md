# Brainstorming Skill

Use before any creative work — creating features, building components, or modifying behavior.

## Process

### Phase 1: Understand Intent
- Ask clarifying questions (max 3)
- Identify core problem vs stated request

### Phase 2: Explore Options
- Generate 2-3 distinct approaches
- For each: pros, cons, complexity estimate

### Phase 3: Converge
- Recommend one approach with reasoning
- Get confirmation before proceeding

## Anti-Patterns
- Jumping to implementation without understanding why
- Asking too many questions (analysis paralysis)
- Presenting options without a recommendation
