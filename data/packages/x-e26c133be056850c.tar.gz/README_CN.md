# 多渠道AI客服平台

小型企业需要在多个应用中处理WhatsApp、Instagram私信、电子邮件和Google评论。客户期望24/7即时响应，但雇佣全天候员工成本高昂。

本方案将所有客户触点整合到一个AI驱动的收件箱中，代表您进行智能回复。

## 核心功能

-   **统一收件箱**：将WhatsApp Business、Instagram私信、Gmail和Google评论汇集一处
-   **AI自动回复**：自动处理 FAQ、预约请求和常见咨询
-   **人工转接**：将复杂问题上报或标记以供人工审核
-   **测试模式**：向客户演示系统，而不影响真实客户
-   **业务语境**：基于您的服务、定价和政策进行训练

## 真实业务案例

在 Futurist Systems，我们为本地服务企业（餐厅、诊所、沙龙）部署了此方案。一家餐厅将响应时间从4小时以上缩短到2分钟以内，并自动处理了80%的咨询。

## 所需技能

-   WhatsApp Business API 集成
-   Instagram Graph API（通过 Meta Business）
-   用于 Gmail 的 `gog` CLI
-   用于评论的 Google Business Profile API
-   AGENTS.md 中的消息路由逻辑

## 设置步骤

1.  通过 OpenClaw 配置**连接渠道**：
    -   WhatsApp Business API（通过 360dialog 或官方 API）
    -   通过 Meta Business Suite 连接 Instagram
    -   通过 `gog` OAuth 连接 Gmail
    -   Google Business Profile API 令牌

2.  **创建业务知识库**：
    -   服务和定价
    -   营业时间和地点
    -   FAQ 回复
    -   升级触发器（例如，投诉、退款请求）

3.  使用路由逻辑**配置 AGENTS.md**：

    ```text
    ## 客服模式

    当收到客户消息时：

    1. 识别渠道（WhatsApp/Instagram/Email/Review）
    2. 检查是否为该客户启用了测试模式
    3. 分类意图：
       - FAQ → 从知识库回复
       - Appointment → 检查可用性，确认预订
       - Complaint → 标记以供人工审核，确认收到
       - Review → 感谢反馈，解决疑虑

    回复风格：
    - 友好、专业、简洁
    - 匹配客户语言（ES/EN/UA）
    - 绝不编造知识库中没有的信息
    - 以业务名称署名

    测试模式：
    - 回复前缀为 [TEST]
    - 记录但不发送到真实渠道
    ```

4.  **设置心跳检查**以监控响应：

    ```text
    ## 心跳：客服检查

    每30分钟：
    - 检查是否有超过5分钟未回复的消息
    - 如果响应队列积压，则发出警报
    - 记录每日响应指标
    ```

## 关键洞察

-   **语言检测很重要**：自动检测并以客户的语言回复
-   **测试模式至关重要**：客户需要在上线前看到其运行效果
-   **转接规则**：定义明确的升级触发器，以避免 AI 干预过度
-   **回复模板**：针对敏感话题（退款、投诉）的预批准模板

## 相关链接

-   [WhatsApp Business API](https://developers.facebook.com/docs/whatsapp)
-   [Instagram Messaging API](https://developers.facebook.com/docs/instagram-api/guides/messaging)
-   [Google Business Profile API](https://developers.google.com/my-business)