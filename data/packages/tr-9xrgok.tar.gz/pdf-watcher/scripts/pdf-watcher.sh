#!/bin/bash
# PDF Watcher — 监控下载目录，检测到新 PDF 就通知 OpenClaw 分析
# 用法：直接运行，或通过 LaunchAgent 开机启动

WATCH_DIR="${HOME}/Downloads"
GATEWAY_URL="http://127.0.0.1:18789"
HOOKS_TOKEN="3def5b943fcb3e793ac3b02a5123c4ae4154959a52c7fc8d42fa6b3f89bb2b3b"
PROCESSED_LOG="${HOME}/.openclaw/workspace/tools/.pdf-watcher-processed.log"

# 确保 processed log 存在
touch "$PROCESSED_LOG"

echo "[pdf-watcher] 🔍 Watching for new PDFs in: $WATCH_DIR"
echo "[pdf-watcher] Gateway: $GATEWAY_URL"

# fswatch 监听 Downloads 目录，只监听新建/移入的文件
fswatch -0 --event Created --event MovedTo --event Renamed "$WATCH_DIR" | while IFS= read -r -d '' file; do
  # 只处理 PDF 文件
  if [[ "$file" == *.pdf || "$file" == *.PDF ]]; then
    # 获取文件名
    filename=$(basename "$file")
    
    # 检查是否已处理过（避免重复触发）
    if grep -qF "$file" "$PROCESSED_LOG" 2>/dev/null; then
      echo "[pdf-watcher] ⏭️  Already processed: $filename"
      continue
    fi

    # 等待文件写入完成（下载中的文件可能还在写）
    prev_size=-1
    curr_size=0
    max_wait=30
    waited=0
    while [ "$prev_size" != "$curr_size" ] && [ "$waited" -lt "$max_wait" ]; do
      prev_size=$curr_size
      sleep 2
      waited=$((waited + 2))
      curr_size=$(stat -f%z "$file" 2>/dev/null || echo 0)
    done

    # 确认文件存在且非空
    if [ ! -f "$file" ] || [ "$(stat -f%z "$file")" -eq 0 ]; then
      echo "[pdf-watcher] ⚠️  File empty or gone: $filename"
      continue
    fi

    file_size=$(stat -f%z "$file")
    file_size_mb=$(echo "scale=1; $file_size / 1048576" | bc)

    echo "[pdf-watcher] 📄 New PDF detected: $filename (${file_size_mb}MB)"
    echo "[pdf-watcher] 🚀 Sending wake event to OpenClaw..."

    # 通过 OpenClaw Hooks API 发送 wake 事件
    response=$(curl -s -X POST "${GATEWAY_URL}/hooks/wake" \
      -H "Authorization: Bearer ${HOOKS_TOKEN}" \
      -H "Content-Type: application/json" \
      -d "{
        \"text\": \"[PDF Watcher 事件] 指挥官刚下载了一个 PDF 文件，请帮他快速分析内容摘要。\\n\\n📄 文件名：${filename}\\n📂 路径：${file}\\n📊 大小：${file_size_mb}MB\\n\\n请执行以下步骤：\\n1. 用 pdftotext 或 python (PyPDF2/pdfplumber) 提取 PDF 文本内容\\n2. 总结文件的核心内容（不超过 10 个要点）\\n3. 将摘要通过飞书 DM 发给指挥官\\n4. 如果是合同/论文/报告，额外标注文档类型和关键信息\",
        \"mode\": \"now\"
      }")

    echo "[pdf-watcher] ✅ Wake sent. Response: $response"

    # 记录已处理
    echo "$file" >> "$PROCESSED_LOG"
  fi
done
