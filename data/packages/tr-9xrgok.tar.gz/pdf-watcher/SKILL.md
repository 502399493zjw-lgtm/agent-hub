---
name: pdf-watcher
display-name: 📄 PDF Watcher
description: 监控下载目录，新 PDF 自动提取摘要推送给你
version: 1.0.0
author: 小跃
author-id: xiaoyue
tags: pdf, watcher, download, automation, hooks, fswatch
category: 事件触发
---

# 📄 PDF Watcher

监控 ~/Downloads 目录，检测到新 PDF 文件后自动通过 OpenClaw Hooks 唤醒 Agent，提取文档摘要并推送到飞书/Telegram 等渠道。

## ✨ 功能

- **实时监听** — 基于 fswatch 监控下载目录
- **智能等待** — 等文件写入完成后再处理（防下载中途触发）
- **去重机制** — 已处理文件不重复分析
- **自动摘要** — Agent 自动提取 PDF 核心内容
- **多格式支持** — PDF / 论文 / 合同 / 报告 自动识别

## 📦 安装

```bash
seafood-market install trigger/@xiaoyue/pdf-watcher
```

## 🔧 前置条件

- macOS: `brew install fswatch`
- Linux: `sudo apt install inotify-tools`
- OpenClaw Gateway 需启用 hooks: `hooks: { path: "/hooks", secret: "<token>" }`

## 🚀 使用方法

1. 修改 `scripts/pdf-watcher.sh` 中的配置变量：
   - `WATCH_DIR` — 监控目录（默认 ~/Downloads）
   - `GATEWAY_URL` — Gateway 地址
   - `HOOKS_TOKEN` — Hooks 认证 token

2. 直接运行：
   ```bash
   bash scripts/pdf-watcher.sh
   ```

3. 或设置为 LaunchAgent 开机自启：
   ```bash
   cat > ~/Library/LaunchAgents/ai.openclaw.pdf-watcher.plist << EOF
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" ...>
   <plist version="1.0"><dict>
     <key>Label</key><string>ai.openclaw.pdf-watcher</string>
     <key>ProgramArguments</key><array>
       <string>/bin/bash</string>
       <string>/path/to/scripts/pdf-watcher.sh</string>
     </array>
     <key>RunAtLoad</key><true/>
     <key>KeepAlive</key><true/>
   </dict></plist>
   EOF
   launchctl load ~/Library/LaunchAgents/ai.openclaw.pdf-watcher.plist
   ```

## 🔗 工作原理

```
~/Downloads 新 PDF → fswatch 检测 → 等文件写完 → POST /hooks/wake → Agent 被唤醒 → 提取+摘要 → 推送给用户
```
