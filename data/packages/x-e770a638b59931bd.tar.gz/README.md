# X 账号分析

有很多网站可以给你 X 账号的定量分析，但 Agent 能给你更深入的定性洞察。

本方案让 Agent 深度分析任意 X 账号：

- 内容风格分析（用词、语气、话题偏好）
- 互动模式（什么类型的推文获得最多互动）
- 发布策略（频率、时间段、线程 vs 单推）
- 受众画像推断
- 增长建议：基于数据的可操作优化方案

## 使用方式

给 Agent 一个 X 用户名，它会：
1. 抓取近期推文
2. 分析内容和互动数据
3. 生成详细的分析报告
4. 提供可操作的改进建议

---

# Original (English)

# X Account Analysis

There are many websites designed to give you a qualitative analysis of your X account. While X already gives you an **analytics** section, it's more focused to show your numbers on your performance.

But a qualitative analysis focuses on the quality of your posts, not the performance stats. Some insights you can get from this type of analysis:
- What are the patterns that make my posts go viral?
- What topics I talk about get me most engagement?
- Why do I get posts with 1000+ likes but sometimes posts with <5 likes? What am I doing wrong?

There are many websites and apps designed to give you X analytics, but they focus on the statistics. There are probably 1-2 websites that let you talk with an AI to understand your performance. 

But now you can use OpenClaw to do this analysis for you, without needing to pay $10-$50 for subscriptions on these websites.

## Skills you Need
Bird Skill. `clawhub install bird` (it comes pre-bundled)

## How to Set it Up
Here's the flow:
1. Make sure Bird skill is working.
2. For security and isolation, you better create a new account for your ClawdBot.
3. Auth with your X account. log into x.com in Chrome/Brave, and provide the right cookie information (`auth-token`, `ct0`) so OpenClaw can access your account.
4. Ask OpenClaw to take a look at your real account, fetch the last N tweets, and ask it any questions you like. Alternatively, you can ask it to write you specific scripts.
