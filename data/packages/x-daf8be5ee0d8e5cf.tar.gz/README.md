# 手机端私人助理

## 痛点

你想随时随地访问 AI 助手，但不想依赖 App 或浏览器。开车、走路、双手忙碌时需要语音交互。

## 方案

ClawdTalk 让 OpenClaw 能接打电话，把任何手机变成 AI 助手的入口：

- 拨打一个电话号码即可与 Agent 语音对话
- 查日历、查 Jira 工单、搜索网络，全部通过语音
- 基于 Telnyx 的可靠电话连接
- SMS 支持即将上线

## 所需技能

- [ClawdTalk](https://github.com/team-telnyx/clawdtalk-client)
- 日历技能（Google Calendar / Outlook）
- Jira 技能
- Web 搜索技能

---

# Original (English)

# Phone-Based Personal Assistant

## Pain Point

You want to access your AI agent from any phone without needing a smartphone app or internet browser. You need hands-free voice assistance while driving, walking, or when your hands are occupied.

## What It Does

ClawdTalk enables OpenClaw to receive and make phone calls, turning any phone into a gateway to your AI assistant. You can:
- Call a phone number to speak with your AI agent via voice
- Get calendar reminders, Jira updates, and web search results via voice
- Integrate with Telnyx for reliable phone connectivity

SMS support is coming soon.

## Prompts

```
You are available via phone. When I call, greet me and ask how I can help.

For calendar queries: "What's on my calendar today?"
For Jira updates: "Show me my open tickets"
For web search: "Search for latest news on AI agents"
```

## Skills Needed

- [ClawdTalk](https://github.com/team-telnyx/clawdtalk-client)
- Calendar skill (Google Calendar or Outlook)
- Jira skill
- Web search skill

## Related Links

- [ClawdTalk Website](https://clawdtalk.com)
- [ClawdTalk GitHub](https://github.com/team-telnyx/clawdtalk-client)
- [Telnyx API](https://telnyx.com/)
- [OpenClaw Skills](https://github.com/openclaw/skills)
