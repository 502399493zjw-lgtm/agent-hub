# 手机端私人助理

## 痛点

你想随时随地访问你的 AI Agent，但不想依赖智能手机 App 或互联网浏览器。开车、走路或双手忙碌时，你需要免提语音协助。

## 方案

ClawdTalk 让 OpenClaw 能够接打电话，将任何手机变成你 AI 助手的入口。你可以：
- 拨打一个电话号码，通过语音与你的 AI Agent 对话
- 通过语音获取日历提醒、Jira 更新和网络搜索结果
- 集成 Telnyx 以实现可靠的电话连接

SMS 支持即将上线。

## 提示词

```
You are available via phone. When I call, greet me and ask how I can help.

For calendar queries: "What's on my calendar today?"
For Jira updates: "Show me my open tickets"
For web search: "Search for latest news on AI agents"
```

## 所需技能

- [ClawdTalk](https://github.com/team-telnyx/clawdtalk-client)
- 日历技能（Google Calendar 或 Outlook）
- Jira 技能
- Web 搜索技能

## 相关链接

- [ClawdTalk 网站](https://clawdtalk.com)
- [ClawdTalk GitHub](https://github.com/team-telnyx/clawdtalk-client)
- [Telnyx API](https://telnyx.com/)
- [OpenClaw 技能](https://github.com/openclaw/skills)