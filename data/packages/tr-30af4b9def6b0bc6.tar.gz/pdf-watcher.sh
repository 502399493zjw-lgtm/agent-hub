#!/bin/bash
# pdf-watcher.sh — 监控 ~/Downloads 新增 PDF，只在有新文件时触发 Agent
# 使用 macOS fswatch（基于 FSEvents，零轮询，实时触发）

export PATH="/opt/homebrew/bin:/usr/local/bin:${PATH}"

WATCH_DIR="${HOME}/Downloads"
HOOK_URL="http://127.0.0.1:18789/hooks/ommata"
HOOK_TOKEN="$(python3 -c "import json; c=json.load(open('$HOME/.openclaw/openclaw.json')); print(c['hooks']['token'])")"

echo "[pdf-watcher] Watching ${WATCH_DIR} for new PDFs..."
echo "[pdf-watcher] Hook: ${HOOK_URL}"

# macOS bash 3 不支持 ${,,}，用 tr 替代
to_lower() { echo "$1" | tr '[:upper:]' '[:lower:]'; }

# fswatch 只在文件创建/移入时触发（不是轮询！）
fswatch -0 --event Created --event MovedTo --event Renamed "${WATCH_DIR}" | while IFS= read -r -d '' filepath; do
    filename=$(basename "$filepath")
    lower_name=$(to_lower "$filename")
    
    # 只处理 PDF 文件
    case "$lower_name" in
        *.pdf) ;;
        *) continue ;;
    esac

    echo "[pdf-watcher] New PDF: ${filename}"
    
    # 判断是否为 arxiv 论文
    is_arxiv=false
    event_type="pdf.detected"
    if echo "$lower_name" | grep -q "arxiv"; then
        is_arxiv=true
        event_type="arxiv.paper.detected"
        echo "[pdf-watcher] ↑ Detected as arxiv paper"
    elif echo "$filename" | grep -qE '^[0-9]{4}\.[0-9]{4,5}'; then
        is_arxiv=true
        event_type="arxiv.paper.detected"
        echo "[pdf-watcher] ↑ Detected as arxiv paper (ID pattern)"
    fi

    # 构造 batch payload → 走 hooks/ommata mapping
    now_ms=$(python3 -c "import time; print(int(time.time()*1000))")
    batch_id=$(uuidgen | tr '[:upper:]' '[:lower:]')
    event_id=$(uuidgen | tr '[:upper:]' '[:lower:]')
    now_iso=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    
    # 用 Python 构造 JSON 避免转义问题
    if [ "$is_arxiv" = "true" ]; then
        py_arxiv="True"
    else
        py_arxiv="False"
    fi
    
    python3 -c "
import json, sys
payload = {
    'batch_id': '${batch_id}',
    'timestamp': '${now_iso}',
    'source_count': 1,
    'events': [{
        'id': '${event_id}',
        'source': 'pdf-watcher',
        'type': '${event_type}',
        'timestamp': '${now_iso}',
        'payload': json.dumps({
            'file_name': sys.argv[1],
            'file_path': sys.argv[2],
            'watch_dir': '${WATCH_DIR}',
            'is_arxiv': ${py_arxiv},
            'detected_at': ${now_ms}
        })
    }]
}
print(json.dumps(payload))
" "$filename" "$filepath" | curl -s -X POST "${HOOK_URL}" \
        -H "Authorization: Bearer ${HOOK_TOKEN}" \
        -H "Content-Type: application/json" \
        -d @- > /dev/null 2>&1
    
    echo "[pdf-watcher] → Event sent to Agent"
done
