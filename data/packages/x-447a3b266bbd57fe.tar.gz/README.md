# Reddit 每日精选

每天运行定时任务，从你最喜欢的 Subreddit 中抓取表现最好的帖子，生成精选摘要。

## 用途

- 追踪特定社区的热门讨论
- 不用刷 Reddit 也能了解最新动态
- 自动过滤低质量内容，只看精华

## 所需技能

- [Reddit Skill](https://clawhub.ai) 或 web_fetch
- Cron 定时任务
- 消息推送渠道

## 配置方式

1. 设定你关注的 Subreddit 列表
2. 配置每日执行时间
3. 选择推送渠道（Telegram/Discord/邮件）

---

# Original (English)

# Daily Reddit Digest
Run a daily digest everyday to give you the top performing posts from your favourite subreddits.

What to use it for:

• Browsing subreddits (hot/new/top posts)
• Searching posts by topic
• Pulling comment threads for context
• Building shortlists of posts to manually review/reply to later

> It's read-only. No posting, voting, or commenting.

## Skills you Need
[reddit-readonly](https://clawhub.ai/buksan1950/reddit-readonly) skill. It doesn't need auth. 

## How to Set it Up
After installing the skill, prompt your OpenClaw:
```text
I want you to give me the top performing posts from the following subreddits.
<paste the list here>
Create a separate memory for the reddit processes, about the type of posts I like to see and every day ask me if I liked the list you provided. Save my preference as rules in the memory to use for a better digest curation. (e.g. do not include memes.)
Every day at 5pm, run this process and give me the digest.
```