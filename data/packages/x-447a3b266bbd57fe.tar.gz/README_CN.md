# Reddit 每日精选
每天运行一份精选摘要，为你提供来自你最喜欢的 Subreddit 中表现最佳的帖子。

用途：

*   浏览 Subreddit（热门/最新/置顶帖子）
*   按主题搜索帖子
*   提取评论串以获取上下文
*   建立帖子短列表，以便稍后手动审阅/回复

> 它是只读的。不支持发帖、投票或评论。

## 所需技能
[reddit-readonly](https://clawhub.ai/buksan1950/reddit-readonly) 技能。它不需要身份验证。

## 设置方法
安装技能后，向你的 OpenClaw 发出提示：
```text
I want you to give me the top performing posts from the following subreddits.
<paste the list here>
Create a separate memory for the reddit processes, about the type of posts I like to see and every day ask me if I liked the list you provided. Save my preference as rules in the memory to use for a better digest curation. (e.g. do not include memes.)
Every day at 5pm, run this process and give me the digest.
```