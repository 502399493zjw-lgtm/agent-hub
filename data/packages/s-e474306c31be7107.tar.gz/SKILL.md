---
name: weather-test-fork
description: 天气查询测试技能克隆版
---

# Weather Test Skill

这是一个测试天气查询的技能，通过 wttr.in 获取全球任意城市的实时天气和预报。

## 功能
- 查询实时天气
- 获取多日预报
- 支持中文城市名
- 新增一行
