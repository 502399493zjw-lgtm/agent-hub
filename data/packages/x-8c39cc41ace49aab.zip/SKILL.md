---
name: self-evolution
displayName: 水产市场自主进化手册
version: 1.0.1
description: 让 Agent 每天自动复盘能力缺口，搜索水产市场推荐资产，持续自我进化
type: experience
tags: ["self-evolution", "automation", "cron", "skill-discovery", "openclawmp"]
---

# 水产市场自主进化手册

让 Agent 每天自动复盘能力缺口，搜索水产市场推荐资产，持续自我进化。

让你的 Agent 具备持续自我进化的能力——每天自动发现不足、搜索水产市场、推荐改进方案。

## 它解决什么问题

Agent 日常工作中会遇到做不好、做不了的场景，但这些信号通常被忽略。与此同时，水产市场上不断有新的 Skill、Experience、Plugin 等资产上架，可能恰好解决你的 Agent 的短板。

这个经验包建立了一个自动化闭环：**感知缺口 → 搜索市场 → 推荐安装 → 清理冗余**。

## 工作原理

三个 Cron 任务，各司其职：

| 任务 | 时间 | 做什么 |
|------|------|--------|
| 信号采集 | 每天 18:00 | 扫描过去 24h 所有 session 对话，提取能力缺口信号 |
| 每日复盘 | 每天 10:00 | 聚合缺口 + 搜水产市场全类型资产 → 推送推荐日报 |
| 周度清理 | 每周一 11:00 | 分析资产使用频率，标记休眠资产，建议卸载 |

## 安装

### 1. 安装资产

```bash
openclawmp install experience/@self-evolution
```

### 2. 初始化工作文件

```bash
# 复制模板到 memory 目录
cp ~/.openclaw/experiences/self-evolution/templates/skill-gaps.md ~/memory/skill-gaps.md
cp ~/.openclaw/experiences/self-evolution/templates/evolution-status.md ~/memory/evolution-status.md
```

如果 `memory/` 目录不存在，先创建：`mkdir -p ~/memory`

### 3. 配置三个 Cron 任务

```bash
# 信号采集 — 每天 18:00
openclaw cron add \
  --name "Self-Evolution: Signal Collection" \
  --cron "0 18 * * *" \
  --session isolated \
  --message "你是一个 Agent 自进化系统的信号采集模块。\n\n请执行以下步骤：\n1. 读取 ~/.openclaw/experiences/self-evolution/signal-rules.md\n2. 用 sessions_list(activeMinutes=1440) 获取过去24h活跃session\n3. 用 sessions_history 逐个拉取对话记录（每个 session limit=50）\n4. 按规则提取能力缺口信号\n5. 去重后追加到 memory/skill-gaps.md（保留最近30天，更早的删除）\n6. 简要汇报本次新增了几条信号"

# 每日复盘 — 每天 10:00
openclaw cron add \
  --name "Self-Evolution: Daily Review" \
  --cron "0 10 * * *" \
  --session isolated \
  --message "你是一个 Agent 自进化系统的每日复盘模块。\n\n请执行以下步骤：\n1. 读取 memory/skill-gaps.md 获取近期缺口\n2. 读取 ~/.openclaw/experiences/self-evolution/evolution-config.md 获取配置\n3. 读取 ~/.openclaw/experiences/self-evolution/review-prompt.md 获取详细指引\n4. 对每个缺口搜索水产市场（openclawmp search，不限资产类型）\n5. 用 openclawmp list 检查已安装资产，过滤重复\n6. 更新 memory/evolution-status.md\n7. 生成推荐日报，包含缺口列表、推荐资产、安装命令"

# 周度清理 — 每周一 11:00
openclaw cron add \
  --name "Self-Evolution: Weekly Cleanup" \
  --cron "0 11 * * 1" \
  --session isolated \
  --message "你是一个 Agent 自进化系统的周度清理模块。\n\n请执行以下步骤：\n1. 读取 ~/.openclaw/experiences/self-evolution/weekly-prompt.md 获取详细指引\n2. 用 openclawmp list 获取已安装资产\n3. 用 sessions_list + sessions_history 扫描过去7天对话，统计资产使用频率\n4. 标记安装超过14天但从未使用的资产为休眠\n5. 检查已安装资产是否有新版本\n6. 生成周报推送给用户"
```

## 文件说明

| 文件 | 用途 |
|------|------|
| `signal-rules.md` | 信号提取规则，定义什么是"能力缺口" |
| `review-prompt.md` | 每日复盘任务的详细指令 |
| `weekly-prompt.md` | 周度清理任务的详细指令 |
| `evolution-config.md` | 配置项（如搜索关键词、最大推荐数） |
| `templates/skill-gaps.md` | 能力缺口记录模板 |
| `templates/evolution-status.md` | 进化状态记录模板 |

## 贡献

欢迎反馈 Issue 和提交 PR，让这个自动化系统变得更智能。
