# 多渠道个人助手

在不同应用之间切换来管理任务、安排日程、发送消息和跟踪工作令人筋疲力尽。你想要一个能连接所有工具的统一界面。

这个工作流将所有功能整合到一个 AI 助手中：

• 以 Telegram 作为主要界面，支持基于主题的路由（例如，针对视频创意、CRM、收入、配置等不同主题）
• 集成 Slack 用于团队协作（任务分配、知识库保存、视频创意触发）
• Google Workspace：在聊天中创建日历事件、管理电子邮件、上传到 Drive — 所有操作都可在聊天中完成
• Todoist 用于快速捕获任务
• Asana 用于项目管理
• 自动化提醒：垃圾日、每周公司信件等

## 所需技能

- `gog` CLI (Google Workspace)
- Slack integration (bot + user tokens)
- Todoist API 或 skill
- Asana API 或 skill
- 配置了多个主题的 Telegram channel

## 如何设置

1. 为不同上下文设置 Telegram 主题：
   - `config` — 机器人设置和调试
   - `updates` — 状态和通知
   - `video-ideas` — 内容管道
   - `personal-crm` — 联系人管理
   - `earnings` — 财务跟踪
   - `knowledge-base` — RAG 摄取和查询

2. 通过 OpenClaw 配置连接所有工具：
   - Google OAuth (Gmail, Calendar, Drive)
   - Slack (应用 + 用户令牌)
   - Todoist API 令牌
   - Asana API 令牌

3. 提示 OpenClaw：
```text
You are my multi-channel assistant. Route requests based on context:

Telegram topics:
- "config" → system settings, debugging
- "updates" → daily summaries, reminders, calendar
- "video-ideas" → content pipeline and research
- "personal-crm" → contact queries and meeting prep
- "earnings" → financial tracking
- "knowledge-base" → save and search content

When I ask you to:
- "Add [task] to my todo" → use Todoist
- "Create a card for [topic]" → use Asana Video Pipeline project
- "Schedule [event]" → use gog calendar
- "Email [person] about [topic]" → draft email via gog gmail
- "Upload [file] to Drive" → use gog drive

Set up automated reminders:
- Monday 6 PM: "🗑️ Trash day tomorrow"
- Friday 3 PM: "✍️ Time to write the weekly company update"
```

4. 分别测试每个集成，然后测试跨工作流交互（例如，将 Slack 链接保存到 knowledge base，然后将其用于视频研究卡片）。