# PDF Watcher — OpenClaw Trigger

基于 macOS `fswatch`（FSEvents 内核级事件）的 PDF 文件监控触发器。

## 功能

- 🔍 **实时监控** — 零轮询，内核级文件系统事件（FSEvents）
- 📄 **PDF 检测** — 自动识别 ~/Downloads 中新增的 PDF 文件
- 🎓 **arXiv 论文识别** — 根据文件名模式自动检测 arXiv 论文（如 `2401.12345.pdf`）
- 🔗 **OpenClaw Hooks 集成** — 通过 hooks webhook 唤醒 Agent 处理新文件
- 🚀 **LaunchAgent 自启** — macOS 开机自动运行，崩溃自动重启

## 工作流程

```
FSEvents → fswatch → pdf-watcher.sh → POST /hooks/ommata → JS transform → Agent
```

## 组件

| 文件 | 说明 |
|------|------|
| `pdf-watcher.sh` | 主监控脚本，fswatch + 过滤 + POST hooks |
| `transforms/ommata-pdf.js` | OpenClaw hooks transform，格式化事件为 Agent 可读消息 |
| `com.openclaw.pdf-watcher.plist` | macOS LaunchAgent 配置（开机自启 + KeepAlive） |

## 安装

```bash
# 依赖
brew install fswatch

# 部署脚本
cp pdf-watcher.sh ~/.openclaw/hooks/
cp transforms/ommata-pdf.js ~/.openclaw/hooks/transforms/

# 注册 LaunchAgent
cp com.openclaw.pdf-watcher.plist ~/Library/LaunchAgents/
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist
```

## 配置

在 `openclaw.json` 的 hooks 中添加 mapping：

```json
{
  "hooks": {
    "path": "/hooks",
    "token": "your-token",
    "mappings": [
      { "path": "/hooks/ommata", "transform": "transforms/ommata-pdf.js" }
    ]
  }
}
```
