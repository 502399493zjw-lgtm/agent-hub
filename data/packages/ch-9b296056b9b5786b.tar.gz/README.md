# DingTalk OpenClaw Connector

Bridge OpenClaw agents with DingTalk (钉钉) messaging.

## Features
- Receive DM and group messages
- Send text and rich-text replies
- @mention filtering in group chats
- Stream mode (WebSocket, no public URL needed)

## Setup

### 1. Create DingTalk Robot
Go to open.dingtalk.com → Create app → Enable Robot → Get AppKey/AppSecret

### 2. Configure OpenClaw
```yaml
channels:
  dingtalk:
    plugin: dingtalk-openclaw-connector
    appKey: ${DINGTALK_APP_KEY}
    appSecret: ${DINGTALK_APP_SECRET}
    mode: stream
    groupPolicy: mention
```

## Message Types
| Type | Send | Receive |
|------|------|---------|
| Text | ✅ | ✅ |
| Rich Text | ✅ | ✅ |
| Card | ✅ | ❌ |
| Image | ❌ | ✅ |
