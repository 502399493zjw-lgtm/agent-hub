import { ChannelPlugin } from '@openclaw/sdk';

export default class DingTalkConnector implements ChannelPlugin {
  name = 'dingtalk-openclaw-connector';
  version = '1.0.0';

  async init(config: Record<string, unknown>) {}
  async onMessage(msg: unknown) {}
  async send(target: string, message: string) {}
}
