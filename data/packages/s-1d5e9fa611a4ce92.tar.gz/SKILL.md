---
name: baoyu-skills
description: 宝玉（Baoyu）分享的 Claude Code 技能合集，涵盖小红书图片、幻灯片、漫画、图片压缩、发推等 15 个实用技能。
---

# 宝玉技能集（Baoyu Skills Collection）

宝玉分享的 Claude Code 技能集，提升日常工作效率。包含三大类共 15 个技能。

## 内容技能（Content Skills）

| 技能 | 说明 |
|------|------|
| baoyu-xhs-images | 小红书信息图系列生成器，10 种风格 × 8 种布局 |
| baoyu-slide-deck | 专业幻灯片生成 |
| baoyu-comic | 知识漫画创作，多种画风和语调 |
| baoyu-infographic | 信息图生成器 |
| baoyu-cover-image | 封面图生成 |
| baoyu-article-illustrator | 文章配图生成 |
| baoyu-post-to-x | 发布内容到 X（Twitter） |
| baoyu-post-to-wechat | 发布到微信公众号 |

## AI 生成技能（AI Generation Skills）

| 技能 | 说明 |
|------|------|
| baoyu-image-gen | AI 图片生成后端 |
| baoyu-danger-gemini-web | Gemini Web 集成 |

## 工具技能（Utility Skills）

| 技能 | 说明 |
|------|------|
| baoyu-url-to-markdown | URL 转 Markdown |
| baoyu-danger-x-to-markdown | X 推文转 Markdown |
| baoyu-compress-image | 图片压缩（WebP/PNG） |
| baoyu-format-markdown | Markdown 格式化 |
| baoyu-markdown-to-html | Markdown 转 HTML |

## 安装

```bash
npx skills add jimliu/baoyu-skills
```

## GitHub

https://github.com/JimLiu/baoyu-skills
