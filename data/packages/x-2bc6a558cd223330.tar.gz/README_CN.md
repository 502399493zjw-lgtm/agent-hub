# Todoist 任务管理器：Agent 任务可见性

通过将 Agent 的内部思考和进度日志直接同步到 Todoist，最大化长期运行的 Agent 任务流的透明度。

## 痛点

当 Agent 运行复杂的多步骤任务（例如构建一个全栈应用程序或进行深入研究）时，用户经常会不知道 Agent 当前正在做什么、哪些步骤已完成以及 Agent 可能卡在哪里。手动检查聊天日志对于后台任务来说非常繁琐。

## 功能介绍

本用例使用 `todoist-task-manager` 技能实现以下功能：
1.  **状态可视化**：在特定分区（如 `🟡 进行中` 或 `🟠 等待中`）创建任务。
2.  **外部化思考过程**：将 Agent 的内部“计划”发布到任务描述中。
3.  **实时日志流**：将子步骤完成情况作为评论实时添加到任务中。
4.  **自动协调**：一个心跳脚本会检查停滞的任务并通知用户。

## 所需技能

你不需要预构建的技能。只需提示你的 OpenClaw Agent 创建下方 **设置指南** 中描述的 bash 脚本即可。由于 OpenClaw 可以管理自己的文件系统并执行 shell 命令，它将根据你的请求有效地为你“构建”该技能。

## 详细设置指南

### 1. 配置 Todoist

创建一个项目（例如，“OpenClaw Workspace”）并获取其 ID。为不同状态创建分区：
- `🟡 进行中`
- `🟠 等待中`
- `🟢 已完成`

### 2. 实现：“Agent 自建”技能

你可以要求 OpenClaw 为你创建这些脚本，而不是安装技能。每个脚本都负责与 Todoist API 通信的不同部分。

**`scripts/todoist_api.sh`** (核心封装器)：
```bash
#!/bin/bash
# 用法: ./todoist_api.sh <端点> <方法> [JSON数据]
ENDPOINT=$1
METHOD=$2
DATA=$3
TOKEN="YOUR_TODOIST_API_TOKEN"

if [ -z "$DATA" ]; then
  curl -s -X "$METHOD" "https://api.todoist.com/rest/v2/$ENDPOINT" \
    -H "Authorization: Bearer $TOKEN"
else
  curl -s -X "$METHOD" "https://api.todoist.com/rest/v2/$ENDPOINT" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "$DATA"
fi
```

**`scripts/sync_task.sh`** (任务与状态管理)：
```bash
#!/bin/bash
# 用法: ./sync_task.sh <任务内容> <状态> [任务ID] [描述] [标签JSON数组]
CONTENT=$1
STATUS=$2
TASK_ID=$3
DESCRIPTION=$4
LABELS=$5
PROJECT_ID="YOUR_PROJECT_ID"

case $STATUS in
  "In Progress") SECTION_ID="SECTION_ID_PROGRESS" ;;
  "Waiting")     SECTION_ID="SECTION_ID_WAITING" ;;
  "Done")        SECTION_ID="SECTION_ID_DONE" ;;
  *)             SECTION_ID="" ;;
esac

PAYLOAD="{\"content\": \"$CONTENT\""
[ -n "$SECTION_ID" ] && PAYLOAD="$PAYLOAD, \"section_id\": \"$SECTION_ID\""
[ -n "$PROJECT_ID" ] && [ -z "$TASK_ID" ] && PAYLOAD="$PAYLOAD, \"project_id\": \"$PROJECT_ID\""
if [ -n "$DESCRIPTION" ]; then
  ESC_DESC=$(echo "$DESCRIPTION" | sed ':a;N;$!ba;s/\n/\\n/g' | sed 's/"/\\"/g')
  PAYLOAD="$PAYLOAD, \"description\": \"$ESC_DESC\""
fi
[ -n "$LABELS" ] && PAYLOAD="$PAYLOAD, \"labels\": $LABELS"
PAYLOAD="$PAYLOAD}"

if [ -n "$TASK_ID" ]; then
  ./scripts/todoist_api.sh "tasks/$TASK_ID" POST "$PAYLOAD"
else
  ./scripts/todoist_api.sh "tasks" POST "$PAYLOAD"
fi
```

**`scripts/add_comment.sh`** (进度日志记录)：
```bash
#!/bin/bash
# 用法: ./add_comment.sh <任务ID> <评论文本>
TASK_ID=$1
TEXT=$2
ESC_TEXT=$(echo "$TEXT" | sed ':a;N;$!ba;s/\n/\\n/g' | sed 's/"/\\"/g')
PAYLOAD="{\"task_id\": \"$TASK_ID\", \"content\": \"$ESC_TEXT\"}"
./scripts/todoist_api.sh "comments" POST "$PAYLOAD"
```

### 3. 使用提示

你可以将此提示提供给你的 Agent，以便 **设置** 和 **使用** 该可见性系统：

```text
我希望你为自己的运行构建一个基于 Todoist 的任务可见性系统。

首先，在 'scripts/' 文件夹中创建三个 bash 脚本：
1. todoist_api.sh (用于 Todoist REST API 的 curl 封装)
2. sync_task.sh (用于创建或更新任务，并为进行中、等待中和已完成状态指定 section_id)
3. add_comment.sh (用于将进度日志作为评论发布)

使用以下变量进行设置：
- Token: [你的 Todoist API Token]
- 项目 ID: [你的项目 ID]
- 分区 ID: [进行中 ID, 等待中 ID, 已完成 ID]

创建完成后，对于我给你的每个复杂任务：
1. 在“进行中”状态创建一个任务，并在描述中包含你的完整计划 (PLAN)。
2. 每完成一个子步骤，调用 add_comment.sh 并附上你所做工作的日志。
3. 完成后将任务移至“已完成”状态。
```

## 相关链接
- [Todoist REST API 文档](https://developer.todoist.com/rest/v2/)