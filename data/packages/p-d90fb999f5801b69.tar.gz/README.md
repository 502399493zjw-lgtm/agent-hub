# OpenClaw Telemetry Plugin

By Knostic — Privacy-first observability for OpenClaw agents.

## What It Tracks
- **Tool Usage**: frequency, success/failure rates
- **Session Metrics**: duration, turn count, tokens in/out
- **Error Rates**: failed tool calls, timeouts, retries
- **Cost Estimation**: approximate token costs per session/day

## Privacy First
- All data stays local (SQLite)
- No PII collection
- Optional remote export with explicit opt-in
- 30-day retention default

## Installation
```bash
openclaw plugin install knostic/openclaw-telemetry
```

## Configuration
```yaml
plugins:
  telemetry:
    package: knostic/openclaw-telemetry
    config:
      storage: local
      retention_days: 30
      track_tokens: true
      track_tools: true
      sample_rate: 1.0
```

## Dashboard
```bash
openclaw telemetry dashboard
# Opens http://localhost:18790/telemetry
```
