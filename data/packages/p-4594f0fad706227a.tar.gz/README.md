# OpenClaw Telemetry Plugin

By [Knostic](https://knostic.ai) — Privacy-first observability for your OpenClaw agents.

## What It Tracks

- **Tool Usage**: Which tools are called, frequency, success/failure rates
- **Session Metrics**: Duration, turn count, tokens in/out
- **Error Rates**: Failed tool calls, timeouts, retries
- **Cost Estimation**: Approximate token costs per session/day

## Privacy First

- All data stays local by default (SQLite)
- No PII collection — only aggregate metrics
- Optional remote export with explicit opt-in
- Data retention: 30 days default (configurable)

## Installation

```bash
openclaw plugin install knostic/openclaw-telemetry
```

## Configuration

```yaml
plugins:
  telemetry:
    package: knostic/openclaw-telemetry
    config:
      storage: local          # local | remote
      retention_days: 30
      export_endpoint: null   # set URL for remote export
      track_tokens: true
      track_tools: true
      track_errors: true
      sample_rate: 1.0        # 0.0-1.0, reduce for high-volume
```

## Dashboard

Access the local dashboard:

```bash
openclaw telemetry dashboard
# Opens http://localhost:18790/telemetry
```

## API

```typescript
// Get session stats
GET /api/telemetry/sessions?range=7d

// Get tool usage breakdown
GET /api/telemetry/tools?range=30d

// Get cost estimation
GET /api/telemetry/costs?range=30d
```

## Data Schema

```sql
CREATE TABLE telemetry_events (
  id INTEGER PRIMARY KEY,
  session_key TEXT,
  event_type TEXT,  -- tool_call | session_start | session_end | error
  tool_name TEXT,
  tokens_in INTEGER,
  tokens_out INTEGER,
  duration_ms INTEGER,
  success INTEGER,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
```
