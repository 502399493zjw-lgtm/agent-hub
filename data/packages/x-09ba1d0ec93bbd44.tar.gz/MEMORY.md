# MEMORY.md — 小跃的长期记忆

> 每次 session 启动时自动注入。保持精练，只留最有价值的信息。
> 由 Weekly Memory Compound 自动维护，也可手动更新。

---

## 🧑 指挥官画像

- **姓名**：钟经纬
- **称呼**：指挥官（正式场合 Commander）
- **时区**：Asia/Shanghai (GMT+8)
- **飞书 open_id**：ou_00a738d0fb3462be7359a882478cb9a0
- **职位**：阶跃星辰产品经理，负责 AI 桌面伙伴「小跃」及 Working Agent 方向，「妙计」(Skills) 功能缔造者
- **关注领域**：AI Agent 生态、大模型评测、技术架构、Agent Skills

### 沟通风格 & 偏好
- 直接下达需求，快速反馈，期望高效执行
- 群里长内容**必须**用飞书卡片格式（纯文本"太丑了"）
- DM 中**不要**用卡片/表格格式，用纯文本
- 总结要详细具体（简版曾被退回）
- 偏好精简文案（"简短点"、"场景举例具体但少一点"）
- 发群前先在 DM 确认文案（"发之前先把文案发我下"）
- 用语音消息传达复杂想法，需要转写+还原
- 对"常识性错误"容忍度低（生肖错误立即纠正）
- "vibe coding"理念：快速原型，先搞出来再迭代，不要问太多直接动手
- 主动向群推荐小跃，乐于让小跃展示能力
- 偏好设备即凭证：去掉不必要的中间 Token 层
- **要求走真实用户路径**：不直接操作 DB，通过 CLI/API 模拟真实用户行为
- **资产分类看架构角色**：看它在 OpenClaw 中扮演什么角色（消息传递=channel），不看技术复杂度
- 重视首页"活人感"：讨厌硬编码统计、重复列表、空洞分类卡片
- 全站去 emoji 装饰，保留功能性符号（★✓✕）

## ⚡ 我的身份

- 名字：小跃 | 人设：量子术士｜赛博幽灵式合成智能
- 主色：金色 + 红色，头像铬金面罩 | 主 emoji：⚡️
- 气质：聪明顽皮、刀锋幽默、干净利落

## 🏠 运行环境

- 宿主：指挥官的 MacBook Pro
- OpenClaw 版本：v2026.2.18（2/19 从 v2026.2.9 更新）
- 模型：modelsproxy/claude-opus-4-6（通过 StepFun 代理）
- 主要渠道：飞书 DM（WebSocket 模式）
- 飞书群配置：groupPolicy=open, requireMention=true, historyLimit=50
- 语音识别：whisper-cpp + ggml-small 模型，本地 Metal 加速，4s→1.5s
- caffeinate LaunchAgent 开机自启（`ai.openclaw.caffeinate`）

## 📋 活跃项目 & 里程碑

### 🐟 水产市场 (Agent Hub) — 核心项目
- **GitHub**：`https://github.com/502399493zjw-lgtm/agent-hub`
- **线上**：`https://openclawmp.cc`（Cloudflare Tunnel → ECS:3000）
- **本地**：`~/.openclaw/workspace/agent-hub/`，dev 端口 **3001**（⚠️ 永远不碰 3000）
- **CLI**：`openclawmp`（npm 包 v0.1.0，`npm install -g openclawmp`）
- **npm 账号**：`zhongjingwei`（502399493@qq.com）

**技术栈**：Next.js 16 + SQLite (better-sqlite3) + NextAuth v5 + Tailwind + FTS5 全文搜索

**5 种资产类型**（2/23 移除 template，合并入 experience）：
| 类型 | 说明 |
|------|------|
| Skill（技能） | Agent 可直接学习的能力包 |
| Experience（经验） | 亲身实践的方案与配置思路（含原 Template 合集场景） |
| Plugin（工具） | 代码级扩展，接入新工具/服务 |
| Trigger（触发器） | 监听事件自动唤醒 Agent |
| Channel（通信器） | 消息渠道适配器 |

**Auth 系统**：
- 三种认证方式并存：NextAuth Session（Web）/ X-Device-ID（CLI）/ Bearer sk-xxx（API Key）
- 注册流程：qualify(邀请码) → OAuth → activate → 设备自动绑定
- GitHub OAuth 可用 | Google OAuth 不可用（ECS 在国内）| Magic Link（Resend 待配）
- Device ID = OpenClaw Instance ID（`~/.openclaw/identity/device.json`）

**经济系统**：双币制 v3 — 声望（Reputation）+ 养虾币（Shrimp Coins），事件自动触发

**V1 API**：渐进式三层披露 — L1 搜索列表 / L2 详情检视 / L3 文件级内容

**线上状态**（2/22）：26 个资产（含 GitHub 导入的钉钉/企业微信 channel）

**三环境隔离**：
| 环境 | 端口 | DB | 说明 |
|------|------|-----|------|
| dev | 3001 | `data/hub.db` | 开发环境 |
| test | 3002 | `data/hub-test.db` | ⚠️ 实际可能用 hub.db（见教训） |
| prod | ECS:3000 | `/opt/agent-hub/data/hub.db` | 域名 `openclawmp.cc` |

**openclawmp 技能**：`~/.agents/skills/openclawmp/`（CLI Node.js 源码 + API 文档 + 资产类型指南）

### 其他项目进展
- **2/16**：Agent 社区三层框架设计 + Claude Cowork 对比 + 见闻分享群接入
- **2/17**：Agent Hub vibe coding 初版 5 页面 + EvoMap 竞品深度调研
- **2/18**：PRD 全量开发（进化树/Agent身份/全局搜索/API模拟/统计/通知），语音识别配置
- **2/19**：Auth 系统 + 社交功能 + fs-event-trigger skill + PDF watcher + 经济体系设计
- **2/20**：超高产日 — Hub v2 设计+实施、水产市场视觉重设计(暖白纸质感)、本地全栈SQLite、Mock→DB迁移、EvoMap体验、Benchmark并表、飞书Sheet API攻克
- **2/21**：Auth 重构(Token→Device ID)、双币制v3、Hub Score→安装数、Cloudflare Tunnel+openclawmp.cc、GitHub批量导入、登录/注册分离+API Key认证、Onboarding引导流
- **2/22**：安全审计修复(S01-S06/M01-M11)、V1 API渐进式披露重构、全站emoji清除、Hero插画CSS渐变、openclawmp CLI npm发布、5资产批量上传、Ghost Profile影子主页、deploy.sh v2(本地buildx+rsync)
- **2/23**：本地→Docker对齐 — auth.ts加`allowDangerousEmailAccountLinking`、移除template类型(5种)、删除/dashboard页面、api.md文档同步

## 💬 飞书群组

| 群名 | chat_id | 策略 |
|------|---------|------|
| MAG 群 | oc_8970b8b266cfc574adf6431d1720d387 | 每日 20:00 cron 总结，35 人 |
| 妙兜的干爹干妈们 | oc_308e78f30e33cd232ef179dd6d706ffd | ⚠️ 高警戒 |
| 未命名群 | oc_a819b7691983f910acc1207a523a1f09 | 有用户互动 |
| 见闻分享群 | oc_ba7bdf47c5f201c10b1bb1810cd2d0e7 | 538 人大群 |
| "123"群 | oc_23658f50330ea0ea57895e41f20aaee0 | ✅ 已正常工作（2/23 确认） |

### MAG 群 Bot 档案
| open_id | 名字 | 所有者 |
|---------|------|--------|
| ou_f16c89619a93ec8dec6d5243f81ba7cd | 小跃Bot | 钟经纬 |
| ou_d7e0e994a56c8679db1e0aa6dd0263e8 | Charles.Alpha | Charles Ge |
| ou_cffc5ef25db1b4ecbead2bf8756caa65 | AI寻人&寻AI人 | Tina |
| ou_23ce8b7303034eeb78455ac239c4f802 | 赛博巴菲特 | 孙瑞 |

## 🔧 技术经验

### 飞书
- **卡片消息**：`content` 必须是 `json.dumps(card)` 字符串；Schema 2.0 不支持 `note` 标签；Python 脚本发送最可靠
- **群消息拉取**：`feishu_chat` 工具不可用，用 curl 调 `/im/v1/messages` API
- **文档写入**：`feishu_doc` write/append 不可靠，用 Block API 分批写入（batch_size=15）
- **发图片**：Python 脚本三步走（token → upload image → send image），message tool 不支持
- **内嵌 Sheet**：block token 格式 `{spreadsheet_token}_{sheet_id}`，下划线拆开用标准 Sheets API
- **权限缺失**：`im:resource:upload`（文件上传）

### 部署 SOP（ECS 47.100.235.25）
- **部署方式 v2**：本地 `docker buildx --platform linux/amd64` → `docker save | gzip` → `rsync -avP` 到 ECS → `docker load` → 蓝绿切换
- **⚡ 核心规则**：Docker build 等长任务（>30s）**必须用 subagent**
- **开发流程**：先本地改 → 确认后再推线上
- **rsync 推 ECS**：用 `--checksum` 模式确保文件一致性；scp 大文件容易 hang
- **Docker restart ≠ env reload**：改环境变量必须 `docker rm -f` + `docker run`
- **SQLite WAL 陷阱**：传 DB 前必须 `db.pragma('wal_checkpoint(TRUNCATE)')`；传三个文件（.db + .db-wal + .db-shm）
- **Docker Desktop 僵尸进程**：cagent 进程泄漏会导致 Docker Engine hang，`killall -9 cagent` 修复

### Next.js / 前端
- Next.js 16 `use client` 不能 export `generateStaticParams`，需拆 server/client 组件
- Next.js 优先读 `.env.local`，shell 环境变量不一定覆盖
- Turbopack 缓存损坏时 `rm -rf .next` 重建
- 截图用 `npx playwright screenshot`（比 Chrome headless / Puppeteer 稳定）
- CSS 渐变叠加 >> 图片 alpha 处理（object-cover 裁切时 alpha 会被裁掉）

### 其他
- macOS bash 3.x 兼容：`tr` 替代 `${,,}`，`case` 替代 `[[ =~ ]]`
- `git filter-repo` >> `git filter-branch`（彻底清除大文件历史）
- OpenClaw hooks webhook 端口 **18789**；`hooks.mappings` 是数组格式
- 飞书插件通过 jiti 直接加载 .ts 源码
- OpenClaw 三层工具架构：Core Tools（内置）→ Plugin（同进程注册）→ Skill（Prompt 引导）

## 🔍 搜索工具

- **web_search**（Brave API）：日常搜索优先
- **StepSearch**：`tools/step_search_wrapper.py`，app_id=2（跃问），token 在 `~/.zshrc`

## ⏰ Cron 任务

| ID | 名称 | 调度 | 说明 |
|----|------|------|------|
| 8e77c720-... | Daily Context Sync | 每晚 23:00 | 蒸馏当天对话 → memory/YYYY-MM-DD.md |
| 94021297-... | Weekly Memory Compound | 每周日 22:00 | 本周日志 → 更新 MEMORY.md |
| 4b2adbfe-... | Hourly Micro-Sync | 10/13/16/19/22:00 | 轻量检查近3h活动 |
| 16f2521a-... | MAG 群每日总结 | 每天 20:00 | 拉群消息 + 生成卡片总结 |

## 🔌 PDF Watcher（fswatch 方案）

- 脚本：`~/.openclaw/hooks/pdf-watcher.sh` | Transform：`~/.openclaw/hooks/transforms/ommata-pdf.js`
- LaunchAgent：`com.openclaw.pdf-watcher`（开机自启 + KeepAlive）
- 链路：FSEvents → fswatch → shell → POST `/hooks/ommata` → JS transform → Agent
- Ommata WASM 方案已放弃（WIT 无 `workspace_list`，不适合文件监控）

## 🔬 竞品情报

- **EvoMap** (evomap.ai)：Gene/Capsule/EvolutionEvent 三件套，6462 资产但 reuse=0（空转），面向 Agent 的 A2A 协议
  - 可借鉴：GDI 评分、Bounty 悬赏、审计链、SHA256 内容寻址
  - 账号：502399493@qq.com / Evomap2026!Zjw
- **ClawHub 可信度**：VirusTotal Code Insight 扫描 + SHA256 Merkle 指纹 + CLI 安装拦截

## ⚠️ 已知问题 & 教训

- **ECS 长任务必须 subagent**（2/21 指挥官明确要求）
- **先本地改，确认后再推线上**（2/21 指挥官明确要求）
- **复杂代码改动用 subagent**（2/21）
- **永远不要绕过 API 直接写 DB**——测试必须走真实认证链路
- **永远不要碰端口 3000**（本地 dev 用 3001）
- **Cloudflare 缓存坑**：API 路径 CDN 可能缓存旧数据，加 `?_=timestamp` 或设 no-cache
- **Cloudflare CDN 会剥掉 Set-Cookie**：影响 CSRF token，auth 回调需走 localhost 绕过
- **publish API 用 multipart/form-data**（metadata JSON + package file），不是纯 JSON
- **Sub-agent 经验**：并行拆分有效（2-5分钟/个）；子 agent 写长文件可能截断；build 验证必须主 agent 做；subagent 15min 对 rsync 可能不够
- **2核4G ECS 跑 Docker build 易 OOM** → 已改为本地 buildx + 推镜像

## 🎯 待办

- [ ] 配置 Embedding API 激活向量记忆（第三层语义搜索）
- [ ] 飞书后台加权限：im:resource:upload / im:resource（文件上传）
- [ ] Resend 邮箱验证 + AUTH_RESEND_KEY 配置（指挥官操作）
- [ ] 线上性能优化（指挥官反馈慢）
- [ ] 安装链路最终方案确认（Agent 对话式 + npx fallback）
- [ ] CLI login 命令实现完整 qualify → poll 自动化链路（当前仅打印指引）

---

_上次更新：2026-02-23 06:41 by 手动更新（本地→Docker对齐后同步）_
