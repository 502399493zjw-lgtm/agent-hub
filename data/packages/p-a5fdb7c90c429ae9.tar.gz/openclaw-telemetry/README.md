# 📊 OpenClaw Telemetry

OpenClaw 遥测与可观测性插件 — 收集 Agent 运行指标（token 用量/响应延迟/错误率），支持 Prometheus 导出和本地 SQLite 持久化

Knostic 出品的 OpenClaw 遥测插件。通过 openclaw.plugin.json 注册，自动 hook Agent 的请求/响应生命周期，记录 token 消耗、延迟分布、错误统计。支持 Prometheus /metrics 端点和本地 SQLite 存储。
