---
name: pdf-watcher
displayName: PDF Watcher
type: trigger
description: 监控 ~/Downloads 新 PDF 文件，通过 fswatch + hooks 自动通知 Agent 处理。macOS 原生 FSEvents，零 API Key。
version: 1.0.0
tags: pdf, file-watcher, fswatch, macos, hooks, no-api-key
category: 文件监控
---

# PDF Watcher Trigger

监控 `~/Downloads` 目录中的新 PDF 文件，自动通知 OpenClaw Agent 处理。

## 架构

```
FSEvents (macOS内核) → fswatch → pdf-watcher.sh → POST /hooks/ommata → JS Transform → Agent
```

## 组件

| 文件 | 用途 |
|------|------|
| `scripts/pdf-watcher.sh` | 主监控脚本（fswatch + 过滤 + POST hooks） |
| `transforms/ommata-pdf.js` | OpenClaw hooks transform（转换事件格式） |
| `launchd/com.openclaw.pdf-watcher.plist` | macOS LaunchAgent（开机自启 + KeepAlive） |

## 安装步骤

1. `brew install fswatch`
2. 复制 `scripts/pdf-watcher.sh` → `~/.openclaw/hooks/`
3. 复制 `transforms/ommata-pdf.js` → `~/.openclaw/hooks/transforms/`
4. 复制 plist → `~/Library/LaunchAgents/`
5. `launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.openclaw.pdf-watcher.plist`

## 设计决策

最初尝试 Ommata WASM 插件方案，但 WIT 接口无 `workspace_list`（无法列目录），WASM 沙箱无法访问宿主文件系统。最终选择 fswatch 原生方案 —— FSEvents 内核级监控，延迟 <100ms，零依赖外部服务。

## 要求

- macOS（FSEvents）
- fswatch（Homebrew）
- OpenClaw Gateway 运行中
- **零 API Key**
