# 定制早报

你醒来后，每天的前30分钟都在忙着追赶信息——刷新闻、查日历、看待办事项，试图弄清今天哪些事情最重要。如果这一切都已准备就绪，以一条消息的形式等着你，那会怎样？

这个工作流让 OpenClaw 每天在预设时间向你发送一份完全定制的早报，内容涵盖新闻、任务、创意和主动推荐。

## 功能概览

- 每天同一时间（例如上午8:00）向 Telegram、Discord 或 iMessage 发送一份结构化的早报
- 通过浏览网页研究与你兴趣相关的隔夜新闻
- 审阅你的待办事项列表，并列出当天需要完成的任务
- 在你睡觉时生成创意输出（完整的脚本、邮件草稿、商业提案——而不仅仅是想法）
- 推荐 AI 可以自主完成的任务，以帮助你应对当天的工作

## 痛点

你将一天中最宝贵的早晨时间花在整理思绪上。与此同时，你的 AI Agent 却整夜闲置。早报将夜间的闲置时间转化为高效的准备时间——你醒来时，工作已经完成。

## 你需要的技能

- Telegram、Discord 或 iMessage 集成
- Todoist / Apple Reminders / Asana 集成（你用于任务管理的任何工具）
- [x-research-v2](https://clawhub.ai) 用于社交媒体趋势研究（可选）

## 如何设置

1.  将 OpenClaw 连接到你的消息平台和任务管理器。

2.  提示 OpenClaw：
    ```text
    I want to set up a regular morning brief. Every morning at 8:00 AM,
    send me a report through Telegram.

    I want this report to include:
    1. News stories relevant to my interests (AI, startups, tech)
    2. Ideas for content I can create today
    3. Tasks I need to complete today (pull from my to-do list)
    4. Recommendations for tasks you can complete for me today

    For the content ideas, write full draft scripts/outlines — not just titles.
    ```

3.  OpenClaw 将自动安排此任务。第二天早上检查你的消息，验证它是否正常工作。

4.  随着时间推移进行定制——只需给你的 bot 发送消息：
    ```text
    Add weather forecast to my morning brief.
    Stop including general news, focus only on AI.
    Include a motivational quote each morning.
    ```

5.  如果你不知道要包含什么，也没关系——只需说：
    ```text
    I want this report to include things relevant to me.
    Think of what would be most helpful to put in this report.
    ```

## 核心亮点

- AI 推荐任务部分是最强大的功能——它让 Agent 主动思考如何帮助你，而不是被动等待指令。
- 你只需通过发消息即可定制早报。比如发送“Add stock prices to my morning brief”，它就会更新。
- 完整的草稿（而不仅仅是想法）是节省时间的关键。醒来即可看到脚本，而不是建议。
- 无论你身处哪个行业，一份包含任务、新闻和主动建议的早报都普遍有用。

## 基于

灵感来自 [Alex Finn 关于改变生活的 OpenClaw 用例视频](https://www.youtube.com/watch?v=41_TNGDDnfQ)。