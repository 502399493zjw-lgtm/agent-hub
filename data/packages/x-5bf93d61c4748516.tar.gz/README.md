# 个性化早报

每天醒来第一件事就是刷各种 App 看新闻、查天气、翻日历——太碎片了。

本方案让 OpenClaw 每天早上自动生成一份定制早报：

- 📰 你关注领域的新闻摘要（AI、科技、金融等）
- 🌤️ 今日天气与穿衣建议
- 📅 今天的日程安排
- ✅ 待处理的重要事项
- 💡 一条有趣的知识或名言

## 工作原理

1. 通过 Cron 任务在每天早上 7:00 触发
2. Agent 并行获取各数据源信息
3. 整合为一份简洁的早报
4. 推送到 Telegram/Discord/飞书

## 你需要的技能

- web_search（内置）
- 天气查询技能
- 日历集成（Google Calendar / Apple Calendar）
- 消息推送渠道（Telegram / Discord）

---

# Original (English)

# Custom Morning Brief

You wake up and spend the first 30 minutes of your day catching up — scrolling news, checking your calendar, reviewing your to-do list, trying to figure out what matters today. What if all of that was already done and waiting for you as a text message?

This workflow has OpenClaw send you a fully customized morning briefing every day at a scheduled time, covering news, tasks, ideas, and proactive recommendations.

## What It Does

- Sends a structured morning report to Telegram, Discord, or iMessage at the same time every day (e.g., 8:00 AM)
- Researches overnight news relevant to your interests by browsing the web
- Reviews your to-do list and surfaces tasks for the day
- Generates creative output (full scripts, email drafts, business proposals — not just ideas) while you sleep
- Recommends tasks the AI can complete autonomously to help you that day

## Pain Point

You're spending your most productive morning hours just getting oriented. Meanwhile, your AI agent sits idle all night. The morning brief turns idle overnight hours into productive prep time — you wake up to work already done.

## Skills You Need

- Telegram, Discord, or iMessage integration
- Todoist / Apple Reminders / Asana integration (whichever you use for tasks)
- [x-research-v2](https://clawhub.ai) for social media trend research (optional)

## How to Set It Up

1. Connect OpenClaw to your messaging platform and task manager.

2. Prompt OpenClaw:
```text
I want to set up a regular morning brief. Every morning at 8:00 AM,
send me a report through Telegram.

I want this report to include:
1. News stories relevant to my interests (AI, startups, tech)
2. Ideas for content I can create today
3. Tasks I need to complete today (pull from my to-do list)
4. Recommendations for tasks you can complete for me today

For the content ideas, write full draft scripts/outlines — not just titles.
```

3. OpenClaw will schedule this automatically. Verify it's working by checking your messages the next morning.

4. Customize over time — just text your bot:
```text
Add weather forecast to my morning brief.
Stop including general news, focus only on AI.
Include a motivational quote each morning.
```

5. If you can't think of what to include, you don't have to — just say:
```text
I want this report to include things relevant to me.
Think of what would be most helpful to put in this report.
```

## Key Insights

- The AI-recommended tasks section is the most powerful part — it has the agent proactively think of ways to help you, rather than waiting for instructions.
- You can customize the brief just by texting. Say "Add stock prices to my morning brief" and it updates.
- Full drafts (not just ideas) are the key to saving time. Wake up to scripts, not suggestions.
- It doesn't matter what industry you're in — a morning brief with tasks, news, and proactive suggestions is universally useful.

## Based On

Inspired by [Alex Finn's video on life-changing OpenClaw use cases](https://www.youtube.com/watch?v=41_TNGDDnfQ).
