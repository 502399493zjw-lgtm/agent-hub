# Polymarket Autopilot：自动化模拟交易

手动监控预测市场以寻找套利机会并执行交易既耗时又需要持续关注。你想在不冒真金白银风险的情况下测试和完善交易策略。

此工作流通过自定义策略自动化 Polymarket 的模拟交易：

*   通过 API 监控市场数据（价格、成交量、价差）
*   使用 TAIL（趋势跟随）和 BONDING（逆势）策略执行模拟交易
*   追踪投资组合表现、盈亏和胜率
*   每日向 Discord 推送交易日志和分析
*   从模式中学习：根据回测结果调整策略参数

## 痛点

预测市场变化很快。手动交易意味着错过机会、情绪化决策，以及难以追踪什么策略有效。在了解市场行为之前，用真金白银测试策略会面临亏损风险。

## 功能介绍

该 Autopilot 持续扫描 Polymarket 寻找机会，使用可配置的策略模拟交易，并记录一切以供分析。你醒来时会看到一份关于它夜间“交易”了什么、哪些有效、哪些无效的总结报告。

示例策略：
- **TAIL**：当成交量飙升且动量明确时跟随趋势
- **BONDING**：当市场对新闻反应过度时买入逆势头寸
- **SPREAD**：识别具有套利潜力的定价错误市场

## 所需技能

- `web_search` 或 `web_fetch`（用于获取 Polymarket API 数据）
- `postgres` 或 SQLite（用于交易日志和投资组合追踪）
- Discord 集成（用于每日报告）
- Cron job（用于持续监控）
- Sub-agent 生成（用于并行市场分析）

## 如何设置

1.  设置一个用于模拟交易的数据库：
    ```sql
    CREATE TABLE paper_trades (
      id SERIAL PRIMARY KEY,
      market_id TEXT,
      market_name TEXT,
      strategy TEXT,
      direction TEXT,
      entry_price DECIMAL,
      exit_price DECIMAL,
      quantity DECIMAL,
      pnl DECIMAL,
      timestamp TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE TABLE portfolio (
      id SERIAL PRIMARY KEY,
      total_value DECIMAL,
      cash DECIMAL,
      positions JSONB,
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    ```

2.  创建一个用于接收更新的 Discord 频道（例如，#polymarket-autopilot）。

3.  提示 OpenClaw：
    ```text
    你是一个 Polymarket 模拟交易 Autopilot。持续运行（通过 Cron 每 15 分钟一次）：

    1. 从 Polymarket API 获取当前市场数据
    2. 使用以下策略分析机会：
       - TAIL：跟随强劲趋势（>60% 概率 + 成交量飙升）
       - BONDING：针对过度反应的逆势操作（新闻发布后突然下跌 >10%）
       - SPREAD：当 YES+NO > 1.05 时进行套利
    3. 在数据库中执行模拟交易（起始资金：$10,000）
    4. 追踪投资组合状态并更新头寸

    每天早上 8 点，向 Discord #polymarket-autopilot 发布一份总结报告：
    - 昨天的交易（入场/出场价格，盈亏）
    - 当前投资组合价值和未平仓头寸
    - 胜率和策略表现
    - 市场洞察和建议

    在高交易量时期，使用 Sub-agent 并行分析多个市场。

    切勿使用真金白银。这仅是模拟交易。
    ```

4.  根据表现迭代策略。调整阈值，添加新策略，回测历史数据。

## 相关链接

- [Polymarket API](https://docs.polymarket.com/)
- [模拟交易最佳实践](https://www.investopedia.com/articles/trading/11/paper-trading.asp)