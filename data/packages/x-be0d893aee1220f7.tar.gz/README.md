# 个人知识库（RAG）

你每天读文章、刷推特、看视频，但永远找不到上周看过的那个东西。书签越存越多，最终变成废品。

本方案搭建一个可搜索的个人知识库：

- 在 Telegram 或 Slack 中丢入任何 URL，自动入库（文章、推文、YouTube 字幕、PDF）
- 语义搜索你保存过的一切："我存过什么关于 Agent 记忆的内容？"返回排名结果和来源
- 可被其他工作流调用——例如内容创作时自动查询知识库获取素材

## 所需技能

- knowledge-base 技能（或自建 RAG + Embedding）
- web_fetch（内置）
- Telegram/Slack 消息渠道

## 配置方式

1. 安装 knowledge-base 技能
2. 创建一个 Telegram 话题或 Slack 频道用于收录
3. 配置 Agent：收到 URL 时自动抓取、分块、入库
4. 测试：丢几个链接，然后问 "我有什么关于 LLM 记忆的内容？"

---

# Original (English)

# Personal Knowledge Base (RAG)

You read articles, tweets, and watch videos all day but can never find that one thing you saw last week. Bookmarks pile up and become useless.

This workflow builds a searchable knowledge base from everything you save:

• Drop any URL into Telegram or Slack and it auto-ingests the content (articles, tweets, YouTube transcripts, PDFs)
• Semantic search over everything you've saved: "What did I save about agent memory?" returns ranked results with sources
• Feeds into other workflows — e.g., the video idea pipeline queries the KB for relevant saved content when building research cards

## Skills you Need

- [knowledge-base](https://clawhub.ai) skill (or build custom RAG with embeddings)
- `web_fetch` (built-in)
- Telegram topic or Slack channel for ingestion

## How to Set it Up

1. Install the knowledge-base skill from ClawdHub.
2. Create a Telegram topic called "knowledge-base" (or use a Slack channel).
3. Prompt OpenClaw:
```text
When I drop a URL in the "knowledge-base" topic:
1. Fetch the content (article, tweet, YouTube transcript, PDF)
2. Ingest it into the knowledge base with metadata (title, URL, date, type)
3. Reply with confirmation: what was ingested and chunk count

When I ask a question in this topic:
1. Search the knowledge base semantically
2. Return top results with sources and relevant excerpts
3. If no good matches, tell me

Also: when other workflows need research (e.g., video ideas, meeting prep), automatically query the knowledge base for relevant saved content.
```

4. Test it by dropping a few URLs and asking questions like "What do I have about LLM memory?"
