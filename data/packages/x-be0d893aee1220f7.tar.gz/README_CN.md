# 个人知识库 (RAG)

你每天读文章、刷推特、看视频，但永远找不到上周看过的那个东西。书签越存越多，最终变成废品。

本方案搭建一个可搜索的个人知识库：

*   在 Telegram 或 Slack 中丢入任何 URL，自动入库（文章、推文、YouTube 字幕、PDF）
*   语义搜索你保存过的一切："我存过什么关于 Agent 记忆的内容？"返回排名结果和来源
*   可被其他工作流调用——例如内容创作时自动查询知识库获取素材

## 所需技能

*   [knowledge-base](https://clawhub.ai) 技能（或自建 RAG + Embedding）
*   `web_fetch`（内置）
*   Telegram/Slack 消息渠道

## 配置方式

1.  从 ClawdHub 安装 knowledge-base 技能。
2.  创建一个名为 "knowledge-base" 的 Telegram 话题（或使用 Slack 频道）。
3.  配置 OpenClaw：
    ```text
    When I drop a URL in the "knowledge-base" topic:
    1. Fetch the content (article, tweet, YouTube transcript, PDF)
    2. Ingest it into the knowledge base with metadata (title, URL, date, type)
    3. Reply with confirmation: what was ingested and chunk count

    When I ask a question in this topic:
    1. Search the knowledge base semantically
    2. Return top results with sources and relevant excerpts
    3. If no good matches, tell me

    Also: when other workflows need research (e.g., video ideas, meeting prep), automatically query the knowledge base for relevant saved content.
    ```
4.  通过丢入几个 URL 并提问（例如 "我有什么关于 LLM 记忆的内容？"）进行测试。