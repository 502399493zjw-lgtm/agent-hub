# 多Agent内容工厂

你是一位内容创作者，身兼数职，要在多个平台兼顾调研、写作和设计。每个步骤——寻找热门话题、撰写脚本、生成缩略图——都会耗费你数小时的时间。如果有一个专业 Agent 团队能在一夜之间全部搞定，那会怎样？

本工作流在 Discord 中搭建了一个多 Agent 内容工厂，不同的 Agent 在专属频道中处理调研、写作和视觉资产。

## 功能特性

- **调研 Agent** 每天早上扫描热门故事、竞品内容和社交媒体，寻找最佳内容机会
- **写作 Agent** 选取最佳创意，撰写完整的脚本、帖子串或新闻稿草稿
- **缩略图 Agent** 为内容生成 AI 缩略图或封面图片
- 每个 Agent 在其专属 Discord 频道中工作，保持一切井然有序且可供审查
- 按计划自动运行（例如，每天早上8点），让你一觉醒来就能看到完成的内容

## 痛点

内容创作有三个阶段——调研、写作和设计——大多数创作者都是手动完成这三个阶段。即使使用 AI 写作工具，你仍然需要逐一进行提示。本系统将 Agent 串联成一个流水线，一个 Agent 的输出作为下一个 Agent 的输入，完全无需人工干预。

## 所需技能

- Discord 多频道集成
- `sessions_spawn` / `sessions_send` 用于多 Agent 编排
- [x-research-v2](https://clawhub.ai) 或类似工具用于社交媒体调研
- 本地图像生成（例如 Nano Banana）或图像生成 API
- [knowledge-base](https://clawhub.ai) 技能（可选，用于 RAG 驱动的调研）

## 设置方法

1.  设置一个 Discord 服务器（或者让 OpenClaw 帮你完成——只需说“为我们设置一个 Discord”）。

2.  为每个 Agent 创建频道：
    -   `#research` — 热门话题和内容机会
    -   `#scripts` — 撰写好的草稿和大纲
    -   `#thumbnails` — 生成的图片和封面艺术

3.  提示 OpenClaw：
```text
I want you to build me a content factory inside of Discord.
Set up channels for different agents:

1. Research Agent (#research): Every morning at 8 AM, research top trending
   stories, competitor content, and what's performing well on social media
   in my niche. Post the top 5 content opportunities with sources.

2. Writing Agent (#scripts): Take the best idea from the research agent
   and write a full script/thread/newsletter draft. Post it in #scripts.

3. Thumbnail Agent (#thumbnails): Generate AI thumbnails or cover images
   for the content. Post them in #thumbnails.

Have all their work organized in different channels.
Run this pipeline automatically every morning.
```

4.  为你的平台定制：
```text
I focus on X/Twitter threads, not YouTube. Change the writing agent
to produce tweet threads instead of video scripts.
```

## 关键洞察

-   核心在于**链式 Agent**——调研结果输入给写作，写作结果输入给缩略图。你无需单独提示每个步骤。
-   Discord 频道使得单独审查每个 Agent 的工作变得容易，并可以提供反馈，例如“脚本太长”或“更多关注 AI 新闻”。
-   你可以将其应用于任何内容格式：推文、新闻稿、LinkedIn 帖子、播客大纲、博客文章。
-   运行本地图像生成模型（例如 Mac Studio 上的 Nano Banana）可以降低成本并提供更多控制。

## 基于

灵感来源于 [Alex Finn 关于改变生活的 OpenClaw 用例的视频](https://www.youtube.com/watch?v=41_TNGDDnfQ)。

## 相关链接

-   [OpenClaw Subagent 文档](https://github.com/openclaw/openclaw)
-   [Discord Bot 设置](https://discord.com/developers/docs)